/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useApp } from '../contexts/AppContext';
import { 
  LayoutDashboard, 
  BookOpen, 
  Receipt, 
  ScanBarcode, 
  Users, 
  RefreshCw, 
  Settings, 
  LogOut, 
  Menu, 
  X, 
  GraduationCap,
  Database,
  UserCheck
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface DashboardLayoutProps {
  children: React.ReactNode;
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export default function DashboardLayout({ children, activeTab, setActiveTab }: DashboardLayoutProps) {
  const { activeUser, logout, schoolSettings, config } = useApp();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  if (!activeUser) return null;

  const is_admin = activeUser.Role === 'ADMIN';

  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard, roles: ['ADMIN', 'TU'] },
    { id: 'buku', label: 'Data Buku', icon: BookOpen, roles: ['ADMIN', 'TU'] },
    { id: 'pesanan', label: 'Pesanan & Pembayaran', icon: Receipt, roles: ['ADMIN', 'TU'] },
    { id: 'scan', label: 'Pengeluaran Buku', icon: ScanBarcode, roles: ['ADMIN', 'TU'] },
    { id: 'siswa', label: 'Kelola Siswa', icon: Users, roles: ['ADMIN'] },
    { id: 'sync', label: 'Integrasi Google Sheet', icon: Database, roles: ['ADMIN'] },
  ];

  const filteredMenuItems = menuItems.filter(item => item.roles.includes(activeUser.Role));

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col md:flex-row font-sans">
      
      {/* Mobile Header */}
      <header className="md:hidden bg-brand-blue-900 text-white flex items-center justify-between p-4 shadow-md sticky top-0 z-50">
        <div className="flex items-center space-x-3">
          <GraduationCap className="h-7 w-7 text-brand-gold-400" />
          <div>
            <h1 className="text-sm font-bold font-display tracking-tight text-brand-gold-400">SD XAVERIUS 2</h1>
            <p className="text-[10px] text-slate-300">Sistem Penjualan Buku</p>
          </div>
        </div>
        <button 
          onClick={() => setSidebarOpen(!sidebarOpen)}
          className="p-1 hover:bg-brand-blue-800 rounded transition-colors"
          id="mobile-menu-toggle"
        >
          {sidebarOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </header>

      {/* Sidebar for Desktop & Mobile Overlay */}
      <AnimatePresence>
        {(sidebarOpen || true) && (
          <motion.aside
            initial={{ x: -260 }}
            animate={{ x: 0 }}
            exit={{ x: -260 }}
            transition={{ duration: 0.3, ease: 'easeInOut' }}
            className={`fixed md:sticky top-[60px] md:top-0 left-0 bottom-0 w-[260px] bg-brand-blue-950 text-white flex flex-col justify-between shadow-2xl z-40 shrink-0 md:h-screen ${
              sidebarOpen ? 'block' : 'hidden md:flex'
            }`}
          >
            {/* Logo Section */}
            <div>
              <div className="hidden md:flex items-center space-x-3 p-6 border-b border-brand-blue-900 bg-brand-blue-900/40">
                <GraduationCap className="h-8 w-8 text-brand-gold-400 shrink-0" />
                <div>
                  <h1 className="text-md font-bold font-display tracking-tight text-brand-gold-400">SD XAVERIUS 2</h1>
                  <p className="text-xs text-slate-300">TEXTBOOK SYSTEM</p>
                </div>
              </div>

              {/* Active User Mini Profile */}
              <div className="p-5 border-b border-brand-blue-900 bg-brand-blue-900/10 flex items-center space-x-3">
                <div className="h-10 w-10 rounded-full bg-brand-gold-500 text-brand-blue-950 font-bold flex items-center justify-center border-2 border-brand-gold-400 shadow-inner">
                  {activeUser.Username.substring(0, 2).toUpperCase()}
                </div>
                <div>
                  <h2 className="text-sm font-semibold text-slate-100">{activeUser.Username}</h2>
                  <div className="flex items-center space-x-1 mt-0.5">
                    <UserCheck className="h-3 w-3 text-brand-gold-400" />
                    <span className="text-[11px] font-bold text-brand-gold-400 tracking-wider">
                      {activeUser.Role === 'ADMIN' ? 'ADMINISTRATOR' : 'STAFF TATA USAHA'}
                    </span>
                  </div>
                </div>
              </div>

              {/* Menu Navigation */}
              <nav className="p-4 space-y-1">
                {filteredMenuItems.map(item => {
                  const IconComponent = item.icon;
                  const is_active = activeTab === item.id;
                  return (
                    <button
                      key={item.id}
                      onClick={() => {
                        setActiveTab(item.id);
                        setSidebarOpen(false);
                      }}
                      className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg text-sm font-medium transition-all ${
                        is_active
                          ? 'bg-brand-gold-600 text-brand-blue-950 font-semibold shadow-md border-l-4 border-brand-gold-400'
                          : 'text-slate-300 hover:bg-brand-blue-900 hover:text-white'
                      }`}
                      id={`sidebar-link-${item.id}`}
                    >
                      <IconComponent className={`h-5 w-5 ${is_active ? 'text-brand-blue-950' : 'text-slate-400 group-hover:text-white'}`} />
                      <span>{item.label}</span>
                    </button>
                  );
                })}
              </nav>
            </div>

            {/* Logout Button */}
            <div className="p-4 border-t border-brand-blue-900 bg-brand-blue-950">
              <button
                onClick={logout}
                className="w-full flex items-center space-x-3 px-4 py-3 rounded-lg text-sm font-medium text-rose-400 hover:bg-rose-900/20 hover:text-rose-300 transition-all"
                id="sidebar-logout"
              >
                <LogOut className="h-5 w-5" />
                <span>Keluar (Logout)</span>
              </button>
            </div>
          </motion.aside>
        )}
      </AnimatePresence>

      {/* Main Panel */}
      <main className="flex-1 flex flex-col min-w-0 md:max-h-screen md:overflow-y-auto">
        {/* Top Header Panel (Desktop) */}
        <header className="hidden md:flex bg-white border-b border-slate-200 py-4 px-8 items-center justify-between sticky top-0 z-30 shadow-sm">
          <div className="flex items-center space-x-4">
            <img 
              src={schoolSettings.Logo} 
              alt="Logo Sekolah" 
              className="h-10 w-10 object-cover rounded-md border border-slate-200"
              referrerPolicy="no-referrer"
            />
            <div>
              <h2 className="text-md font-bold text-brand-blue-900">{schoolSettings.NamaSekolah}</h2>
              <p className="text-xs text-slate-500">{schoolSettings.Alamat}</p>
            </div>
          </div>

          {/* Sync & Academic Status Widget */}
          <div className="flex items-center space-x-4">
            <div className="text-right">
              <span className="text-[11px] text-slate-400 uppercase tracking-wider block font-bold">Tahun Pelajaran</span>
              <span className="text-xs font-bold text-brand-blue-800 bg-slate-100 px-2 py-0.5 rounded">
                {schoolSettings.TahunPelajaran}
              </span>
            </div>

            {/* Connection Mode Status */}
            <div className="flex items-center space-x-2 bg-slate-50 border border-slate-200 px-3 py-1.5 rounded-lg">
              <div className={`h-2.5 w-2.5 rounded-full ${config.isLiveMode ? 'bg-emerald-500 animate-pulse' : 'bg-amber-500'}`} />
              <div className="text-left">
                <span className="text-[10px] text-slate-400 block font-bold leading-none">DATABASE MODE</span>
                <span className="text-xs font-semibold text-slate-700">
                  {config.isLiveMode ? 'Google Sheet Live' : 'Simulasi Offline'}
                </span>
              </div>
            </div>
          </div>
        </header>

        {/* Content Box */}
        <div className="flex-1 p-4 md:p-8">
          {children}
        </div>
      </main>
    </div>
  );
}
