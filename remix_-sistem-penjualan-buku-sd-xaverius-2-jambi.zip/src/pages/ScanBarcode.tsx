/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { useApp } from '../contexts/AppContext';
import { Pesanan, DetailPesanan, Buku } from '../types';
import { 
  Scan, 
  Search, 
  Camera, 
  CheckCircle, 
  AlertCircle, 
  Sparkles, 
  ArrowLeft,
  ChevronRight,
  User,
  Barcode as BarcodeIcon,
  Play
} from 'lucide-react';
import { Html5QrcodeScanner } from 'html5-qrcode';
import { motion, AnimatePresence } from 'motion/react';

export default function ScanBarcode() {
  const { pesanan, detailPesanan, buku, dispatchBook, showToast } = useApp();

  // Active Orders waiting for Dispatch (LUNAS status)
  const activeOrders = pesanan.filter(p => p.Status === 'LUNAS');

  // Scanner states
  const [selectedOrder, setSelectedOrder] = useState<Pesanan | null>(null);
  const [orderSearch, setOrderSearch] = useState('');
  const [manualBarcode, setManualBarcode] = useState('');
  
  // Camera scan states
  const [isCameraActive, setIsCameraActive] = useState(false);
  const scannerRef = useRef<Html5QrcodeScanner | null>(null);

  // Filter active orders based on search
  const filteredOrders = activeOrders.filter(p => 
    p.NamaSiswa.toLowerCase().includes(orderSearch.toLowerCase()) || 
    p.NoPesanan.toLowerCase().includes(orderSearch.toLowerCase()) ||
    p.NIS.includes(orderSearch)
  );

  const getOrderItems = (noPesanan: string): DetailPesanan[] => {
    return detailPesanan.filter(d => d.NoPesanan === noPesanan);
  };

  // Turn on/off camera scanner
  useEffect(() => {
    if (isCameraActive && selectedOrder) {
      // Delay initialization slightly to let the div mount in DOM
      const timer = setTimeout(() => {
        try {
          const scanner = new Html5QrcodeScanner(
            "reader", 
            { fps: 10, qrbox: { width: 250, height: 250 } },
            false
          );
          
          scanner.render(
            (decodedText) => {
              // On successful scan
              handleBarcodeScan(decodedText);
              // Stop camera scanner after success
              scanner.clear();
              setIsCameraActive(false);
            },
            (err) => {
              // Soft handle scan failures (no-op to prevent console spam)
            }
          );
          
          scannerRef.current = scanner;
        } catch (err) {
          console.error("Camera scanner error:", err);
          showToast("Kamera tidak dapat diakses atau sedang digunakan.", "error");
          setIsCameraActive(false);
        }
      }, 300);

      return () => {
        clearTimeout(timer);
        if (scannerRef.current) {
          try {
            scannerRef.current.clear();
          } catch(e){}
        }
      };
    }
  }, [isCameraActive, selectedOrder]);

  // Handle scanned barcode (either camera, manual text, or quick click)
  const handleBarcodeScan = async (barcodeText: string) => {
    if (!selectedOrder) return;
    const cleanBarcode = barcodeText.trim();
    if (!cleanBarcode) return;

    // Find the book representing this barcode
    const matchedBook = buku.find(b => b.Barcode === cleanBarcode || b.KodeBuku === cleanBarcode);
    
    if (!matchedBook) {
      showToast(`Buku dengan Barcode ${cleanBarcode} tidak ditemukan dalam sistem sekolah!`, 'error');
      setManualBarcode('');
      return;
    }

    // Attempt dispatch
    const result = await dispatchBook(selectedOrder.NoPesanan, matchedBook.KodeBuku, 1);
    
    if (result.success) {
      // Refresh current selected order state to render update
      const updated = pesanan.find(p => p.NoPesanan === selectedOrder.NoPesanan);
      if (updated) {
        setSelectedOrder(updated);
      }
      showToast(result.message, result.completed ? 'success' : 'info');
    } else {
      showToast(result.message, 'error');
    }
    
    setManualBarcode('');
  };

  const handleManualSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    handleBarcodeScan(manualBarcode);
  };

  return (
    <div className="space-y-6 text-left font-sans">
      
      {/* PAGE HEADER */}
      <div>
        <h2 className="text-xl font-bold font-display text-brand-blue-900 flex items-center space-x-2">
          <Scan className="h-6 w-6 text-brand-gold-600" />
          <span>Pengeluaran & Penyerahan Buku Pelajaran</span>
        </h2>
        <p className="text-xs text-slate-500 mt-1">Scan barcode fisik pada buku pelajaran untuk memvalidasi pengambilan, mengurangi stok otomatis, dan menyelesaikan pesanan.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* LEFT COLUMN: ACTIVE LUNAS ORDERS SELECTOR (5 Cols) */}
        <div className="lg:col-span-5 bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-4">
          <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider border-b border-slate-100 pb-2.5 flex justify-between items-center">
            <span>Daftar Pesanan Lunas (Belum Ambil)</span>
            <span className="bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded font-extrabold text-[10px]">
              {activeOrders.length} Antrean
            </span>
          </h3>

          {/* Search box */}
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-4 w-4 text-slate-400" />
            </div>
            <input 
              type="text"
              value={orderSearch}
              onChange={(e) => setOrderSearch(e.target.value)}
              placeholder="Cari siswa atau No Pesanan..."
              className="w-full pl-9 pr-4 py-2 bg-slate-50 hover:bg-slate-100/50 focus:bg-white border border-slate-200 focus:border-brand-blue-600 rounded-lg text-xs font-semibold focus:outline-none transition-all"
            />
          </div>

          {/* Order list */}
          <div className="space-y-2 max-h-96 overflow-y-auto pr-1">
            {filteredOrders.length === 0 ? (
              <div className="text-center py-8 text-slate-400 font-bold text-xs">
                Tidak ada pesanan antrean lunas yang siap dikirim.
              </div>
            ) : (
              filteredOrders.map(p => {
                const is_selected = selectedOrder?.NoPesanan === p.NoPesanan;
                return (
                  <button
                    key={p.NoPesanan}
                    onClick={() => { setSelectedOrder(p); setIsCameraActive(false); }}
                    className={`w-full text-left p-3.5 rounded-xl border-2 transition-all flex justify-between items-center ${
                      is_selected 
                        ? 'border-brand-blue-800 bg-brand-blue-50/20 shadow-sm' 
                        : 'border-slate-100 hover:border-slate-200 bg-white'
                    }`}
                    id={`tu-scan-select-order-${p.NoPesanan}`}
                  >
                    <div>
                      <span className="text-xs font-mono font-bold text-slate-400 block">{p.NoPesanan}</span>
                      <span className="text-sm font-bold text-slate-800 block mt-0.5">{p.NamaSiswa}</span>
                      <span className="text-xs text-slate-500 font-semibold">Kelas {p.Kelas} | NIS: {p.NIS}</span>
                    </div>
                    <ChevronRight className={`h-5 w-5 ${is_selected ? 'text-brand-blue-800' : 'text-slate-300'}`} />
                  </button>
                );
              })
            )}
          </div>
        </div>

        {/* RIGHT COLUMN: DISPATCH CAMERA AND MANUAL CONTROLS (7 Cols) */}
        <div className="lg:col-span-7 space-y-6">
          <AnimatePresence mode="wait">
            
            {!selectedOrder ? (
              <motion.div 
                key="no-order-selected"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="bg-slate-100 border-2 border-dashed border-slate-300 rounded-2xl p-12 text-center text-slate-500 space-y-3"
              >
                <div className="h-16 w-16 bg-white rounded-full border border-slate-200 flex items-center justify-center mx-auto shadow-sm">
                  <Scan className="h-8 w-8 text-slate-400" />
                </div>
                <h4 className="font-extrabold text-sm text-slate-800 uppercase tracking-wide">Pilih Pesanan Terlebih Dahulu</h4>
                <p className="text-xs max-w-sm mx-auto">
                  Silakan pilih salah satu pesanan lunas di panel sebelah kiri untuk memulai penyerahan buku pelajaran fisik.
                </p>
              </motion.div>
            ) : (
              <motion.div
                key="order-selected"
                initial={{ opacity: 0, scale: 0.98 }}
                animate={{ opacity: 1, scale: 1 }}
                className="space-y-6"
              >
                {/* Active Student Info Header */}
                <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-4">
                  <div className="flex justify-between items-start border-b border-slate-100 pb-3">
                    <div>
                      <span className="text-xs font-mono font-bold text-slate-400 block">{selectedOrder.NoPesanan}</span>
                      <h4 className="text-md font-bold text-slate-900 flex items-center space-x-1.5 mt-0.5">
                        <User className="h-4.5 w-4.5 text-brand-blue-800 shrink-0" />
                        <span>{selectedOrder.NamaSiswa}</span>
                      </h4>
                      <p className="text-xs text-slate-500 font-semibold mt-0.5">NIS: {selectedOrder.NIS} | Kelas {selectedOrder.Kelas}</p>
                    </div>

                    <button 
                      onClick={() => { setSelectedOrder(null); setIsCameraActive(false); }}
                      className="text-[10px] font-extrabold text-rose-600 bg-rose-50 hover:bg-rose-100 px-2.5 py-1.5 rounded-lg transition"
                    >
                      Batal Pilih
                    </button>
                  </div>

                  {/* Ordered Items Progress bar list */}
                  <div className="space-y-3">
                    <span className="text-slate-400 uppercase tracking-wider text-[10px] font-bold block">Status Penyerahan Buku:</span>
                    <div className="space-y-2">
                      {getOrderItems(selectedOrder.NoPesanan).map((it, idx) => {
                        const scanned = selectedOrder.BukuScanned?.[it.KodeBuku] || 0;
                        const is_fully_scanned = scanned === it.Qty;
                        return (
                          <div key={idx} className="p-3.5 rounded-xl border border-slate-100 bg-slate-50 flex items-center justify-between text-xs font-bold gap-4">
                            <div>
                              <span className="text-slate-800 block">{it.NamaBuku}</span>
                              <span className="text-[10px] text-slate-400 mt-0.5 block font-semibold">
                                Kode: {it.KodeBuku} | Barcode: {buku.find(b => b.KodeBuku === it.KodeBuku)?.Barcode}
                              </span>
                            </div>

                            <span className={`px-2.5 py-1 rounded-lg shrink-0 text-[10px] font-extrabold ${
                              is_fully_scanned 
                                ? 'bg-emerald-100 text-emerald-800' 
                                : 'bg-amber-100 text-amber-800'
                            }`}>
                              {scanned} / {it.Qty} pcs diserahkan
                            </span>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>

                {/* DISPATCH CONTROLS (Camera or Simulator) */}
                <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-4 text-xs font-semibold text-slate-700">
                  <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wide border-b border-slate-100 pb-2.5">
                    Metode Scan & Validasi Barcode
                  </h3>

                  {/* CAMERA BARCODE ACTION */}
                  {isCameraActive ? (
                    <div className="space-y-4">
                      {/* html5-qrcode video anchor point */}
                      <div id="reader" className="overflow-hidden rounded-xl border border-slate-200 bg-slate-950 shadow-inner max-w-sm mx-auto"></div>
                      <button
                        type="button"
                        onClick={() => setIsCameraActive(false)}
                        className="w-full text-center bg-rose-600 hover:bg-rose-500 text-white font-bold py-2 rounded-xl"
                      >
                        Matikan Kamera Scanner
                      </button>
                    </div>
                  ) : (
                    <button
                      type="button"
                      onClick={() => setIsCameraActive(true)}
                      className="w-full bg-slate-50 hover:bg-slate-100 border-2 border-slate-200 p-4 rounded-xl flex flex-col items-center justify-center space-y-2 transition shadow-inner"
                      id="tu-scan-activate-camera"
                    >
                      <Camera className="h-7 w-7 text-brand-blue-800 animate-bounce" />
                      <span className="font-bold text-brand-blue-900">Nyalakan Kamera Webcam/HP</span>
                      <span className="text-[10px] text-slate-400">Scan barcode fisik langsung dari kamera</span>
                    </button>
                  )}

                  {/* MANUAL BARCODE CONTROLLER (Fallback / Simulator) */}
                  <div className="border-t border-slate-100 pt-4 space-y-4">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wide block">Emulator / Input Manual Barcode:</span>
                    
                    {/* Simulator buttons based on actual books in current order */}
                    <div className="space-y-2">
                      <span className="text-[10px] text-slate-400 block leading-none font-bold mb-1">KLIK DISINI UNTUK SIMULASI SCAN (SANGAT COCOK UNTUK DEMO):</span>
                      <div className="flex flex-wrap gap-2">
                        {getOrderItems(selectedOrder.NoPesanan).map((it, idx) => {
                          const bookBarcode = buku.find(b => b.KodeBuku === it.KodeBuku)?.Barcode || '';
                          const scannedCount = selectedOrder.BukuScanned?.[it.KodeBuku] || 0;
                          const completed = scannedCount === it.Qty;
                          return (
                            <button
                              key={idx}
                              type="button"
                              onClick={() => handleBarcodeScan(bookBarcode)}
                              disabled={completed}
                              className={`px-3 py-2 rounded-lg border text-[10px] font-bold inline-flex items-center space-x-1.5 transition ${
                                completed 
                                  ? 'bg-slate-100 border-slate-200 text-slate-400 cursor-not-allowed' 
                                  : 'bg-brand-gold-500/10 hover:bg-brand-gold-500/20 border-brand-gold-500/50 text-brand-gold-800'
                              }`}
                              id={`tu-simulator-scan-${it.KodeBuku}`}
                            >
                              <Play className="h-3 w-3 shrink-0" />
                              <span>Scan {it.KodeBuku} (BC: {bookBarcode})</span>
                            </button>
                          );
                        })}
                      </div>
                    </div>

                    {/* Manual text input search */}
                    <form onSubmit={handleManualSubmit} className="flex gap-2">
                      <input 
                        type="text"
                        value={manualBarcode}
                        onChange={(e) => setManualBarcode(e.target.value)}
                        placeholder="Ketik Barcode (misal: 899000101)..."
                        className="flex-1 px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs font-semibold focus:outline-none focus:border-brand-blue-600"
                        id="tu-scan-manual-input"
                      />
                      <button
                        type="submit"
                        className="bg-brand-blue-800 hover:bg-brand-blue-700 text-white font-bold px-4 rounded-lg"
                      >
                        Kirim
                      </button>
                    </form>
                  </div>
                </div>
              </motion.div>
            )}

          </AnimatePresence>
        </div>

      </div>
    </div>
  );
}
