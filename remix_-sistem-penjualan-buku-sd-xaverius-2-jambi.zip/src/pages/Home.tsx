/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { useApp } from '../contexts/AppContext';
import { Siswa, Buku, Pesanan, DetailPesanan } from '../types';
import { 
  BookOpen, 
  Search, 
  CheckCircle, 
  ShoppingBag, 
  User, 
  Phone, 
  FileText, 
  ArrowRight,
  Sparkles,
  CreditCard,
  Hash,
  ArrowLeft,
  ChevronRight,
  Printer
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function Home({ onGoToLogin }: { onGoToLogin: () => void }) {
  const { siswa, buku, addOrder, schoolSettings, pesanan, detailPesanan } = useApp();
  
  // Navigation states
  const [view, setView] = useState<'landing' | 'pesan' | 'sukses' | 'lacak'>('landing');
  
  // Order states
  const [selectedSiswa, setSelectedSiswa] = useState<Siswa | null>(null);
  const [siswaSearch, setSiswaSearch] = useState('');
  const [showSiswaSuggestions, setShowSiswaSuggestions] = useState(false);
  const [cart, setCart] = useState<{ [kodeBuku: string]: number }>({});
  const [latestOrder, setLatestOrder] = useState<Pesanan | null>(null);
  const [latestOrderItems, setLatestOrderItems] = useState<DetailPesanan[]>(null as any);
  
  // Track state
  const [trackQuery, setTrackQuery] = useState('');
  const [trackResult, setTrackResult] = useState<{ order: Pesanan; items: DetailPesanan[] } | null>(null);
  const [trackError, setTrackError] = useState('');

  // Auto-filtering books based on student's grade/class
  const getStudentGrade = (kelasName: string) => {
    // Extract first character (usually grade digit 1-6)
    const match = kelasName.match(/^[1-6]/);
    return match ? match[0] : '1';
  };

  const filteredBuku = selectedSiswa 
    ? buku.filter(b => b.Kelas === getStudentGrade(selectedSiswa.Kelas) && b.Status === 'AKTIF')
    : [];

  // Filter siswa suggestions
  const suggestedSiswa = siswaSearch.trim() === '' 
    ? [] 
    : siswa.filter(s => 
        s.Nama.toLowerCase().includes(siswaSearch.toLowerCase()) || 
        s.NIS.includes(siswaSearch)
      ).slice(0, 5);

  const handleSelectSiswa = (s: Siswa) => {
    setSelectedSiswa(s);
    setSiswaSearch(`${s.Nama} (${s.NIS} - Kelas ${s.Kelas})`);
    setShowSiswaSuggestions(false);
    // Reset cart when student changes
    setCart({});
  };

  const handleToggleCartItem = (kode: string, maxStok: number) => {
    if (cart[kode]) {
      const nextCart = { ...cart };
      delete nextCart[kode];
      setCart(nextCart);
    } else {
      if (maxStok <= 0) return; // out of stock
      setCart({ ...cart, [kode]: 1 });
    }
  };

  const handleQtyChange = (kode: string, val: number, maxStok: number) => {
    if (val < 1) return;
    if (val > maxStok) return;
    setCart({ ...cart, [kode]: val });
  };

  const calculateTotal = () => {
    let total = 0;
    Object.keys(cart).forEach(kode => {
      const book = buku.find(b => b.KodeBuku === kode);
      if (book) {
        total += book.Harga * cart[kode];
      }
    });
    return total;
  };

  const handlePesan = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedSiswa || Object.keys(cart).length === 0) return;

    // Generate unique order number
    const dateStr = new Date().toISOString().slice(0, 10).replace(/-/g, '');
    const randomNum = Math.floor(100 + Math.random() * 900);
    const noPesanan = `ORD-${dateStr}-${randomNum}`;
    
    const totalOrder = calculateTotal();
    const orderObj: Pesanan = {
      NoPesanan: noPesanan,
      Tanggal: new Date().toISOString().slice(0, 10),
      NamaSiswa: selectedSiswa.Nama,
      NIS: selectedSiswa.NIS,
      Kelas: selectedSiswa.Kelas,
      Total: totalOrder,
      Status: 'MENUNGGU PEMBAYARAN',
      Petugas: 'Sistem Mandiri',
      BukuScanned: {}
    };

    const itemsArray: DetailPesanan[] = Object.keys(cart).map(kode => {
      const b = buku.find(item => item.KodeBuku === kode)!;
      return {
        NoPesanan: noPesanan,
        KodeBuku: b.KodeBuku,
        NamaBuku: b.NamaBuku,
        Qty: cart[kode],
        Harga: b.Harga,
        Subtotal: b.Harga * cart[kode]
      };
    });

    await addOrder(orderObj, itemsArray);
    setLatestOrder(orderObj);
    setLatestOrderItems(itemsArray);
    setView('sukses');
  };

  const handleLacakPesanan = (e: React.FormEvent) => {
    e.preventDefault();
    setTrackError('');
    setTrackResult(null);

    const matchOrder = pesanan.find(
      p => p.NoPesanan.toLowerCase() === trackQuery.trim().toLowerCase() ||
           p.NIS === trackQuery.trim()
    );

    if (matchOrder) {
      const items = detailPesanan.filter(d => d.NoPesanan === matchOrder.NoPesanan);
      setTrackResult({ order: matchOrder, items });
    } else {
      setTrackError('Maaf, pesanan dengan Nomor Pesanan atau NIS tersebut tidak ditemukan.');
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col justify-between">
      
      {/* Navigation Header */}
      <nav className="bg-brand-blue-900 text-white shadow-md sticky top-0 z-40">
        <div className="max-w-6xl mx-auto px-4 py-3.5 flex justify-between items-center">
          <div className="flex items-center space-x-3 cursor-pointer" onClick={() => setView('landing')}>
            <img 
              src={schoolSettings.Logo} 
              alt="Logo Sekolah" 
              className="h-10 w-10 object-cover rounded bg-white p-0.5 border-2 border-brand-gold-400"
              referrerPolicy="no-referrer"
            />
            <div>
              <h1 className="text-sm font-bold tracking-tight font-display text-brand-gold-400">SD XAVERIUS 2 JAMBI</h1>
              <p className="text-[10px] text-slate-300 leading-none">PORTAL PENJUALAN BUKU PELAJARAN</p>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <button 
              onClick={() => { setView('lacak'); setTrackResult(null); setTrackQuery(''); }}
              className="text-xs font-semibold px-3 py-1.5 rounded-lg border border-brand-gold-500/50 hover:bg-brand-blue-800 text-brand-gold-400 transition"
            >
              Lacak Pesanan
            </button>
            <button 
              onClick={onGoToLogin}
              className="text-xs font-semibold bg-brand-gold-600 hover:bg-brand-gold-500 text-brand-blue-950 px-3 py-1.5 rounded-lg font-bold shadow-md transition"
            >
              Login Staff
            </button>
          </div>
        </div>
      </nav>

      {/* Main Container */}
      <main className="flex-1 max-w-6xl w-full mx-auto px-4 py-8 flex flex-col items-center justify-center">
        
        <AnimatePresence mode="wait">
          
          {/* LANDING VIEW */}
          {view === 'landing' && (
            <motion.div 
              key="landing"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              className="w-full grid grid-cols-1 md:grid-cols-12 gap-8 items-center py-6"
            >
              {/* Left Column Text details */}
              <div className="md:col-span-7 text-left space-y-6">
                <div className="inline-flex items-center space-x-2 bg-brand-blue-50 text-brand-blue-800 px-3 py-1.5 rounded-full text-xs font-semibold">
                  <Sparkles className="h-4 w-4 text-brand-gold-600" />
                  <span>Sistem Informasi Buku Kurikulum Merdeka</span>
                </div>
                
                <h1 className="text-3xl md:text-5xl font-bold font-display tracking-tight text-slate-900 leading-tight">
                  Pesan Buku Pelajaran Resmi <br />
                  <span className="text-brand-blue-700">SD Xaverius 2 Jambi</span>
                </h1>
                
                <p className="text-slate-600 text-sm md:text-base max-w-lg leading-relaxed">
                  Selamat datang di layanan resmi penjualan buku paket siswa SD Xaverius 2 Sipin, Kota Jambi. 
                  Sistem ini memudahkan Orang Tua/Wali Murid memesan buku pelajaran secara online, melacak status, 
                  dan mencetak bukti lunas setelah pembayaran di sekolah.
                </p>

                <div className="flex flex-col sm:flex-row gap-3 pt-2">
                  <button 
                    onClick={() => { setView('pesan'); setSelectedSiswa(null); setSiswaSearch(''); }}
                    className="flex items-center justify-center space-x-2 bg-brand-blue-800 hover:bg-brand-blue-700 text-white font-bold px-6 py-3.5 rounded-xl shadow-lg hover:shadow-xl transition-all"
                  >
                    <span>Pesan Buku Pelajaran</span>
                    <ArrowRight className="h-5 w-5 text-brand-gold-400" />
                  </button>
                  <button 
                    onClick={() => { setView('lacak'); setTrackResult(null); setTrackQuery(''); }}
                    className="flex items-center justify-center space-x-2 bg-white hover:bg-slate-100 border-2 border-slate-200 text-slate-700 font-bold px-6 py-3.5 rounded-xl transition-all"
                  >
                    <span>Cek Status Pesanan</span>
                  </button>
                </div>

                <div className="grid grid-cols-3 gap-4 pt-6 border-t border-slate-200 max-w-md">
                  <div>
                    <span className="block text-2xl font-bold text-brand-blue-900">100%</span>
                    <span className="text-xs text-slate-500">Buku Sesuai Kelas</span>
                  </div>
                  <div>
                    <span className="block text-2xl font-bold text-brand-blue-900">Online</span>
                    <span className="text-xs text-slate-500">Proses Cepat & Rapih</span>
                  </div>
                  <div>
                    <span className="block text-2xl font-bold text-brand-blue-900">Tata Usaha</span>
                    <span className="text-xs text-slate-500">Lokasi Ambil Buku</span>
                  </div>
                </div>
              </div>

              {/* Right Column Image banner */}
              <div className="md:col-span-5 relative flex justify-center">
                <div className="absolute inset-0 bg-brand-gold-400/20 rounded-3xl filter blur-3xl transform rotate-6 scale-95" />
                <div className="bg-white p-5 rounded-3xl shadow-xl relative border border-slate-200 w-full max-w-sm">
                  <img 
                    src="https://images.unsplash.com/photo-1503676260728-1c00da094a0b?w=500&auto=format&fit=crop&q=80" 
                    alt="Anak Sekolah SD" 
                    className="w-full h-48 object-cover rounded-2xl mb-4 shadow"
                    referrerPolicy="no-referrer"
                  />
                  <div className="space-y-3">
                    <h3 className="font-bold font-display text-slate-800 text-sm">PENGUMUMAN PENTING</h3>
                    <p className="text-[11px] text-slate-500 leading-relaxed">
                      Pengambilan buku fisik pelajaran Tahun Pelajaran {schoolSettings.TahunPelajaran} dilayani di ruangan Tata Usaha (TU) sekolah dengan membawa Bukti Pemesanan atau bukti transfer lunas.
                    </p>
                    <div className="bg-brand-blue-50 p-2.5 rounded-lg border border-brand-blue-100 flex items-center space-x-2">
                      <CreditCard className="h-4 w-4 text-brand-gold-600" />
                      <span className="text-[10px] font-bold text-brand-blue-900 uppercase">Bisa Tunai & Transfer</span>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          {/* ORDERING VIEW (PESAN) */}
          {view === 'pesan' && (
            <motion.div 
              key="pesan"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              className="w-full max-w-4xl"
            >
              {/* Back Link */}
              <button 
                onClick={() => setView('landing')}
                className="inline-flex items-center space-x-1.5 text-xs font-semibold text-slate-600 hover:text-brand-blue-900 mb-6 transition"
              >
                <ArrowLeft className="h-4 w-4" />
                <span>Kembali ke Halaman Utama</span>
              </button>

              <div className="bg-white rounded-2xl shadow-xl border border-slate-200 overflow-hidden">
                <div className="bg-brand-blue-900 text-white p-6">
                  <h2 className="text-xl font-bold font-display tracking-tight text-brand-gold-400">Pemesanan Buku Pelajaran Mandiri</h2>
                  <p className="text-xs text-slate-300 mt-1">Lengkapi data siswa untuk melihat buku yang sesuai dengan kelas kurikulum.</p>
                </div>

                <form onSubmit={handlePesan} className="p-6 md:p-8 space-y-8">
                  {/* Step 1: Input Nama Siswa Autocomplete */}
                  <div className="space-y-3">
                    <label className="text-xs font-bold text-slate-700 uppercase tracking-wide flex items-center space-x-1.5">
                      <User className="h-4 w-4 text-brand-blue-800" />
                      <span>Cari Nama Siswa (Wajib Terdaftar)</span>
                    </label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none">
                        <Search className="h-4 w-4 text-slate-400" />
                      </div>
                      <input 
                        type="text"
                        value={siswaSearch}
                        onChange={(e) => {
                          setSiswaSearch(e.target.value);
                          setShowSiswaSuggestions(true);
                          if (!e.target.value) {
                            setSelectedSiswa(null);
                          }
                        }}
                        onFocus={() => setShowSiswaSuggestions(true)}
                        placeholder="Ketik nama lengkap siswa atau NIS..."
                        className="w-full pl-10 pr-4 py-3 bg-slate-50 hover:bg-slate-100/50 focus:bg-white border-2 border-slate-200 focus:border-brand-blue-600 rounded-xl text-sm font-semibold text-slate-800 shadow-sm focus:outline-none transition-all"
                        required
                        id="parent-student-lookup"
                      />

                      {/* Suggestions list dropdown */}
                      {showSiswaSuggestions && suggestedSiswa.length > 0 && (
                        <div className="absolute z-50 left-0 right-0 mt-1.5 bg-white border border-slate-200 rounded-xl shadow-xl max-h-56 overflow-y-auto">
                          {suggestedSiswa.map(s => (
                            <button
                              key={s.NIS}
                              type="button"
                              onClick={() => handleSelectSiswa(s)}
                              className="w-full text-left px-4 py-3 hover:bg-brand-blue-50 flex items-center justify-between border-b border-slate-100 last:border-b-0"
                            >
                              <div>
                                <span className="text-sm font-semibold text-slate-800 block">{s.Nama}</span>
                                <span className="text-xs text-slate-500">NIS: {s.NIS} | Wali: {s.NamaOrtu}</span>
                              </div>
                              <span className="text-xs font-bold bg-brand-gold-500/15 text-brand-gold-700 px-2.5 py-1 rounded">
                                Kelas {s.Kelas}
                              </span>
                            </button>
                          ))}
                        </div>
                      )}
                    </div>

                    {/* Auto populated details */}
                    {selectedSiswa && (
                      <motion.div 
                        initial={{ opacity: 0, scale: 0.98 }}
                        animate={{ opacity: 1, scale: 1 }}
                        className="grid grid-cols-1 sm:grid-cols-3 gap-4 bg-slate-50 p-4 rounded-xl border border-slate-200 text-xs font-semibold text-slate-700"
                      >
                        <div>
                          <span className="text-slate-400 block mb-0.5">NAMA LENGKAP SISWA</span>
                          <span className="text-slate-800 font-bold text-sm">{selectedSiswa.Nama}</span>
                        </div>
                        <div>
                          <span className="text-slate-400 block mb-0.5">NOMOR INDUK SISWA (NIS)</span>
                          <span className="text-slate-800 font-mono text-sm">{selectedSiswa.NIS}</span>
                        </div>
                        <div>
                          <span className="text-slate-400 block mb-0.5">KELAS KURIKULUM</span>
                          <span className="text-brand-blue-800 font-extrabold text-sm">Kelas {selectedSiswa.Kelas}</span>
                        </div>
                      </motion.div>
                    )}
                  </div>

                  {/* Step 2: Book Selection Catalog matching pupil grade */}
                  {selectedSiswa && (
                    <motion.div 
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      className="space-y-4 pt-4 border-t border-slate-100"
                    >
                      <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wide flex items-center space-x-1.5">
                        <BookOpen className="h-4 w-4 text-brand-blue-800" />
                        <span>Katalog Buku Kelas {getStudentGrade(selectedSiswa.Kelas)}</span>
                      </h3>

                      {filteredBuku.length === 0 ? (
                        <div className="bg-amber-50 p-6 rounded-xl border border-amber-200 text-center text-sm text-amber-800 font-medium">
                          Belum ada buku pelajaran yang diaktifkan untuk kelas ini. Hubungi pihak sekolah.
                        </div>
                      ) : (
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          {filteredBuku.map(b => {
                            const inCart = !!cart[b.KodeBuku];
                            const selectedQty = cart[b.KodeBuku] || 1;
                            return (
                              <div 
                                key={b.KodeBuku}
                                className={`p-4 rounded-xl border-2 flex items-center space-x-4 transition-all bg-white ${
                                  inCart 
                                    ? 'border-brand-blue-700 bg-brand-blue-50/20 shadow-md' 
                                    : 'border-slate-200 hover:border-slate-300'
                                }`}
                              >
                                {/* Checkbox click area */}
                                <button
                                  type="button"
                                  onClick={() => handleToggleCartItem(b.KodeBuku, b.Stok)}
                                  className={`h-5 w-5 rounded border flex items-center justify-center transition-colors shrink-0 ${
                                    inCart 
                                      ? 'bg-brand-blue-800 border-brand-blue-800 text-white' 
                                      : 'border-slate-300 hover:border-slate-400 bg-white'
                                  }`}
                                  disabled={b.Stok <= 0}
                                >
                                  {inCart && <CheckCircle className="h-4 w-4" />}
                                </button>

                                {/* Cover image */}
                                <img 
                                  src={b.Foto || 'https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=400&auto=format&fit=crop&q=60'} 
                                  alt="Cover Buku" 
                                  className="h-14 w-11 object-cover rounded shadow-sm border border-slate-200 shrink-0"
                                  referrerPolicy="no-referrer"
                                />

                                {/* Info */}
                                <div className="flex-1 min-w-0 text-left">
                                  <h4 className="text-xs font-bold text-slate-800 truncate">{b.NamaBuku}</h4>
                                  <p className="text-[11px] text-slate-400 mt-0.5">Kategori: {b.Kategori}</p>
                                  <p className="text-xs font-extrabold text-brand-blue-800 mt-1">
                                    Rp {b.Harga.toLocaleString('id-ID')}
                                  </p>
                                  
                                  {/* Stock indicator */}
                                  <span className={`text-[10px] inline-block font-bold mt-1 px-2 py-0.5 rounded ${
                                    b.Stok > 10 
                                      ? 'bg-emerald-100 text-emerald-800' 
                                      : b.Stok > 0 
                                        ? 'bg-amber-100 text-amber-800' 
                                        : 'bg-rose-100 text-rose-800'
                                  }`}>
                                    {b.Stok > 0 ? `Sisa Stok: ${b.Stok} pcs` : 'Habis (Preorder)'}
                                  </span>
                                </div>

                                {/* Quantity Trigger if checked */}
                                {inCart && (
                                  <div className="flex items-center space-x-1 bg-slate-100 p-1 rounded-lg shrink-0">
                                    <button 
                                      type="button"
                                      onClick={() => handleQtyChange(b.KodeBuku, selectedQty - 1, b.Stok)}
                                      className="h-6 w-6 rounded hover:bg-white text-xs font-extrabold text-slate-600 transition"
                                    >
                                      -
                                    </button>
                                    <span className="w-6 text-center text-xs font-bold text-slate-800">{selectedQty}</span>
                                    <button 
                                      type="button"
                                      onClick={() => handleQtyChange(b.KodeBuku, selectedQty + 1, b.Stok)}
                                      className="h-6 w-6 rounded hover:bg-white text-xs font-extrabold text-slate-600 transition"
                                    >
                                      +
                                    </button>
                                  </div>
                                )}
                              </div>
                            );
                          })}
                        </div>
                      )}
                    </motion.div>
                  )}

                  {/* Step 3: Shopping Cart Summary and Submit Button */}
                  {selectedSiswa && Object.keys(cart).length > 0 && (
                    <motion.div 
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="pt-6 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-4"
                    >
                      <div className="text-left">
                        <span className="text-xs text-slate-400 font-semibold uppercase">TOTAL BUKU DIPESAN</span>
                        <div className="flex items-baseline space-x-1.5 mt-0.5">
                          <span className="text-2xl font-bold font-display text-slate-900">
                            Rp {calculateTotal().toLocaleString('id-ID')}
                          </span>
                          <span className="text-xs text-slate-500">
                            ({Object.keys(cart).length} buku)
                          </span>
                        </div>
                      </div>

                      <button
                        type="submit"
                        className="w-full sm:w-auto flex items-center justify-center space-x-2 bg-brand-blue-800 hover:bg-brand-blue-700 text-white font-bold px-8 py-3.5 rounded-xl shadow-lg hover:shadow-xl transition-all"
                        id="parent-submit-order"
                      >
                        <ShoppingBag className="h-5 w-5 text-brand-gold-400" />
                        <span>Kirim Pemesanan Sekarang</span>
                      </button>
                    </motion.div>
                  )}
                </form>
              </div>
            </motion.div>
          )}

          {/* SUCCESS SCREEN */}
          {view === 'sukses' && latestOrder && (
            <motion.div 
              key="sukses"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="w-full max-w-2xl bg-white rounded-3xl shadow-xl border border-slate-200 overflow-hidden"
            >
              <div className="bg-emerald-600 text-white p-8 text-center space-y-3">
                <div className="h-16 w-16 bg-white/20 rounded-full flex items-center justify-center mx-auto shadow-inner">
                  <CheckCircle className="h-10 w-10 text-white" />
                </div>
                <h2 className="text-2xl font-bold font-display text-brand-gold-400">Pemesanan Berhasil Terkirim!</h2>
                <p className="text-xs text-emerald-100 max-w-md mx-auto">
                  Nomor Pesanan Anda telah dibuat secara otomatis. Simpan rincian di bawah ini untuk ditunjukkan ke petugas TU.
                </p>
              </div>

              <div className="p-6 md:p-8 space-y-6">
                {/* Order specifics */}
                <div className="bg-slate-50 rounded-2xl p-5 border border-slate-200 space-y-4 text-xs font-semibold text-slate-700">
                  <div className="flex items-center justify-between border-b border-slate-200 pb-3">
                    <span className="text-slate-400 uppercase">Nomor Pesanan (Order ID)</span>
                    <span className="text-brand-blue-900 font-mono text-base font-extrabold">{latestOrder.NoPesanan}</span>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <span className="text-slate-400 block mb-0.5">NAMA SISWA</span>
                      <span className="text-slate-800 text-sm font-bold">{latestOrder.NamaSiswa}</span>
                    </div>
                    <div>
                      <span className="text-slate-400 block mb-0.5">NIS / KELAS</span>
                      <span className="text-slate-800 text-sm font-bold">{latestOrder.NIS} / Kelas {latestOrder.Kelas}</span>
                    </div>
                  </div>

                  <div className="border-t border-slate-200 pt-3 flex justify-between items-center">
                    <span className="text-slate-400">TOTAL PEMBAYARAN</span>
                    <span className="text-lg font-bold text-slate-900">Rp {latestOrder.Total.toLocaleString('id-ID')}</span>
                  </div>
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-slate-400">STATUS PESANAN</span>
                    <span className="bg-amber-100 text-amber-800 px-3 py-1 rounded-full font-bold">
                      {latestOrder.Status}
                    </span>
                  </div>
                </div>

                {/* Next Steps for parents */}
                <div className="space-y-3 text-left">
                  <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wide">LANGKAH SELANJUTNYA:</h4>
                  <ul className="space-y-2 text-xs text-slate-600 list-disc pl-4 leading-relaxed">
                    <li>Sampaikan **Nomor Pesanan** ini ke petugas Tata Usaha (TU) Sipin, Jambi.</li>
                    <li>Lakukan pembayaran sebesar **Rp {latestOrder.Total.toLocaleString('id-ID')}** tunai di sekolah, atau transfer bank.</li>
                    <li>Setelah lunas, petugas TU akan mengonfirmasi status pesanan Anda menjadi **LUNAS** dan menyerahkan buku pelajaran fisik yang dipesan.</li>
                  </ul>
                </div>

                {/* Print and Actions */}
                <div className="flex flex-col sm:flex-row gap-3 pt-4 border-t border-slate-100">
                  <button
                    onClick={() => window.print()}
                    className="flex-1 flex items-center justify-center space-x-2 border-2 border-slate-200 text-slate-700 hover:bg-slate-50 font-semibold py-3 rounded-xl transition"
                  >
                    <Printer className="h-4.5 w-4.5" />
                    <span>Cetak Bukti Pemesanan</span>
                  </button>
                  <button
                    onClick={() => setView('landing')}
                    className="flex-1 flex items-center justify-center bg-brand-blue-800 hover:bg-brand-blue-700 text-white font-bold py-3 rounded-xl transition"
                  >
                    <span>Selesai (Halaman Utama)</span>
                  </button>
                </div>
              </div>
            </motion.div>
          )}

          {/* LACHAK PESANAN (TRACK) */}
          {view === 'lacak' && (
            <motion.div 
              key="lacak"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              className="w-full max-w-2xl"
            >
              {/* Back Link */}
              <button 
                onClick={() => setView('landing')}
                className="inline-flex items-center space-x-1.5 text-xs font-semibold text-slate-600 hover:text-brand-blue-900 mb-6 transition"
              >
                <ArrowLeft className="h-4 w-4" />
                <span>Kembali ke Halaman Utama</span>
              </button>

              <div className="bg-white rounded-2xl shadow-xl border border-slate-200 overflow-hidden">
                <div className="bg-brand-blue-900 text-white p-6">
                  <h2 className="text-xl font-bold font-display tracking-tight text-brand-gold-400">Lacak Status Pesanan Buku</h2>
                  <p className="text-xs text-slate-300 mt-1">Masukkan Nomor Pesanan (misal: ORD-20260627-001) atau NIS Siswa.</p>
                </div>

                <div className="p-6 md:p-8 space-y-6">
                  <form onSubmit={handleLacakPesanan} className="flex gap-2">
                    <input 
                      type="text"
                      value={trackQuery}
                      onChange={(e) => setTrackQuery(e.target.value)}
                      placeholder="Contoh: ORD-20260627-001 atau 10203001"
                      className="flex-1 px-4 py-3 bg-slate-50 hover:bg-slate-100/50 focus:bg-white border-2 border-slate-200 focus:border-brand-blue-600 rounded-xl text-sm font-semibold text-slate-800 focus:outline-none transition-all"
                      required
                      id="parent-track-query"
                    />
                    <button
                      type="submit"
                      className="bg-brand-blue-800 hover:bg-brand-blue-700 text-white px-6 rounded-xl font-bold text-xs"
                    >
                      Cari Pesanan
                    </button>
                  </form>

                  {trackError && (
                    <div className="bg-rose-50 border border-rose-200 text-rose-800 p-4 rounded-xl text-xs font-semibold text-center">
                      {trackError}
                    </div>
                  )}

                  {/* Search Result */}
                  {trackResult && (
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="border border-slate-200 rounded-2xl overflow-hidden text-xs font-semibold"
                    >
                      <div className="bg-slate-50 px-4 py-3 border-b border-slate-200 flex justify-between items-center">
                        <span className="text-slate-500 font-mono">{trackResult.order.NoPesanan}</span>
                        <span className={`px-2.5 py-1 rounded text-[10px] font-extrabold ${
                          trackResult.order.Status === 'LUNAS' 
                            ? 'bg-emerald-100 text-emerald-800' 
                            : trackResult.order.Status === 'SELESAI'
                              ? 'bg-blue-100 text-blue-800'
                              : 'bg-amber-100 text-amber-800'
                        }`}>
                          {trackResult.order.Status}
                        </span>
                      </div>

                      <div className="p-4 space-y-4 text-left text-slate-700">
                        <div className="grid grid-cols-2 gap-3 text-xs">
                          <div>
                            <span className="text-slate-400 block text-[10px]">NAMA SISWA</span>
                            <span className="font-bold">{trackResult.order.NamaSiswa}</span>
                          </div>
                          <div>
                            <span className="text-slate-400 block text-[10px]">NIS / KELAS</span>
                            <span className="font-bold">{trackResult.order.NIS} / Kelas {trackResult.order.Kelas}</span>
                          </div>
                        </div>

                        {/* Items in order */}
                        <div className="border-t border-slate-100 pt-3 space-y-2">
                          <span className="text-slate-400 block text-[10px]">DAFTAR BUKU YANG DIPESAN</span>
                          {trackResult.items.map((it, idx) => (
                            <div key={idx} className="flex justify-between items-center py-1 border-b border-slate-50 last:border-b-0">
                              <span>{it.NamaBuku} <span className="text-slate-400">(x{it.Qty})</span></span>
                              <span className="font-bold text-slate-800">Rp {it.Subtotal.toLocaleString('id-ID')}</span>
                            </div>
                          ))}
                        </div>

                        <div className="border-t border-slate-100 pt-3 flex justify-between items-center">
                          <span className="text-slate-500">TOTAL AKHIR</span>
                          <span className="text-sm font-bold text-brand-blue-800">Rp {trackResult.order.Total.toLocaleString('id-ID')}</span>
                        </div>
                      </div>
                    </motion.div>
                  )}
                </div>
              </div>
            </motion.div>
          )}

        </AnimatePresence>
      </main>

      {/* Modern footer with school credits */}
      <footer className="bg-brand-blue-950 text-slate-400 py-6 border-t border-brand-blue-900 text-xs">
        <div className="max-w-6xl mx-auto px-4 text-center space-y-2">
          <p>© 2026 SD Xaverius 2 Jambi, Kota Jambi _ TU - Sy</p>
          <p className="text-[11px] text-slate-500">Sistem terhubung terpusat secara real-time dengan Tata Usaha sekolah melalui Google Apps Script & Google Sheets.</p>
        </div>
      </footer>
    </div>
  );
}
