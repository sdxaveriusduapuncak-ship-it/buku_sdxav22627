/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useApp } from '../contexts/AppContext';
import { 
  Database, 
  Link, 
  RefreshCw, 
  Copy, 
  Trash2, 
  Save, 
  Check, 
  AlertCircle,
  Code,
  ArrowUpRight,
  Info,
  LogIn,
  LogOut,
  CheckCircle2,
  FileSpreadsheet
} from 'lucide-react';
import { GOOGLE_APPS_SCRIPT_CODE } from '../data';
import { extractSpreadsheetId } from '../utils/googleSheetsApi';

export default function AdminSync() {
  const { 
    config, 
    saveConfig, 
    syncWithGoogleSheets, 
    clearAndResetLocal, 
    showToast,
    googleUser,
    googleToken,
    connectGoogle,
    disconnectGoogle,
    initializeSheetsInSpreadsheet
  } = useApp();
  
  // Local config states
  const [syncMode, setSyncMode] = useState<'direct' | 'gas'>(config.syncMode || 'direct');
  const [googleSpreadsheetId, setGoogleSpreadsheetId] = useState(config.googleSpreadsheetId || '1Ff5ru5DPHxDoHERc38ukdHtPW7XedLU2bGJp3f7g1hE');
  const [gasUrl, setGasUrl] = useState(config.gasUrl || '');
  const [isLiveMode, setIsLiveMode] = useState(config.isLiveMode || false);
  
  // States
  const [isCopied, setIsCopied] = useState(false);
  const [syncLoading, setSyncLoading] = useState<'pull' | 'push' | 'test' | 'init' | null>(null);

  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Extract Spreadsheet ID if a full link was pasted
    const cleanedSpreadsheetId = extractSpreadsheetId(googleSpreadsheetId.trim()) || googleSpreadsheetId.trim();

    saveConfig({ 
      syncMode,
      googleSpreadsheetId: cleanedSpreadsheetId,
      gasUrl: gasUrl.trim(), 
      isLiveMode 
    });
  };

  const handleInitializeSpreadsheet = async () => {
    setSyncLoading('init');
    const res = await initializeSheetsInSpreadsheet();
    setSyncLoading(null);
    if (res.success) {
      showToast(res.message, 'success');
    } else {
      showToast(res.message, 'error');
    }
  };

  const handleTestConnection = async () => {
    if (syncMode === 'gas') {
      if (!gasUrl.trim()) {
        showToast('Masukkan URL Apps Script terlebih dahulu!', 'error');
        return;
      }
      setSyncLoading('test');
      try {
        const response = await fetch(`${gasUrl.trim()}?action=getSiswa`, { method: 'GET' });
        const resData = await response.json();
        if (resData.success) {
          showToast('Koneksi sukses! REST API Google Sheets terhubung dengan sempurna.', 'success');
        } else {
          showToast(`Koneksi gagal: ${resData.message || 'Respons tidak valid'}`, 'error');
        }
      } catch (err: any) {
        console.warn('Test connection warning:', err);
        showToast('Koneksi selesai! (Verifikasi: Cek apakah data termuat dengan baik)', 'info');
      } finally {
        setSyncLoading(null);
      }
    } else {
      // For direct mode, testing connection means verifying the sheet is accessible
      if (!googleToken) {
        showToast('Akun Google belum terhubung! Hubungkan akun Anda terlebih dahulu.', 'error');
        return;
      }
      setSyncLoading('test');
      try {
        const spreadId = extractSpreadsheetId(googleSpreadsheetId) || googleSpreadsheetId;
        const res = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${spreadId}`, {
          headers: {
            Authorization: `Bearer ${googleToken}`
          }
        });
        if (res.ok) {
          showToast('Koneksi sukses! Spreadsheet Google Sheets dapat diakses secara langsung.', 'success');
        } else {
          const errData = await res.json();
          showToast(`Koneksi gagal: ${errData.error?.message || 'Spreadsheet tidak ditemukan atau tidak memiliki akses'}`, 'error');
        }
      } catch (err: any) {
        showToast(`Koneksi gagal: ${err.message || err}`, 'error');
      } finally {
        setSyncLoading(null);
      }
    }
  };

  const handleSyncAction = async (action: 'pull' | 'push') => {
    if (syncMode === 'gas' && !config.gasUrl) {
      showToast('Konfigurasi URL Web App belum disimpan!', 'error');
      return;
    }

    const conf = confirm(
      action === 'pull'
        ? 'Tarik Data akan mengganti data lokal Anda dengan data dari Google Sheet. Lanjutkan?'
        : 'Unggah Data akan menimpa data di Google Sheet dengan data lokal Anda saat ini. Lanjutkan?'
    );

    if (!conf) return;

    setSyncLoading(action);
    const result = await syncWithGoogleSheets(action);
    setSyncLoading(null);

    if (result.success) {
      showToast(result.message, 'success');
    } else {
      showToast(result.message, 'error');
    }
  };

  const handleCopyCode = () => {
    navigator.clipboard.writeText(GOOGLE_APPS_SCRIPT_CODE);
    setIsCopied(true);
    showToast('Kode Google Apps Script disalin ke clipboard!', 'success');
    setTimeout(() => {
      setIsCopied(false);
    }, 3000);
  };

  const handleResetDB = () => {
    const doubleCheck = confirm('⚠️ PERINGATAN: Ini akan menghapus semua perubahan lokal, pesanan baru, pembayaran, dan mengembalikan setelan default SD Xaverius 2 Jambi. Lanjutkan?');
    if (doubleCheck) {
      clearAndResetLocal();
      setGasUrl('');
      setGoogleSpreadsheetId('1Ff5ru5DPHxDoHERc38ukdHtPW7XedLU2bGJp3f7g1hE');
      setSyncMode('direct');
      setIsLiveMode(false);
    }
  };

  return (
    <div className="space-y-6 text-left font-sans">
      
      {/* PAGE HEADER */}
      <div>
        <h2 className="text-xl font-bold font-display text-brand-blue-900 flex items-center space-x-2">
          <Database className="h-6 w-6 text-brand-gold-600" />
          <span>Integrasi Google Sheets & Cloud Sync</span>
        </h2>
        <p className="text-xs text-slate-500 mt-1">Konfigurasikan integrasi Google Sheets langsung (Direct REST API) menggunakan akun Google Anda atau menggunakan custom Google Apps Script.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* LEFT PANEL: CONFIGURATION & MANUAL SYNC (6 Cols) */}
        <div className="lg:col-span-7 space-y-6">
          
          {/* API SETTINGS FORM */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-5">
            <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wide border-b border-slate-100 pb-2.5 flex items-center space-x-1.5">
              <Link className="h-4 w-4 text-brand-blue-800" />
              <span>Metode Sinkronisasi Database</span>
            </h3>

            {/* SYNC MODE SELECTOR BUTTONS */}
            <div className="grid grid-cols-2 gap-2 p-1 bg-slate-100 rounded-xl">
              <button
                type="button"
                onClick={() => setSyncMode('direct')}
                className={`py-2 px-3 text-xs font-bold rounded-lg transition-all ${syncMode === 'direct' ? 'bg-white text-brand-blue-900 shadow-sm' : 'text-slate-500 hover:text-slate-800'}`}
              >
                Direct Sheets API (Rekomendasi)
              </button>
              <button
                type="button"
                onClick={() => setSyncMode('gas')}
                className={`py-2 px-3 text-xs font-bold rounded-lg transition-all ${syncMode === 'gas' ? 'bg-white text-brand-blue-900 shadow-sm' : 'text-slate-500 hover:text-slate-800'}`}
              >
                Google Apps Script (GAS)
              </button>
            </div>

            {/* DIRECT MODE CONTENT */}
            {syncMode === 'direct' && (
              <div className="space-y-4">
                {/* Google Sign In status */}
                <div className="p-4 rounded-xl border border-slate-150 bg-slate-50/50 flex flex-col md:flex-row md:items-center justify-between gap-3">
                  <div>
                    <span className="text-xs font-bold text-slate-800 block">Koneksi Akun Google</span>
                    {googleUser ? (
                      <div className="flex items-center space-x-2 mt-1">
                        <div className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse" />
                        <span className="text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-100">
                          Tersambung: {googleUser.email}
                        </span>
                      </div>
                    ) : (
                      <span className="text-[11px] text-slate-500 font-medium block mt-1">
                        Hubungkan akun Google Anda untuk mengakses Spreadsheet secara instan.
                      </span>
                    )}
                  </div>

                  {googleUser ? (
                    <button
                      type="button"
                      onClick={disconnectGoogle}
                      className="px-3 py-1.5 bg-rose-50 hover:bg-rose-100 border border-rose-200 text-rose-700 font-bold rounded-lg text-[10px] transition flex items-center space-x-1"
                    >
                      <LogOut className="h-3 w-3" />
                      <span>Putuskan Akun</span>
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={connectGoogle}
                      className="px-4 py-2 bg-brand-blue-800 hover:bg-brand-blue-700 text-white font-bold rounded-lg text-xs transition shadow flex items-center space-x-1.5"
                    >
                      <LogIn className="h-4 w-4 text-brand-gold-400" />
                      <span>Hubungkan Akun Google</span>
                    </button>
                  )}
                </div>

                <form onSubmit={handleSaveSettings} className="space-y-4 text-xs font-semibold text-slate-700">
                  {/* Spreadsheet ID Input */}
                  <div className="space-y-1">
                    <label className="text-slate-500 uppercase flex items-center justify-between">
                      <span>Google Spreadsheet ID atau Link</span>
                      <span className="text-[10px] text-slate-400 lowercase italic">Bisa di-paste URL spreadsheet lengkap</span>
                    </label>
                    <input 
                      type="text"
                      value={googleSpreadsheetId}
                      onChange={(e) => setGoogleSpreadsheetId(e.target.value)}
                      placeholder="Masukkan ID Spreadsheet atau Link lengkap..."
                      className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 focus:border-brand-blue-600 focus:bg-white rounded-lg font-mono text-xs focus:outline-none transition-all"
                    />
                    {googleSpreadsheetId && (
                      <div className="text-[10px] text-slate-400 mt-1 font-medium leading-relaxed flex items-center space-x-1">
                        <FileSpreadsheet className="h-3 w-3 text-emerald-600 flex-shrink-0" />
                        <span className="truncate">
                          Tautan Aktif:{' '}
                          <a 
                            href={`https://docs.google.com/spreadsheets/d/${extractSpreadsheetId(googleSpreadsheetId) || googleSpreadsheetId}/edit`} 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="text-brand-blue-800 underline hover:text-brand-blue-600"
                          >
                            Buka di Google Sheets &rarr;
                          </a>
                        </span>
                      </div>
                    )}
                  </div>

                  {/* Table Initializer button */}
                  {googleUser && (
                    <div className="p-3 bg-emerald-50/50 border border-emerald-100 rounded-xl space-y-2">
                      <div className="flex items-start space-x-2 text-[11px] text-emerald-800 font-medium leading-relaxed">
                        <CheckCircle2 className="h-4 w-4 text-emerald-600 mt-0.5 flex-shrink-0" />
                        <div>
                          <span className="font-bold block text-emerald-900">Inisialisasi Tabel Spreadsheet Otomatis</span>
                          Klik tombol di bawah untuk membuat seluruh lembar tabel database (Siswa, Buku, Pesanan, dll.) lengkap dengan kolom baris pertamanya secara instan di spreadsheet baru Anda!
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={handleInitializeSpreadsheet}
                        disabled={syncLoading !== null}
                        className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-lg text-[11px] transition shadow flex items-center space-x-1 cursor-pointer"
                      >
                        {syncLoading === 'init' ? 'Sedang Membuat...' : 'Inisialisasi Semua Tabel (Recommended)'}
                      </button>
                    </div>
                  )}

                  {/* Toggle Switch */}
                  <div className="flex items-center justify-between p-3 rounded-xl bg-slate-50 border border-slate-200">
                    <div>
                      <span className="text-xs font-bold text-slate-800 block">Aktifkan Database Live</span>
                      <span className="text-[10px] text-slate-400 block mt-0.5 font-medium">Transaksi dan update data akan disinkronkan secara real-time</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => setIsLiveMode(!isLiveMode)}
                      className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                        isLiveMode ? 'bg-brand-blue-800' : 'bg-slate-300'
                      }`}
                    >
                      <span
                        className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
                          isLiveMode ? 'translate-x-5' : 'translate-x-0'
                        }`}
                      />
                    </button>
                  </div>

                  {/* Form Actions */}
                  <div className="flex justify-end space-x-2 pt-2">
                    <button
                      type="button"
                      onClick={handleTestConnection}
                      disabled={syncLoading !== null}
                      className="px-4 py-2 border border-slate-200 text-slate-700 hover:bg-slate-50 rounded-lg text-xs font-bold transition cursor-pointer"
                    >
                      {syncLoading === 'test' ? 'Menguji...' : 'Uji Akses Spreadsheet'}
                    </button>
                    <button
                      type="submit"
                      className="px-5 py-2 bg-brand-blue-800 hover:bg-brand-blue-700 text-white font-bold rounded-lg shadow flex items-center space-x-1.5 cursor-pointer"
                    >
                      <Save className="h-4 w-4 text-brand-gold-400" />
                      <span>Simpan Konfigurasi</span>
                    </button>
                  </div>
                </form>
              </div>
            )}

            {/* GAS MODE CONTENT */}
            {syncMode === 'gas' && (
              <div className="space-y-4">
                <form onSubmit={handleSaveSettings} className="space-y-4 text-xs font-semibold text-slate-700">
                  {/* Endpoint Input */}
                  <div className="space-y-1">
                    <label className="text-slate-500 uppercase">Google Apps Script Web App URL</label>
                    <input 
                      type="url"
                      value={gasUrl}
                      onChange={(e) => setGasUrl(e.target.value)}
                      placeholder="https://script.google.com/macros/s/AKfyby.../exec"
                      className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 focus:border-brand-blue-600 focus:bg-white rounded-lg font-mono text-xs focus:outline-none transition-all"
                    />
                  </div>

                  {/* Toggle Switch */}
                  <div className="flex items-center justify-between p-3 rounded-xl bg-slate-50 border border-slate-200">
                    <div>
                      <span className="text-xs font-bold text-slate-800 block">Aktifkan Database Live</span>
                      <span className="text-[10px] text-slate-400 block mt-0.5 font-medium">Kirim perubahan data langsung ke Apps Script API</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => setIsLiveMode(!isLiveMode)}
                      className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                        isLiveMode ? 'bg-brand-blue-800' : 'bg-slate-300'
                      }`}
                    >
                      <span
                        className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
                          isLiveMode ? 'translate-x-5' : 'translate-x-0'
                        }`}
                      />
                    </button>
                  </div>

                  {/* Form Actions */}
                  <div className="flex justify-end space-x-2 pt-2">
                    <button
                      type="button"
                      onClick={handleTestConnection}
                      disabled={syncLoading !== null}
                      className="px-4 py-2 border border-slate-200 text-slate-700 hover:bg-slate-50 rounded-lg text-xs font-bold transition cursor-pointer"
                    >
                      {syncLoading === 'test' ? 'Menguji...' : 'Uji Koneksi GAS'}
                    </button>
                    <button
                      type="submit"
                      className="px-5 py-2 bg-brand-blue-800 hover:bg-brand-blue-700 text-white font-bold rounded-lg shadow flex items-center space-x-1.5 cursor-pointer"
                    >
                      <Save className="h-4 w-4 text-brand-gold-400" />
                      <span>Simpan Konfigurasi</span>
                    </button>
                  </div>
                </form>
              </div>
            )}
          </div>

          {/* CLOUD DATA SYNCHRONIZATION TOOLS */}
          {(syncMode === 'direct' ? googleUser : config.gasUrl) && (
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-4">
              <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wide border-b border-slate-100 pb-2.5 flex items-center space-x-1.5">
                <RefreshCw className="h-4 w-4 text-brand-blue-800" />
                <span>Alat Sinkronisasi Awan (Cloud Sync)</span>
              </h3>

              <div className="grid grid-cols-2 gap-3 text-xs">
                {/* Pull Button */}
                <button
                  onClick={() => handleSyncAction('pull')}
                  disabled={syncLoading !== null}
                  className="p-4 rounded-xl border border-slate-200 hover:bg-slate-50 flex flex-col items-center justify-center space-y-2 transition shadow-xs group cursor-pointer"
                >
                  <RefreshCw className={`h-6 w-6 text-brand-blue-800 ${syncLoading === 'pull' ? 'animate-spin' : 'group-hover:rotate-180 transition-transform'}`} />
                  <span className="font-bold text-slate-800">Tarik Data (PULL)</span>
                  <span className="text-[10px] text-slate-400 text-center leading-relaxed font-medium">Ganti database lokal dengan isi Google Sheet terbaru</span>
                </button>

                {/* Push Button */}
                <button
                  onClick={() => handleSyncAction('push')}
                  disabled={syncLoading !== null}
                  className="p-4 rounded-xl border border-slate-200 hover:bg-slate-50 flex flex-col items-center justify-center space-y-2 transition shadow-xs group cursor-pointer"
                >
                  <ArrowUpRight className={`h-6 w-6 text-brand-gold-600 ${syncLoading === 'push' ? 'animate-bounce' : ''}`} />
                  <span className="font-bold text-slate-800">Unggah Data (PUSH)</span>
                  <span className="text-[10px] text-slate-400 text-center leading-relaxed font-medium">Kirim database lokal untuk menimpa semua data Google Sheet</span>
                </button>
              </div>
            </div>
          )}

          {/* DANGEROUS SYSTEM SETTINGS */}
          <div className="bg-white p-5 rounded-2xl border border-red-100 shadow-sm space-y-3">
            <h3 className="text-xs font-bold text-rose-800 uppercase tracking-wide border-b border-red-50 pb-2.5 flex items-center space-x-1.5">
              <Trash2 className="h-4.5 w-4.5 text-rose-600" />
              <span>Setelan Bahaya (Danger Zone)</span>
            </h3>
            <p className="text-[11px] text-slate-500 leading-relaxed font-medium">
              Jika data lokal Anda kotor atau Anda ingin menghapus semua uji coba untuk demonstrasi bersih sekolah, gunakan tombol di bawah untuk menyetel ulang database lokal.
            </p>
            <button
              onClick={handleResetDB}
              className="w-full text-center bg-rose-50 hover:bg-rose-100 border border-rose-200 text-rose-700 font-bold py-2.5 rounded-xl text-xs transition cursor-pointer"
            >
              Kembalikan ke Setelan Awal Pabrik
            </button>
          </div>

        </div>

        {/* RIGHT PANEL: GUIDE (5 Cols) */}
        <div className="lg:col-span-5 bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-4">
          <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wide border-b border-slate-100 pb-2.5 flex items-center space-x-1.5">
            <Info className="h-4.5 w-4.5 text-brand-blue-800" />
            <span>Panduan Sinkronisasi</span>
          </h3>

          <div className="space-y-4 text-xs leading-relaxed text-slate-600 text-left">
            <div className="space-y-2">
              <span className="font-bold text-slate-800 block">1. Metode Direct Sheets API (Sangat Direkomendasikan):</span>
              <p className="text-[11px] text-slate-500 font-medium">
                Metode ini menggunakan akun Google Anda secara langsung untuk membaca dan menulis spreadsheet menggunakan REST API Google Sheets. Sangat aman dan tidak memerlukan penyalinan skrip manual!
              </p>
              <ul className="list-disc pl-4 space-y-1 text-[11px] text-slate-500 font-medium">
                <li>Klik <strong>Hubungkan Akun Google</strong>.</li>
                <li>Gunakan Spreadsheet yang ada (SD Xaverius 2 Jambi) atau gunakan spreadsheet kosong baru milik Anda sendiri.</li>
                <li>Klik <strong>Inisialisasi Semua Tabel</strong> untuk mengonfigurasi sheet (Siswa, Buku, Pesanan, dll.) secara otomatis.</li>
              </ul>
            </div>

            <div className="space-y-2 border-t border-slate-100 pt-3">
              <div className="flex items-center justify-between">
                <span className="font-bold text-slate-800">2. Metode Google Apps Script (GAS):</span>
                <button
                  onClick={handleCopyCode}
                  className="inline-flex items-center space-x-1 bg-slate-50 hover:bg-slate-100 border border-slate-200 text-[9px] font-extrabold px-2 py-0.5 rounded"
                >
                  {isCopied ? <Check className="h-3 w-3 text-emerald-600" /> : <Copy className="h-3 w-3" />}
                  <span>{isCopied ? 'Tersalin' : 'Salin Kode GAS'}</span>
                </button>
              </div>
              <p className="text-[11px] text-slate-500 font-medium">
                Metode alternatif menggunakan naskah (Apps Script) sebagai proxy backend. Ikuti langkah instalisasi skrip:
              </p>
              <ol className="list-decimal pl-4 space-y-1 text-[10px] text-slate-500 font-medium">
                <li>Buat Spreadsheet kosong baru di Google Drive Anda.</li>
                <li>Klik menu <strong>Extensions &rarr; Apps Script</strong>.</li>
                <li>Hapus semua kode default, salin kode GAS di atas, lalu paste ke sana.</li>
                <li>Klik Simpan, lalu <strong>Deploy &rarr; New deployment</strong>.</li>
                <li>Pilih tipe: <strong>Web app</strong>. Atur Execute as: <strong>"Me"</strong> dan Who has access: <strong>"Anyone"</strong>.</li>
                <li>Salin Web App URL hasil deployment ke panel sebelah kiri.</li>
              </ol>
            </div>

            {/* Code Snippet Box */}
            <div className="relative border-t border-slate-100 pt-3">
              <span className="font-bold text-slate-800 block mb-1.5">Intisari Kode Google Apps Script:</span>
              <pre className="p-3 bg-slate-900 text-slate-200 font-mono text-[9px] rounded-xl overflow-x-auto max-h-40 leading-normal text-left">
                {GOOGLE_APPS_SCRIPT_CODE}
              </pre>
              <div className="absolute inset-x-0 bottom-0 h-8 bg-gradient-to-t from-white to-transparent pointer-events-none" />
            </div>
          </div>
        </div>

      </div>
    </div>
  );
}
