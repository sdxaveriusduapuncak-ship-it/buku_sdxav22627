/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { useApp } from '../contexts/AppContext';
import { 
  ShoppingBag, 
  Hourglass, 
  CheckCircle, 
  TrendingUp, 
  Coins, 
  AlertTriangle,
  FileText,
  UserCheck,
  CalendarDays
} from 'lucide-react';
import { motion } from 'motion/react';

export default function Dashboard({ setActiveTab }: { setActiveTab: (tab: string) => void }) {
  const { pesanan, buku, transaksi, auditLogs, schoolSettings } = useApp();

  // 1. Calculate KPI Metrics
  const totalOrders = pesanan.length;
  const pendingOrders = pesanan.filter(p => p.Status === 'MENUNGGU PEMBAYARAN').length;
  const lunasOrders = pesanan.filter(p => p.Status === 'LUNAS').length; // paid but not yet dispatched
  const selesaiOrders = pesanan.filter(p => p.Status === 'SELESAI').length;

  const todayStr = new Date().toISOString().slice(0, 10);
  const totalSalesToday = transaksi
    .filter(t => t.TanggalBayar.startsWith(todayStr))
    .reduce((sum, t) => sum + t.Jumlah, 0);

  const totalSalesAllTime = transaksi.reduce((sum, t) => sum + t.Jumlah, 0);

  // 2. Alert textbooks with Low Stocks
  const lowStockBooks = buku.filter(b => b.Stok < 10 && b.Status === 'AKTIF');

  // 3. SVG Chart Calculations
  // Let's count orders per student class level (Kelas 1 to 6)
  const classLevels = ['1', '2', '3', '4', '5', '6'];
  const dataByClass = classLevels.map(lvl => {
    const totalQty = pesanan
      .filter(p => p.Kelas.startsWith(lvl))
      .reduce((sum, p) => sum + p.Total, 0);
    return { class: `Kelas ${lvl}`, total: totalQty };
  });

  const maxVal = Math.max(...dataByClass.map(d => d.total), 100000);

  return (
    <div className="space-y-6 text-left">
      {/* Welcome Banner */}
      <div className="bg-gradient-to-r from-brand-blue-900 to-brand-blue-700 rounded-2xl p-6 text-white shadow-md flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-xl font-bold font-display text-brand-gold-400">Selamat Datang di Portal Tata Usaha</h2>
          <p className="text-xs text-slate-300 mt-1">Sistem informasi penjualan buku pelajaran {schoolSettings.NamaSekolah}. Kelola pesanan, verifikasi pembayaran, dan pantau ketersediaan stok.</p>
        </div>
        <div className="bg-brand-blue-950/40 border border-brand-blue-500/30 px-3.5 py-2 rounded-xl text-xs flex items-center space-x-2 shrink-0">
          <CalendarDays className="h-4.5 w-4.5 text-brand-gold-400" />
          <span className="font-bold tracking-wide">Hari Ini: {new Date().toLocaleDateString('id-ID', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}</span>
        </div>
      </div>

      {/* KPI Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Metric 1 */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between">
          <div className="space-y-1">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">Pesanan Baru</span>
            <span className="text-2xl font-bold font-display text-slate-800">{pendingOrders}</span>
            <span className="text-[10px] text-amber-600 font-bold block">Menunggu Pembayaran</span>
          </div>
          <div className="h-12 w-12 bg-amber-100 rounded-xl flex items-center justify-center text-amber-600">
            <Hourglass className="h-6 w-6" />
          </div>
        </div>

        {/* Metric 2 */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between">
          <div className="space-y-1">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">Sudah Bayar</span>
            <span className="text-2xl font-bold font-display text-slate-800">{lunasOrders}</span>
            <span className="text-[10px] text-emerald-600 font-bold block">Siap Diambil di TU</span>
          </div>
          <div className="h-12 w-12 bg-emerald-100 rounded-xl flex items-center justify-center text-emerald-600">
            <ShoppingBag className="h-6 w-6" />
          </div>
        </div>

        {/* Metric 3 */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between">
          <div className="space-y-1">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">Total Selesai</span>
            <span className="text-2xl font-bold font-display text-slate-800">{selesaiOrders}</span>
            <span className="text-[10px] text-brand-blue-600 font-bold block">Buku Sudah Diserahkan</span>
          </div>
          <div className="h-12 w-12 bg-blue-100 rounded-xl flex items-center justify-center text-brand-blue-600">
            <CheckCircle className="h-6 w-6" />
          </div>
        </div>

        {/* Metric 4 */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between">
          <div className="space-y-1">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">Omset Hari Ini</span>
            <span className="text-lg font-bold font-display text-slate-800">Rp {totalSalesToday.toLocaleString('id-ID')}</span>
            <span className="text-[10px] text-slate-400 font-bold block">Total: Rp {totalSalesAllTime.toLocaleString('id-ID')}</span>
          </div>
          <div className="h-12 w-12 bg-yellow-100 rounded-xl flex items-center justify-center text-yellow-600">
            <Coins className="h-6 w-6" />
          </div>
        </div>
      </div>

      {/* Main Grid: Graph and Side Alert logs */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Sales Chart (8 Cols) */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm lg:col-span-8 flex flex-col justify-between">
          <div>
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wider flex items-center space-x-2">
                <TrendingUp className="h-5 w-5 text-brand-blue-800" />
                <span>Grafik Penjualan Per Kelas (Rupiah)</span>
              </h3>
              <span className="text-[10px] bg-slate-100 text-slate-600 font-bold px-2.5 py-1 rounded-full">
                Sistem Merdeka
              </span>
            </div>
            
            {/* Custom SVG Responsive Bar Chart */}
            <div className="h-64 w-full flex items-end justify-between px-2 pt-6 pb-2 border-b border-l border-slate-200 relative">
              
              {dataByClass.map((d, index) => {
                const percentHeight = (d.total / maxVal) * 80; // Scale height max 80%
                return (
                  <div key={index} className="flex-1 flex flex-col items-center group relative mx-2">
                    {/* Tooltip on Hover */}
                    <div className="absolute -top-12 opacity-0 group-hover:opacity-100 bg-brand-blue-900 text-white text-[10px] font-bold px-2 py-1 rounded shadow-md pointer-events-none transition-opacity z-10 whitespace-nowrap">
                      Rp {d.total.toLocaleString('id-ID')}
                    </div>

                    {/* Bar Pillar */}
                    <div 
                      style={{ height: `${percentHeight}%` }} 
                      className="w-full bg-gradient-to-t from-brand-blue-800 to-brand-blue-500 rounded-t-md group-hover:from-brand-gold-500 group-hover:to-brand-gold-400 transition-all duration-300 min-h-[4px]"
                    />

                    {/* Label below axis */}
                    <span className="text-[10px] font-bold text-slate-500 mt-2 whitespace-nowrap">
                      {d.class}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="text-[11px] text-slate-400 mt-4 text-center">
            Pilar grafik di atas menampilkan kontribusi nilai penjualan (Rupiah) buku pelajaran untuk masing-masing tingkatan kelas SD.
          </div>
        </div>

        {/* Stock Alert & Logs (4 Cols) */}
        <div className="lg:col-span-4 space-y-6">
          {/* Stock warning box */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-3">
            <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center space-x-2 border-b border-slate-100 pb-2.5">
              <AlertTriangle className="h-4.5 w-4.5 text-amber-500" />
              <span>Peringatan Stok Tipis</span>
            </h3>

            {lowStockBooks.length === 0 ? (
              <div className="text-[11px] text-slate-500 font-semibold text-center py-4">
                Semua stok buku aktif aman (di atas 10 pcs).
              </div>
            ) : (
              <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                {lowStockBooks.map(b => (
                  <div key={b.KodeBuku} className="flex items-center justify-between p-2 rounded-lg bg-amber-50 border border-amber-200 text-xs">
                    <span className="font-semibold text-slate-700 truncate max-w-[150px]" title={b.NamaBuku}>
                      {b.NamaBuku}
                    </span>
                    <span className="font-bold text-rose-600 bg-rose-50 px-2 py-0.5 rounded shrink-0">
                      Sisa: {b.Stok}
                    </span>
                  </div>
                ))}
              </div>
            )}
            
            <button
              onClick={() => setActiveTab('buku')}
              className="w-full text-center text-[11px] font-bold text-brand-blue-800 hover:text-brand-blue-700 block"
            >
              Kelola Pengadaan Buku &rarr;
            </button>
          </div>

          {/* School Settings Profile preview */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-3 text-xs">
            <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center space-x-2 border-b border-slate-100 pb-2.5">
              <UserCheck className="h-4.5 w-4.5 text-brand-blue-800" />
              <span>Informasi Profil Aplikasi</span>
            </h3>
            <div className="space-y-2 text-slate-600 font-semibold">
              <div className="flex justify-between">
                <span className="text-slate-400">NAMA SEKOLAH:</span>
                <span className="text-slate-800 font-bold">{schoolSettings.NamaSekolah}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">TELEPON:</span>
                <span className="text-slate-800">{schoolSettings.Telepon}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">TAHUN AJARAN:</span>
                <span className="text-brand-blue-800 font-bold">{schoolSettings.TahunPelajaran}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Recent Activity Timeline (Bottom) */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
        <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wider flex items-center space-x-2 border-b border-slate-100 pb-3 mb-4">
          <FileText className="h-5 w-5 text-brand-blue-800" />
          <span>Log Riwayat Aktivitas & Audit Penjualan</span>
        </h3>

        <div className="space-y-4">
          {auditLogs.slice(0, 5).map((log, index) => (
            <div key={log.id} className="flex items-start space-x-3 text-xs">
              <div className="relative flex items-center justify-center shrink-0 mt-0.5">
                <div className="h-2 w-2 rounded-full bg-brand-blue-700" />
                {index < 4 && <div className="absolute top-2 bottom-[-24px] w-0.5 bg-slate-200" />}
              </div>
              <div className="flex-1">
                <div className="flex flex-col sm:flex-row sm:justify-between">
                  <span className="font-bold text-slate-800">{log.aktivitas}</span>
                  <span className="text-[10px] text-slate-400 font-mono mt-0.5 sm:mt-0">{log.tanggal}</span>
                </div>
                <p className="text-slate-600 mt-0.5 font-medium">{log.keterangan}</p>
                <div className="text-[10px] text-brand-blue-800 font-bold mt-1 uppercase">
                  Oleh: {log.user}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
