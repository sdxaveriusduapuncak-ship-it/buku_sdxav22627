/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useApp } from '../contexts/AppContext';
import { Siswa } from '../types';
import { 
  Plus, 
  Edit2, 
  Trash2, 
  Download, 
  Upload, 
  Search, 
  X, 
  Users,
  ChevronLeft,
  ChevronRight
} from 'lucide-react';
import { exportToCSV, parseCSV, processImportedSiswa } from '../utils/excelExporter';
import { motion, AnimatePresence } from 'motion/react';

export default function AdminSiswa() {
  const { siswa, saveSiswa, deleteSiswa, showToast } = useApp();

  // Search and Pagination
  const [searchTerm, setSearchTerm] = useState('');
  const [classFilter, setClassFilter] = useState('ALL');
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10;

  // Modal States
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedSiswa, setSelectedSiswa] = useState<Siswa | null>(null);

  // Form States
  const [formNIS, setFormNIS] = useState('');
  const [formNama, setFormNama] = useState('');
  const [formKelas, setFormKelas] = useState('1A');
  const [formGender, setFormGender] = useState<'L' | 'P'>('L');
  const [formNamaOrtu, setFormNamaOrtu] = useState('');
  const [formNoHP, setFormNoHP] = useState('');

  // Filtering
  const filteredSiswa = siswa.filter(s => {
    const matchesSearch = s.Nama.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          s.NIS.includes(searchTerm) ||
                          s.NamaOrtu.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesClass = classFilter === 'ALL' || s.Kelas === classFilter;
    return matchesSearch && matchesClass;
  });

  // Paginated Results
  const totalPages = Math.ceil(filteredSiswa.length / itemsPerPage) || 1;
  const paginatedSiswa = filteredSiswa.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);

  const handleOpenAddModal = () => {
    setSelectedSiswa(null);
    setFormNIS(String(10203000 + siswa.length + 1));
    setFormNama('');
    setFormKelas('1A');
    setFormGender('L');
    setFormNamaOrtu('');
    setFormNoHP('');
    setIsModalOpen(true);
  };

  const handleOpenEditModal = (s: Siswa) => {
    setSelectedSiswa(s);
    setFormNIS(s.NIS);
    setFormNama(s.Nama);
    setFormKelas(s.Kelas);
    setFormGender(s.JenisKelamin);
    setFormNamaOrtu(s.NamaOrtu);
    setFormNoHP(s.NoHP);
    setIsModalOpen(true);
  };

  const handleSaveSiswa = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formNama || !formNIS) {
      showToast('Nama dan NIS tidak boleh kosong!', 'error');
      return;
    }

    const newSiswa: Siswa = {
      NIS: formNIS,
      Nama: formNama,
      Kelas: formKelas,
      JenisKelamin: formGender,
      NamaOrtu: formNamaOrtu,
      NoHP: formNoHP
    };

    saveSiswa(newSiswa);
    setIsModalOpen(false);
  };

  const handleDeleteSiswa = (nis: string) => {
    if (confirm('Apakah Anda yakin ingin menghapus data siswa ini secara permanen dari database sekolah?')) {
      deleteSiswa(nis);
    }
  };

  const handleExportCSV = () => {
    exportToCSV(siswa, 'DATA-SISWA-XAVERIUS2');
    showToast('Berhasil mengekspor daftar siswa ke format Excel/CSV', 'success');
  };

  const handleImportCSV = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      try {
        const rows = parseCSV(text);
        const imported = processImportedSiswa(rows);
        
        imported.forEach(s => {
          saveSiswa(s);
        });

        showToast(`Berhasil mengimpor ${imported.length} siswa baru ke database!`, 'success');
      } catch (err) {
        showToast('Gagal memproses file spreadsheet. Format kolom tidak sesuai.', 'error');
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="space-y-6 text-left font-sans">
      
      {/* HEADER SECTION */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-xl font-bold font-display text-brand-blue-900 flex items-center space-x-2">
            <Users className="h-6 w-6 text-brand-gold-600" />
            <span>Kelola Basis Data Siswa Sekolah</span>
          </h2>
          <p className="text-xs text-slate-500 mt-1">Kelola data murid terdaftar, edit kelas, setel wali murid, dan sinkronisasi backup spreadsheet Excel.</p>
        </div>

        <div className="flex gap-2">
          <button
            onClick={handleExportCSV}
            className="inline-flex items-center space-x-1.5 px-3 py-2 border-2 border-slate-200 rounded-xl hover:bg-slate-50 text-xs font-semibold text-slate-700 transition"
          >
            <Download className="h-4 w-4" />
            <span>Unduh Excel</span>
          </button>
          
          <label className="inline-flex items-center space-x-1.5 px-3 py-2 border-2 border-slate-200 rounded-xl hover:bg-slate-50 text-xs font-semibold text-slate-700 transition cursor-pointer">
            <Upload className="h-4 w-4" />
            <span>Unggah Excel</span>
            <input 
              type="file"
              accept=".csv"
              onChange={handleImportCSV}
              className="hidden"
            />
          </label>

          <button
            onClick={handleOpenAddModal}
            className="inline-flex items-center space-x-1.5 px-4 py-2 bg-brand-blue-800 hover:bg-brand-blue-700 text-white rounded-xl text-xs font-bold shadow transition"
            id="admin-add-student-btn"
          >
            <Plus className="h-4.5 w-4.5 text-brand-gold-400" />
            <span>Tambah Siswa Baru</span>
          </button>
        </div>
      </div>

      {/* SEARCH AND FILTERS PANEL */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search className="h-4 w-4 text-slate-400" />
          </div>
          <input 
            type="text"
            value={searchTerm}
            onChange={(e) => { setSearchTerm(e.target.value); setCurrentPage(1); }}
            placeholder="Cari siswa berdasarkan nama, NIS, atau wali murid..."
            className="w-full pl-9 pr-4 py-2.5 bg-slate-50 hover:bg-slate-100/50 focus:bg-white border border-slate-200 focus:border-brand-blue-600 rounded-lg text-xs font-semibold focus:outline-none transition-all"
            id="admin-student-search"
          />
        </div>

        <select
          value={classFilter}
          onChange={(e) => { setClassFilter(e.target.value); setCurrentPage(1); }}
          className="px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-semibold focus:outline-none focus:border-brand-blue-600"
        >
          <option value="ALL">Semua Kelas</option>
          <option value="1A">Kelas 1A</option>
          <option value="1B">Kelas 1B</option>
          <option value="2A">Kelas 2A</option>
          <option value="2B">Kelas 2B</option>
          <option value="3A">Kelas 3A</option>
          <option value="3B">Kelas 3B</option>
          <option value="4A">Kelas 4A</option>
          <option value="4B">Kelas 4B</option>
          <option value="5A">Kelas 5A</option>
          <option value="5B">Kelas 5B</option>
          <option value="6A">Kelas 6A</option>
          <option value="6B">Kelas 6B</option>
        </select>
      </div>

      {/* STUDENT MAIN REGISTER TABLE */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full border-collapse text-left text-xs font-semibold text-slate-600">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-400 uppercase tracking-wider text-[10px]">
              <tr>
                <th className="py-3.5 px-4 text-center">NIS</th>
                <th className="py-3.5 px-4">Nama Lengkap Murid</th>
                <th className="py-3.5 px-4 text-center">Kelas</th>
                <th className="py-3.5 px-4 text-center">L/P</th>
                <th className="py-3.5 px-4">Nama Orang Tua (Wali)</th>
                <th className="py-3.5 px-4">No. HP Hubungi</th>
                <th className="py-3.5 px-4 text-center">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
              {paginatedSiswa.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-slate-400 font-bold">
                    Tidak ditemukan murid terdaftar yang cocok dengan filter.
                  </td>
                </tr>
              ) : (
                paginatedSiswa.map((s) => (
                  <tr key={s.NIS} className="hover:bg-slate-50/50">
                    <td className="py-4 px-4 text-center font-mono font-bold text-slate-950">{s.NIS}</td>
                    <td className="py-4 px-4 text-slate-900 font-bold">{s.Nama}</td>
                    <td className="py-4 px-4 text-center">
                      <span className="bg-brand-blue-50 text-brand-blue-800 text-[11px] font-extrabold px-2.5 py-1 rounded">
                        {s.Kelas}
                      </span>
                    </td>
                    <td className="py-4 px-4 text-center font-bold text-slate-500">{s.JenisKelamin}</td>
                    <td className="py-4 px-4">{s.NamaOrtu}</td>
                    <td className="py-4 px-4 font-mono font-semibold text-slate-600">{s.NoHP}</td>
                    <td className="py-4 px-4 text-center">
                      <div className="flex items-center justify-center space-x-2">
                        <button
                          onClick={() => handleOpenEditModal(s)}
                          className="p-1.5 bg-brand-blue-50 hover:bg-brand-blue-100 text-brand-blue-800 rounded-lg transition"
                          id={`admin-edit-student-${s.NIS}`}
                        >
                          <Edit2 className="h-4 w-4" />
                        </button>
                        <button
                          onClick={() => handleDeleteSiswa(s.NIS)}
                          className="p-1.5 bg-rose-50 hover:bg-rose-100 text-rose-600 rounded-lg transition"
                          id={`admin-delete-student-${s.NIS}`}
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* PAGINATION PANEL */}
        {totalPages > 1 && (
          <div className="bg-slate-50 py-3.5 px-4 border-t border-slate-200 flex justify-between items-center text-xs text-slate-500 font-semibold">
            <span>Menampilkan halaman {currentPage} dari {totalPages} ({filteredSiswa.length} siswa)</span>
            <div className="flex items-center space-x-1">
              <button
                onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                disabled={currentPage === 1}
                className="p-1 bg-white border border-slate-200 rounded hover:bg-slate-100 disabled:opacity-40 transition"
              >
                <ChevronLeft className="h-4.5 w-4.5" />
              </button>
              <button
                onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                disabled={currentPage === totalPages}
                className="p-1 bg-white border border-slate-200 rounded hover:bg-slate-100 disabled:opacity-40 transition"
              >
                <ChevronRight className="h-4.5 w-4.5" />
              </button>
            </div>
          </div>
        )}
      </div>

      {/* ADD/EDIT STUDENT MODAL OVERLAY */}
      <AnimatePresence>
        {isModalOpen && (
          <div className="fixed inset-0 z-50 overflow-y-auto bg-black/40 backdrop-blur-xs flex items-center justify-center p-4">
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white rounded-3xl w-full max-w-md shadow-2xl border border-slate-200 overflow-hidden text-left"
            >
              <div className="bg-brand-blue-900 text-white p-6 flex justify-between items-center">
                <h3 className="text-md font-bold font-display text-brand-gold-400">
                  {selectedSiswa ? `Edit Siswa: ${selectedSiswa.NIS}` : 'Tambah Siswa Baru'}
                </h3>
                <button onClick={() => setIsModalOpen(false)} className="text-white/80 hover:text-white rounded">
                  <X className="h-5 w-5" />
                </button>
              </div>

              <form onSubmit={handleSaveSiswa} className="p-6 space-y-4 text-xs font-semibold text-slate-700">
                {/* NIS */}
                <div className="space-y-1">
                  <label className="text-slate-500 uppercase">Nomor Induk Siswa (NIS)</label>
                  <input 
                    type="text"
                    value={formNIS}
                    onChange={(e) => setFormNIS(e.target.value.replace(/\D/g, ''))}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg font-mono focus:border-brand-blue-600 focus:outline-none"
                    disabled={!!selectedSiswa}
                    required
                  />
                </div>

                {/* Nama Lengkap */}
                <div className="space-y-1">
                  <label className="text-slate-500 uppercase">Nama Lengkap Siswa</label>
                  <input 
                    type="text"
                    value={formNama}
                    onChange={(e) => setFormNama(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:border-brand-blue-600 focus:outline-none"
                    placeholder="Contoh: Angelina Wijaya..."
                    required
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  {/* Kelas */}
                  <div className="space-y-1">
                    <label className="text-slate-500 uppercase">Kelas Terdaftar</label>
                    <select
                      value={formKelas}
                      onChange={(e) => setFormKelas(e.target.value)}
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:border-brand-blue-600"
                    >
                      <option value="1A">Kelas 1A</option>
                      <option value="1B">Kelas 1B</option>
                      <option value="2A">Kelas 2A</option>
                      <option value="2B">Kelas 2B</option>
                      <option value="3A">Kelas 3A</option>
                      <option value="3B">Kelas 3B</option>
                      <option value="4A">Kelas 4A</option>
                      <option value="4B">Kelas 4B</option>
                      <option value="5A">Kelas 5A</option>
                      <option value="5B">Kelas 5B</option>
                      <option value="6A">Kelas 6A</option>
                      <option value="6B">Kelas 6B</option>
                    </select>
                  </div>

                  {/* Jenis Kelamin */}
                  <div className="space-y-1">
                    <label className="text-slate-500 uppercase">Jenis Kelamin</label>
                    <select
                      value={formGender}
                      onChange={(e) => setFormGender(e.target.value as any)}
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:border-brand-blue-600"
                    >
                      <option value="L">Laki-laki (L)</option>
                      <option value="P">Perempuan (P)</option>
                    </select>
                  </div>
                </div>

                {/* Nama Wali */}
                <div className="space-y-1">
                  <label className="text-slate-500 uppercase">Nama Orang Tua / Wali Murid</label>
                  <input 
                    type="text"
                    value={formNamaOrtu}
                    onChange={(e) => setFormNamaOrtu(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:border-brand-blue-600 focus:outline-none"
                    placeholder="Contoh: Hendra Wijaya..."
                    required
                  />
                </div>

                {/* No HP */}
                <div className="space-y-1">
                  <label className="text-slate-500 uppercase">Nomor HP Hubungi (WhatsApp)</label>
                  <input 
                    type="text"
                    value={formNoHP}
                    onChange={(e) => setFormNoHP(e.target.value.replace(/\D/g, ''))}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg font-mono focus:border-brand-blue-600 focus:outline-none"
                    placeholder="Contoh: 081234567890..."
                    required
                  />
                </div>

                {/* Submit block */}
                <div className="pt-4 border-t border-slate-100 flex justify-end space-x-2">
                  <button
                    type="button"
                    onClick={() => setIsModalOpen(false)}
                    className="px-4 py-2 border border-slate-200 hover:bg-slate-50 text-slate-700 font-semibold rounded-lg"
                  >
                    Batal
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 bg-brand-blue-800 hover:bg-brand-blue-700 text-white font-bold rounded-lg shadow"
                    id="admin-student-save-submit"
                  >
                    Simpan Siswa
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
