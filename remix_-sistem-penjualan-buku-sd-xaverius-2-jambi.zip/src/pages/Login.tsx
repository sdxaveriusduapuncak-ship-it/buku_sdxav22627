/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useApp } from '../contexts/AppContext';
import { KeyRound, User, Lock, ArrowLeft, ShieldAlert } from 'lucide-react';
import { motion } from 'motion/react';

export default function Login({ onGoBack, onLoginSuccess }: { onGoBack: () => void; onLoginSuccess: () => void }) {
  const { login, schoolSettings } = useApp();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!username || !password) return;

    setLoading(true);
    // Simulate API network check
    setTimeout(() => {
      const success = login(username, password);
      setLoading(false);
      if (success) {
        onLoginSuccess();
      }
    }, 800);
  };

  return (
    <div className="min-h-screen bg-brand-blue-950 flex flex-col justify-center items-center p-4 relative overflow-hidden font-sans">
      
      {/* Decorative Golden Ambient Gradients */}
      <div className="absolute -top-32 -left-32 w-96 h-96 bg-brand-gold-500/10 rounded-full blur-3xl" />
      <div className="absolute -bottom-32 -right-32 w-96 h-96 bg-brand-blue-700/20 rounded-full blur-3xl" />

      {/* Back to Parent Portal link */}
      <button 
        onClick={onGoBack}
        className="absolute top-6 left-6 inline-flex items-center space-x-1.5 text-xs font-semibold text-slate-300 hover:text-brand-gold-400 transition z-50"
      >
        <ArrowLeft className="h-4 w-4" />
        <span>Kembali ke Portal Wali Murid</span>
      </button>

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="w-full max-w-md"
      >
        {/* Card Frame */}
        <div className="bg-white rounded-3xl shadow-2xl overflow-hidden border border-slate-200">
          
          {/* Form Header */}
          <div className="bg-brand-blue-900 p-8 text-center text-white relative">
            <div className="h-14 w-14 bg-brand-gold-500/10 rounded-2xl flex items-center justify-center mx-auto mb-4 border border-brand-gold-500/30">
              <KeyRound className="h-7 w-7 text-brand-gold-400 animate-pulse" />
            </div>
            <h1 className="text-lg font-bold font-display text-brand-gold-400 uppercase tracking-tight">Sistem Administrasi Buku</h1>
            <p className="text-[11px] text-slate-300 mt-1">{schoolSettings.NamaSekolah.toUpperCase()}</p>
          </div>

          {/* Form Body */}
          <form onSubmit={handleSubmit} className="p-8 space-y-6 text-left">
            {/* Username Input */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-700 uppercase tracking-wide flex items-center space-x-1.5">
                <User className="h-4 w-4 text-brand-blue-800" />
                <span>Username Akun</span>
              </label>
              <input 
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="Masukkan username..."
                className="w-full px-4 py-3 bg-slate-50 border-2 border-slate-200 rounded-xl text-xs font-semibold text-slate-800 focus:outline-none focus:border-brand-blue-700 transition-all"
                required
                id="login-username-input"
              />
            </div>

            {/* Password Input */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-700 uppercase tracking-wide flex items-center space-x-1.5">
                <Lock className="h-4 w-4 text-brand-blue-800" />
                <span>Password</span>
              </label>
              <input 
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full px-4 py-3 bg-slate-50 border-2 border-slate-200 rounded-xl text-xs font-semibold text-slate-800 focus:outline-none focus:border-brand-blue-700 transition-all"
                required
                id="login-password-input"
              />
            </div>

            {/* Login Trigger Button */}
            <button
              type="submit"
              disabled={loading}
              className="w-full flex items-center justify-center space-x-2 bg-brand-blue-800 hover:bg-brand-blue-700 text-white font-bold py-3.5 rounded-xl shadow-lg hover:shadow-xl transition-all"
              id="login-submit-button"
            >
              <span>{loading ? 'Memvalidasi Sesi...' : 'Masuk ke Dashboard'}</span>
            </button>

            {/* Simulated Credentials Helper Box */}
            <div className="bg-amber-50 rounded-xl p-4 border border-amber-200 space-y-2">
              <span className="text-[11px] font-bold text-amber-800 flex items-center space-x-1 uppercase tracking-wide">
                <ShieldAlert className="h-4 w-4 text-brand-gold-600" />
                <span>Akses Akun Demo Sekolah:</span>
              </span>
              <div className="grid grid-cols-2 gap-2 text-[10px] text-slate-600 font-mono">
                <div>
                  <span className="block font-bold">Role Administrator:</span>
                  <span>U: admin</span><br />
                  <span>P: password123</span>
                </div>
                <div>
                  <span className="block font-bold">Role Tata Usaha:</span>
                  <span>U: tu_xaverius</span><br />
                  <span>P: tu123</span>
                </div>
              </div>
            </div>
          </form>

        </div>
      </motion.div>
    </div>
  );
}
