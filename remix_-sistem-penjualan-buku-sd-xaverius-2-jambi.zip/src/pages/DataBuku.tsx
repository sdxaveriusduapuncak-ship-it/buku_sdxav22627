/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useApp } from '../contexts/AppContext';
import { Buku } from '../types';
import { 
  Plus, 
  Edit2, 
  Trash2, 
  Upload, 
  Download, 
  Barcode as BarcodeIcon, 
  Search, 
  Check, 
  X,
  PlusCircle,
  BookOpen,
  Printer,
  ChevronLeft,
  ChevronRight
} from 'lucide-react';
import { exportToCSV, parseCSV, processImportedBooks } from '../utils/excelExporter';
import { motion, AnimatePresence } from 'motion/react';

export default function DataBuku() {
  const { buku, saveBook, deleteBook, showToast } = useApp();
  
  // Search & Filter state
  const [searchTerm, setSearchTerm] = useState('');
  const [classFilter, setClassFilter] = useState('ALL');
  
  // Modal states
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedBook, setSelectedBook] = useState<Buku | null>(null);

  // Print Barcode states
  const [isBarcodeView, setIsBarcodeView] = useState(false);
  const [barcodeBook, setBarcodeBook] = useState<Buku | null>(null);
  const [barcodeQty, setBarcodeQty] = useState(8); // Default print 8 copies

  // Form Fields
  const [formKode, setFormKode] = useState('');
  const [formBarcode, setFormBarcode] = useState('');
  const [formNama, setFormNama] = useState('');
  const [formKelas, setFormKelas] = useState('1');
  const [formHarga, setFormHarga] = useState(0);
  const [formStok, setFormStok] = useState(0);
  const [formKategori, setFormKategori] = useState('Wajib');
  const [formStatus, setFormStatus] = useState<'AKTIF' | 'NONAKTIF'>('AKTIF');

  // Pagination state
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 8;

  // Filter books
  const filteredBuku = buku.filter(b => {
    const matchesSearch = b.NamaBuku.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          b.KodeBuku.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          b.Barcode.includes(searchTerm);
    const matchesClass = classFilter === 'ALL' || b.Kelas === classFilter;
    return matchesSearch && matchesClass;
  });

  // Paginated books
  const totalPages = Math.ceil(filteredBuku.length / itemsPerPage) || 1;
  const paginatedBuku = filteredBuku.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);

  const handleOpenAddModal = () => {
    setSelectedBook(null);
    setFormKode(`B${buku.length + 101}`);
    setFormBarcode(String(899000000 + buku.length + 101));
    setFormNama('');
    setFormKelas('1');
    setFormHarga(50000);
    setFormStok(30);
    setFormKategori('Wajib');
    setFormStatus('AKTIF');
    setIsModalOpen(true);
  };

  const handleOpenEditModal = (book: Buku) => {
    setSelectedBook(book);
    setFormKode(book.KodeBuku);
    setFormBarcode(book.Barcode);
    setFormNama(book.NamaBuku);
    setFormKelas(book.Kelas);
    setFormHarga(book.Harga);
    setFormStok(book.Stok);
    setFormKategori(book.Kategori);
    setFormStatus(book.Status);
    setIsModalOpen(true);
  };

  const handleSaveBook = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formNama) {
      showToast('Nama buku tidak boleh kosong!', 'error');
      return;
    }

    const newBook: Buku = {
      KodeBuku: formKode,
      Barcode: formBarcode || formKode,
      NamaBuku: formNama,
      Kelas: formKelas,
      Harga: Number(formHarga),
      Stok: Number(formStok),
      Kategori: formKategori,
      Status: formStatus,
      Foto: selectedBook?.Foto || 'https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=400&auto=format&fit=crop&q=60'
    };

    saveBook(newBook);
    setIsModalOpen(false);
  };

  const handleDeleteBook = (kode: string) => {
    if (confirm('Apakah Anda yakin ingin menghapus buku pelajaran ini dari database?')) {
      deleteBook(kode);
    }
  };

  // CSV Export
  const handleExportCSV = () => {
    exportToCSV(buku, 'DAFTAR-BUKU-XAVERIUS2');
    showToast('Berhasil mengekspor daftar buku ke format Excel/CSV', 'success');
  };

  // CSV Import simulation
  const handleImportCSV = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      try {
        const rows = parseCSV(text);
        const imported = processImportedBooks(rows);
        
        // Save each imported book
        imported.forEach(b => {
          saveBook(b);
        });

        showToast(`Berhasil mengimpor ${imported.length} buku baru secara bulk!`, 'success');
      } catch (err) {
        showToast('Gagal memproses file spreadsheet. Format kolom tidak sesuai.', 'error');
      }
    };
    reader.readAsText(file);
  };

  // Visual Barcode rendering using pure CSS/HTML grid of columns
  const renderVisualBarcode = (val: string) => {
    // Generate a beautiful consistent barcode look based on character strings
    const bars = [];
    for (let i = 0; i < val.length; i++) {
      const weight = (parseInt(val[i]) || 3) % 4 + 1; // bar thickness 1-4
      bars.push(
        <div key={`b-${i}`} className={`h-12 bg-black shrink-0`} style={{ width: `${weight * 1.5}px`, marginRight: `${(i % 2 === 0 ? 1 : 2)}px` }} />
      );
    }
    return (
      <div className="flex items-center justify-center overflow-hidden bg-white p-2 border border-slate-200 rounded">
        {bars}
      </div>
    );
  };

  return (
    <div className="space-y-6 text-left font-sans">
      
      {/* PAGE HEADER */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-xl font-bold font-display text-brand-blue-900 flex items-center space-x-2">
            <BookOpen className="h-6 w-6 text-brand-gold-600" />
            <span>Katalog & Ketersediaan Buku Pelajaran</span>
          </h2>
          <p className="text-xs text-slate-500 mt-1">Kelola data buku teks utama, setel harga, pantau kuantitas stok, dan unduh backup Excel.</p>
        </div>

        {/* Action button triggers */}
        <div className="flex flex-wrap gap-2">
          <button
            onClick={handleExportCSV}
            className="inline-flex items-center space-x-1.5 px-3 py-2 border-2 border-slate-200 rounded-xl hover:bg-slate-50 text-xs font-semibold text-slate-700 transition"
          >
            <Download className="h-4 w-4" />
            <span>Unduh Excel</span>
          </button>
          
          <label className="inline-flex items-center space-x-1.5 px-3 py-2 border-2 border-slate-200 rounded-xl hover:bg-slate-50 text-xs font-semibold text-slate-700 transition cursor-pointer">
            <Upload className="h-4 w-4" />
            <span>Unggah Excel</span>
            <input 
              type="file"
              accept=".csv"
              onChange={handleImportCSV}
              className="hidden"
            />
          </label>

          <button
            onClick={handleOpenAddModal}
            className="inline-flex items-center space-x-1.5 px-4 py-2 bg-brand-blue-800 hover:bg-brand-blue-700 text-white rounded-xl text-xs font-bold shadow transition"
            id="tu-add-book-button"
          >
            <Plus className="h-4.5 w-4.5 text-brand-gold-400" />
            <span>Tambah Buku Baru</span>
          </button>
        </div>
      </div>

      <AnimatePresence mode="wait">
        
        {/* VIEW 1: BOOK TABLE GRID (Standard) */}
        {!isBarcodeView ? (
          <motion.div 
            key="table-view"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="space-y-4"
          >
            {/* SEARCH AND FILTERS PANEL */}
            <div className="bg-white p-4 rounded-xl border border-slate-200 flex flex-col md:flex-row gap-3">
              <div className="relative flex-1">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Search className="h-4 w-4 text-slate-400" />
                </div>
                <input 
                  type="text"
                  value={searchTerm}
                  onChange={(e) => { setSearchTerm(e.target.value); setCurrentPage(1); }}
                  placeholder="Cari buku berdasarkan nama, kode, atau barcode..."
                  className="w-full pl-9 pr-4 py-2.5 bg-slate-50 hover:bg-slate-100/50 focus:bg-white border border-slate-200 focus:border-brand-blue-600 rounded-lg text-xs font-semibold focus:outline-none transition-all"
                  id="tu-book-search"
                />
              </div>

              <div className="flex gap-2">
                <select
                  value={classFilter}
                  onChange={(e) => { setClassFilter(e.target.value); setCurrentPage(1); }}
                  className="px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-semibold focus:outline-none focus:border-brand-blue-600"
                >
                  <option value="ALL">Semua Kelas</option>
                  <option value="1">Kelas 1</option>
                  <option value="2">Kelas 2</option>
                  <option value="3">Kelas 3</option>
                  <option value="4">Kelas 4</option>
                  <option value="5">Kelas 5</option>
                  <option value="6">Kelas 6</option>
                </select>
              </div>
            </div>

            {/* MAIN DATA TABLE */}
            <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full border-collapse text-left text-xs font-semibold text-slate-600">
                  <thead className="bg-slate-50 border-b border-slate-200 text-slate-400 uppercase tracking-wider text-[10px]">
                    <tr>
                      <th className="py-3.5 px-4 text-center">Kode</th>
                      <th className="py-3.5 px-4">Nama Buku Pelajaran</th>
                      <th className="py-3.5 px-4 text-center">Kelas</th>
                      <th className="py-3.5 px-4 text-right">Harga</th>
                      <th className="py-3.5 px-4 text-center">Stok</th>
                      <th className="py-3.5 px-4 text-center">Kategori</th>
                      <th className="py-3.5 px-4 text-center">Status</th>
                      <th className="py-3.5 px-4 text-center">Aksi</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 font-medium">
                    {paginatedBuku.length === 0 ? (
                      <tr>
                        <td colSpan={8} className="py-8 text-center text-slate-400 font-bold">
                          Tidak ditemukan buku pelajaran yang cocok dengan filter.
                        </td>
                      </tr>
                    ) : (
                      paginatedBuku.map((b) => (
                        <tr key={b.KodeBuku} className="hover:bg-slate-50/50">
                          <td className="py-4 px-4 text-center font-mono font-bold text-slate-950">{b.KodeBuku}</td>
                          <td className="py-4 px-4">
                            <div className="flex items-center space-x-3">
                              <img 
                                src={b.Foto || 'https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=400&auto=format&fit=crop&q=60'} 
                                alt="Book Cover" 
                                className="h-10 w-8 object-cover rounded border border-slate-200"
                                referrerPolicy="no-referrer"
                              />
                              <div>
                                <span className="text-slate-900 font-bold block">{b.NamaBuku}</span>
                                <span className="text-[10px] text-slate-400 font-mono">Barcode: {b.Barcode}</span>
                              </div>
                            </div>
                          </td>
                          <td className="py-4 px-4 text-center">
                            <span className="bg-brand-blue-50 text-brand-blue-800 text-[11px] font-extrabold px-2.5 py-1 rounded">
                              Kelas {b.Kelas}
                            </span>
                          </td>
                          <td className="py-4 px-4 text-right text-slate-900 font-extrabold">
                            Rp {b.Harga.toLocaleString('id-ID')}
                          </td>
                          <td className="py-4 px-4 text-center">
                            <span className={`text-[11px] font-bold px-2 py-0.5 rounded ${
                              b.Stok > 15 
                                ? 'bg-emerald-100 text-emerald-800' 
                                : b.Stok > 0 
                                  ? 'bg-amber-100 text-amber-800' 
                                  : 'bg-rose-100 text-rose-800'
                            }`}>
                              {b.Stok} pcs
                            </span>
                          </td>
                          <td className="py-4 px-4 text-center text-slate-500 uppercase font-bold text-[10px]">{b.Kategori}</td>
                          <td className="py-4 px-4 text-center">
                            <span className={`inline-flex h-2 w-2 rounded-full mr-1.5 ${b.Status === 'AKTIF' ? 'bg-emerald-500' : 'bg-slate-300'}`} />
                            <span className="text-[11px] font-bold text-slate-700">{b.Status}</span>
                          </td>
                          <td className="py-4 px-4 text-center">
                            <div className="flex items-center justify-center space-x-2">
                              {/* Print barcode button */}
                              <button
                                onClick={() => { setBarcodeBook(b); setIsBarcodeView(true); }}
                                className="p-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg transition"
                                title="Cetak Label Barcode"
                                id={`tu-book-barcode-${b.KodeBuku}`}
                              >
                                <BarcodeIcon className="h-4 w-4" />
                              </button>
                              
                              {/* Edit button */}
                              <button
                                onClick={() => handleOpenEditModal(b)}
                                className="p-1.5 bg-brand-blue-50 hover:bg-brand-blue-100 text-brand-blue-800 rounded-lg transition"
                                title="Edit Buku"
                                id={`tu-book-edit-${b.KodeBuku}`}
                              >
                                <Edit2 className="h-4 w-4" />
                              </button>

                              {/* Delete button */}
                              <button
                                onClick={() => handleDeleteBook(b.KodeBuku)}
                                className="p-1.5 bg-rose-50 hover:bg-rose-100 text-rose-600 rounded-lg transition"
                                title="Hapus Buku"
                                id={`tu-book-delete-${b.KodeBuku}`}
                              >
                                <Trash2 className="h-4 w-4" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>

              {/* PAGINATION PANEL */}
              {totalPages > 1 && (
                <div className="bg-slate-50 py-3.5 px-4 border-t border-slate-200 flex justify-between items-center text-xs text-slate-500 font-semibold">
                  <span>Menampilkan halaman {currentPage} dari {totalPages} ({filteredBuku.length} buku)</span>
                  <div className="flex items-center space-x-1">
                    <button
                      onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                      disabled={currentPage === 1}
                      className="p-1 bg-white border border-slate-200 rounded hover:bg-slate-100 disabled:opacity-40 transition"
                    >
                      <ChevronLeft className="h-4.5 w-4.5" />
                    </button>
                    <button
                      onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                      disabled={currentPage === totalPages}
                      className="p-1 bg-white border border-slate-200 rounded hover:bg-slate-100 disabled:opacity-40 transition"
                    >
                      <ChevronRight className="h-4.5 w-4.5" />
                    </button>
                  </div>
                </div>
              )}
            </div>
          </motion.div>
        ) : (
          /* VIEW 2: BARCODE LABELS GRID (For printing) */
          <motion.div 
            key="barcode-view"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="space-y-6"
          >
            {/* Toolbar for barcode printing */}
            <div className="bg-white p-5 rounded-xl border border-slate-200 flex justify-between items-center gap-4">
              <button
                onClick={() => { setIsBarcodeView(false); setBarcodeBook(null); }}
                className="inline-flex items-center space-x-1.5 text-xs font-semibold text-slate-600 hover:text-slate-900 transition"
              >
                <ChevronLeft className="h-4 w-4" />
                <span>Kembali ke Daftar Buku</span>
              </button>

              <div className="flex items-center space-x-3 text-xs">
                <span className="font-semibold text-slate-600">Jumlah Label Dicetak:</span>
                <input 
                  type="number"
                  value={barcodeQty}
                  onChange={(e) => setBarcodeQty(Math.max(1, Number(e.target.value)))}
                  className="w-16 px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-center font-bold"
                />
                
                <button
                  onClick={() => window.print()}
                  className="inline-flex items-center space-x-1.5 bg-brand-blue-800 hover:bg-brand-blue-700 text-white font-bold px-4 py-2 rounded-xl transition shadow"
                >
                  <Printer className="h-4 w-4" />
                  <span>Cetak Label Sekarang</span>
                </button>
              </div>
            </div>

            {/* Print area card */}
            {barcodeBook && (
              <div id="print-area" className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm max-w-4xl mx-auto">
                <div className="text-center mb-6">
                  <h3 className="text-base font-extrabold text-brand-blue-900 font-display">LABELS BARCODE BUKU SEKOLAH</h3>
                  <p className="text-[10px] text-slate-400 uppercase font-bold mt-0.5">SD XAVERIUS 2 JAMBI | SIPIN</p>
                </div>

                {/* Printable barcode layout blocks */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                  {Array.from({ length: barcodeQty }).map((_, idx) => (
                    <div 
                      key={idx} 
                      className="border-2 border-dashed border-slate-300 p-4 rounded-xl text-center space-y-3 bg-white flex flex-col items-center justify-between h-48"
                    >
                      <div>
                        <span className="text-[9px] font-bold text-brand-blue-800 block leading-none">SD XAVERIUS 2</span>
                        <h4 className="text-[10px] font-extrabold text-slate-900 line-clamp-2 mt-1 leading-tight h-8" title={barcodeBook.NamaBuku}>
                          {barcodeBook.NamaBuku}
                        </h4>
                      </div>

                      {/* Barcode artwork lines */}
                      {renderVisualBarcode(barcodeBook.Barcode)}

                      <div className="space-y-0.5">
                        <span className="text-[10px] font-bold font-mono text-slate-800 block tracking-widest">{barcodeBook.Barcode}</span>
                        <span className="text-[8px] font-extrabold text-brand-gold-600 uppercase tracking-wide">KODE: {barcodeBook.KodeBuku} | KELAS {barcodeBook.Kelas}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </motion.div>
        )}

      </AnimatePresence>

      {/* CRUD ADD/EDIT MODAL OVERLAY */}
      <AnimatePresence>
        {isModalOpen && (
          <div className="fixed inset-0 z-50 overflow-y-auto bg-black/40 backdrop-blur-xs flex items-center justify-center p-4">
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white rounded-3xl w-full max-w-lg shadow-2xl border border-slate-200 overflow-hidden text-left"
            >
              {/* Modal Title Banner */}
              <div className="bg-brand-blue-900 text-white p-6 flex justify-between items-center">
                <h3 className="text-md font-bold font-display text-brand-gold-400">
                  {selectedBook ? `Edit Buku: ${selectedBook.KodeBuku}` : 'Tambah Buku Pelajaran Baru'}
                </h3>
                <button onClick={() => setIsModalOpen(false)} className="text-white/80 hover:text-white rounded">
                  <X className="h-5 w-5" />
                </button>
              </div>

              {/* Modal Form */}
              <form onSubmit={handleSaveBook} className="p-6 md:p-8 space-y-4 text-xs font-semibold text-slate-700">
                <div className="grid grid-cols-2 gap-4">
                  {/* Kode Buku */}
                  <div className="space-y-1">
                    <label className="text-slate-500 uppercase">Kode Buku (Unik)</label>
                    <input 
                      type="text"
                      value={formKode}
                      onChange={(e) => setFormKode(e.target.value.toUpperCase())}
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg font-mono focus:border-brand-blue-600 focus:outline-none"
                      disabled={!!selectedBook}
                      required
                    />
                  </div>

                  {/* Barcode */}
                  <div className="space-y-1">
                    <label className="text-slate-500 uppercase">Barcode (Angka/EAN)</label>
                    <input 
                      type="text"
                      value={formBarcode}
                      onChange={(e) => setFormBarcode(e.target.value.replace(/\D/g, ''))}
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg font-mono focus:border-brand-blue-600 focus:outline-none"
                      required
                    />
                  </div>
                </div>

                {/* Nama Buku */}
                <div className="space-y-1">
                  <label className="text-slate-500 uppercase">Nama Buku Pelajaran</label>
                  <input 
                    type="text"
                    value={formNama}
                    onChange={(e) => setFormNama(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:border-brand-blue-600 focus:outline-none"
                    placeholder="Contoh: Seni Musik Kelas 1 Kurikulum Merdeka..."
                    required
                  />
                </div>

                <div className="grid grid-cols-3 gap-4">
                  {/* Kelas */}
                  <div className="space-y-1">
                    <label className="text-slate-500 uppercase">Tingkat Kelas</label>
                    <select
                      value={formKelas}
                      onChange={(e) => setFormKelas(e.target.value)}
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:border-brand-blue-600"
                    >
                      <option value="1">Kelas 1</option>
                      <option value="2">Kelas 2</option>
                      <option value="3">Kelas 3</option>
                      <option value="4">Kelas 4</option>
                      <option value="5">Kelas 5</option>
                      <option value="6">Kelas 6</option>
                    </select>
                  </div>

                  {/* Kategori */}
                  <div className="space-y-1">
                    <label className="text-slate-500 uppercase">Kategori</label>
                    <select
                      value={formKategori}
                      onChange={(e) => setFormKategori(e.target.value)}
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:border-brand-blue-600"
                    >
                      <option value="Agama">Agama</option>
                      <option value="Nasional">Nasional</option>
                      <option value="Sains">Sains</option>
                      <option value="Bahasa">Bahasa</option>
                      <option value="Seni">Seni</option>
                    </select>
                  </div>

                  {/* Status */}
                  <div className="space-y-1">
                    <label className="text-slate-500 uppercase">Status</label>
                    <select
                      value={formStatus}
                      onChange={(e) => setFormStatus(e.target.value as any)}
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:border-brand-blue-600"
                    >
                      <option value="AKTIF">AKTIF</option>
                      <option value="NONAKTIF">NONAKTIF</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  {/* Harga */}
                  <div className="space-y-1">
                    <label className="text-slate-500 uppercase">Harga Buku (Rupiah)</label>
                    <input 
                      type="number"
                      value={formHarga}
                      onChange={(e) => setFormHarga(Number(e.target.value))}
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:border-brand-blue-600 focus:outline-none"
                      required
                    />
                  </div>

                  {/* Stok */}
                  <div className="space-y-1">
                    <label className="text-slate-500 uppercase">Kuantitas Stok</label>
                    <input 
                      type="number"
                      value={formStok}
                      onChange={(e) => setFormStok(Number(e.target.value))}
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:border-brand-blue-600 focus:outline-none"
                      required
                    />
                  </div>
                </div>

                {/* Submit Panel */}
                <div className="pt-4 border-t border-slate-100 flex justify-end space-x-2">
                  <button
                    type="button"
                    onClick={() => setIsModalOpen(false)}
                    className="px-4 py-2 border border-slate-200 hover:bg-slate-50 text-slate-700 font-semibold rounded-lg"
                  >
                    Batal
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 bg-brand-blue-800 hover:bg-brand-blue-700 text-white font-bold rounded-lg shadow"
                    id="tu-save-book-submit"
                  >
                    Simpan Data
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
