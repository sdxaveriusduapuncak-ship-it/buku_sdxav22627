/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useApp } from '../contexts/AppContext';
import { Pesanan as PesananType, DetailPesanan } from '../types';
import { 
  Search, 
  Receipt, 
  Hourglass, 
  CheckCircle, 
  FileText, 
  CreditCard, 
  Calendar,
  X,
  Printer,
  ChevronLeft,
  ChevronRight,
  User,
  School
} from 'lucide-react';
import { generatePaymentReceiptPDF } from '../utils/pdfGenerator';
import { motion, AnimatePresence } from 'motion/react';

export default function Pesanan() {
  const { 
    pesanan, 
    detailPesanan, 
    transaksi, 
    confirmPayment, 
    schoolSettings,
    showToast 
  } = useApp();

  // Search and Filter states
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [classFilter, setClassFilter] = useState('ALL');
  const [dateFilter, setDateFilter] = useState('');

  // Selected Order for Detail Modal
  const [selectedOrder, setSelectedOrder] = useState<PesananType | null>(null);
  const [isDetailOpen, setIsDetailOpen] = useState(false);

  // Payment Confirmation Modal State
  const [isPayModalOpen, setIsPayModalOpen] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState('TUNAI');

  // Pagination
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 8;

  // Filter logic
  const filteredPesanan = pesanan.filter(p => {
    const matchesSearch = p.NamaSiswa.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          p.NoPesanan.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          p.NIS.includes(searchTerm);
    const matchesStatus = statusFilter === 'ALL' || p.Status === statusFilter;
    const matchesClass = classFilter === 'ALL' || p.Kelas === classFilter;
    const matchesDate = !dateFilter || p.Tanggal === dateFilter;

    return matchesSearch && matchesStatus && matchesClass && matchesDate;
  });

  // Paginated pesanan
  const totalPages = Math.ceil(filteredPesanan.length / itemsPerPage) || 1;
  const paginatedPesanan = filteredPesanan.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);

  const handleOpenDetail = (order: PesananType) => {
    setSelectedOrder(order);
    setIsDetailOpen(true);
  };

  const getOrderItems = (noPesanan: string): DetailPesanan[] => {
    return detailPesanan.filter(d => d.NoPesanan === noPesanan);
  };

  const handleOpenPaymentConfirm = (order: PesananType) => {
    setSelectedOrder(order);
    setPaymentMethod('TUNAI');
    setIsPayModalOpen(true);
  };

  const handleConfirmPaySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedOrder) return;

    await confirmPayment(selectedOrder.NoPesanan, paymentMethod, selectedOrder.Total);
    
    // Auto trigger PDF Receipt printout
    const items = getOrderItems(selectedOrder.NoPesanan);
    const payDate = new Date().toISOString().slice(0, 19).replace('T', ' ');
    
    generatePaymentReceiptPDF(
      { ...selectedOrder, Status: 'LUNAS' }, 
      items, 
      schoolSettings, 
      paymentMethod, 
      payDate
    );

    setIsPayModalOpen(false);
    setIsDetailOpen(false);
    showToast(`Pesanan ${selectedOrder.NoPesanan} Berhasil Dikonfirmasi Lunas & PDF Kuitansi diunduh!`, 'success');
  };

  const handlePrintDirectReceipt = (order: PesananType) => {
    const items = getOrderItems(order.NoPesanan);
    const tx = transaksi.find(t => t.NoPesanan === order.NoPesanan);
    const method = tx ? tx.MetodePembayaran : 'TUNAI';
    const date = tx ? tx.TanggalBayar : order.Tanggal;
    
    generatePaymentReceiptPDF(order, items, schoolSettings, method, date);
    showToast(`Mengekspor kuitansi PDF untuk ${order.NoPesanan}`, 'success');
  };

  return (
    <div className="space-y-6 text-left font-sans">
      
      {/* PAGE HEADER */}
      <div>
        <h2 className="text-xl font-bold font-display text-brand-blue-900 flex items-center space-x-2">
          <Receipt className="h-6 w-6 text-brand-gold-600" />
          <span>Kelola Registrasi Pesanan & Pembayaran</span>
        </h2>
        <p className="text-xs text-slate-500 mt-1">Verifikasi pembayaran murid, filter pesanan berdasarkan status lunas, dan ekspor bukti kuitansi PDF resmi sekolah.</p>
      </div>

      {/* FILTERS PANEL */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
        {/* Search */}
        <div className="relative">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search className="h-4 w-4 text-slate-400" />
          </div>
          <input 
            type="text"
            value={searchTerm}
            onChange={(e) => { setSearchTerm(e.target.value); setCurrentPage(1); }}
            placeholder="Cari Siswa atau No Pesanan..."
            className="w-full pl-9 pr-4 py-2 bg-slate-50 hover:bg-slate-100/50 focus:bg-white border border-slate-200 focus:border-brand-blue-600 rounded-lg text-xs font-semibold focus:outline-none transition-all"
            id="tu-order-search"
          />
        </div>

        {/* Status Filter */}
        <div>
          <select
            value={statusFilter}
            onChange={(e) => { setStatusFilter(e.target.value); setCurrentPage(1); }}
            className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs font-semibold focus:outline-none focus:border-brand-blue-600"
          >
            <option value="ALL">Semua Status</option>
            <option value="MENUNGGU PEMBAYARAN">Menunggu Pembayaran</option>
            <option value="LUNAS">Lunas</option>
            <option value="SELESAI">Selesai (Sudah Diambil)</option>
          </select>
        </div>

        {/* Class Filter */}
        <div>
          <select
            value={classFilter}
            onChange={(e) => { setClassFilter(e.target.value); setCurrentPage(1); }}
            className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs font-semibold focus:outline-none focus:border-brand-blue-600"
          >
            <option value="ALL">Semua Kelas</option>
            <option value="1A">Kelas 1A</option>
            <option value="1B">Kelas 1B</option>
            <option value="2A">Kelas 2A</option>
            <option value="2B">Kelas 2B</option>
            <option value="3A">Kelas 3A</option>
            <option value="3B">Kelas 3B</option>
            <option value="4A">Kelas 4A</option>
            <option value="4B">Kelas 4B</option>
            <option value="5A">Kelas 5A</option>
            <option value="5B">Kelas 5B</option>
            <option value="6A">Kelas 6A</option>
            <option value="6B">Kelas 6B</option>
          </select>
        </div>

        {/* Date Filter */}
        <div className="relative">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Calendar className="h-4 w-4 text-slate-400" />
          </div>
          <input 
            type="date"
            value={dateFilter}
            onChange={(e) => { setDateFilter(e.target.value); setCurrentPage(1); }}
            className="w-full pl-9 pr-4 py-2 bg-slate-50 hover:bg-slate-100/50 focus:bg-white border border-slate-200 focus:border-brand-blue-600 rounded-lg text-xs font-semibold focus:outline-none transition-all"
          />
        </div>
      </div>

      {/* DATA REGISTER TABLE */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full border-collapse text-left text-xs font-semibold text-slate-600">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-400 uppercase tracking-wider text-[10px]">
              <tr>
                <th className="py-3.5 px-4">No Pesanan</th>
                <th className="py-3.5 px-4">Tanggal</th>
                <th className="py-3.5 px-4">Nama Siswa (NIS)</th>
                <th className="py-3.5 px-4 text-center">Kelas</th>
                <th className="py-3.5 px-4 text-right">Total Tagihan</th>
                <th className="py-3.5 px-4 text-center">Status</th>
                <th className="py-3.5 px-4 text-center">Petugas</th>
                <th className="py-3.5 px-4 text-center">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium">
              {paginatedPesanan.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-8 text-center text-slate-400 font-bold">
                    Tidak ditemukan data pesanan buku yang sesuai dengan filter.
                  </td>
                </tr>
              ) : (
                paginatedPesanan.map((p) => (
                  <tr key={p.NoPesanan} className="hover:bg-slate-50/50">
                    <td className="py-4 px-4 font-mono font-bold text-brand-blue-900">{p.NoPesanan}</td>
                    <td className="py-4 px-4 text-slate-500 font-semibold">{p.Tanggal}</td>
                    <td className="py-4 px-4">
                      <div>
                        <span className="text-slate-900 font-bold block">{p.NamaSiswa}</span>
                        <span className="text-[10px] text-slate-400 font-mono">NIS: {p.NIS}</span>
                      </div>
                    </td>
                    <td className="py-4 px-4 text-center">
                      <span className="bg-brand-blue-50 text-brand-blue-800 text-[11px] font-extrabold px-2.5 py-1 rounded">
                        {p.Kelas}
                      </span>
                    </td>
                    <td className="py-4 px-4 text-right text-slate-950 font-extrabold">
                      Rp {p.Total.toLocaleString('id-ID')}
                    </td>
                    <td className="py-4 px-4 text-center">
                      <span className={`inline-block text-[10px] font-extrabold px-2.5 py-1 rounded-full ${
                        p.Status === 'LUNAS' 
                          ? 'bg-emerald-100 text-emerald-800' 
                          : p.Status === 'SELESAI'
                            ? 'bg-blue-100 text-blue-800'
                            : 'bg-amber-100 text-amber-800'
                      }`}>
                        {p.Status}
                      </span>
                    </td>
                    <td className="py-4 px-4 text-center text-slate-400 font-mono text-[10px]">{p.Petugas}</td>
                    <td className="py-4 px-4 text-center">
                      <div className="flex items-center justify-center space-x-2">
                        {/* Detail Trigger */}
                        <button
                          onClick={() => handleOpenDetail(p)}
                          className="px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-[11px] font-bold rounded-lg transition"
                          id={`tu-order-detail-btn-${p.NoPesanan}`}
                        >
                          Detail
                        </button>

                        {/* Payment Quick Trigger */}
                        {p.Status === 'MENUNGGU PEMBAYARAN' ? (
                          <button
                            onClick={() => handleOpenPaymentConfirm(p)}
                            className="px-2.5 py-1.5 bg-brand-blue-800 hover:bg-brand-blue-700 text-white text-[11px] font-bold rounded-lg shadow-sm transition"
                            id={`tu-confirm-pay-btn-${p.NoPesanan}`}
                          >
                            Konfirmasi Lunas
                          </button>
                        ) : (
                          /* Direct print invoice PDF */
                          <button
                            onClick={() => handlePrintDirectReceipt(p)}
                            className="p-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 rounded-lg transition"
                            title="Unduh Kuitansi PDF"
                            id={`tu-print-pdf-btn-${p.NoPesanan}`}
                          >
                            <Printer className="h-4 w-4" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* PAGINATION PANEL */}
        {totalPages > 1 && (
          <div className="bg-slate-50 py-3.5 px-4 border-t border-slate-200 flex justify-between items-center text-xs text-slate-500 font-semibold">
            <span>Menampilkan halaman {currentPage} dari {totalPages} ({filteredPesanan.length} pesanan)</span>
            <div className="flex items-center space-x-1">
              <button
                onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                disabled={currentPage === 1}
                className="p-1 bg-white border border-slate-200 rounded hover:bg-slate-100 disabled:opacity-40 transition"
              >
                <ChevronLeft className="h-4.5 w-4.5" />
              </button>
              <button
                onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                disabled={currentPage === totalPages}
                className="p-1 bg-white border border-slate-200 rounded hover:bg-slate-100 disabled:opacity-40 transition"
              >
                <ChevronRight className="h-4.5 w-4.5" />
              </button>
            </div>
          </div>
        )}
      </div>

      {/* DETAIL MODAL DRAWER OVERLAY */}
      <AnimatePresence>
        {isDetailOpen && selectedOrder && (
          <div className="fixed inset-0 z-50 overflow-y-auto bg-black/40 backdrop-blur-xs flex items-center justify-center p-4">
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white rounded-3xl w-full max-w-xl shadow-2xl border border-slate-200 overflow-hidden text-left"
            >
              {/* Header */}
              <div className="bg-brand-blue-900 text-white p-6 flex justify-between items-center">
                <div>
                  <h3 className="text-md font-bold font-display text-brand-gold-400">Rincian Pesanan Buku</h3>
                  <p className="text-[10px] text-slate-300 font-mono mt-0.5">{selectedOrder.NoPesanan}</p>
                </div>
                <button onClick={() => setIsDetailOpen(false)} className="text-white/80 hover:text-white rounded">
                  <X className="h-5 w-5" />
                </button>
              </div>

              {/* Body */}
              <div className="p-6 md:p-8 space-y-5 text-xs font-semibold text-slate-700">
                {/* Pupil and date info grids */}
                <div className="grid grid-cols-2 gap-4 bg-slate-50 p-4 rounded-xl border border-slate-200">
                  <div className="space-y-1">
                    <span className="text-slate-400 uppercase text-[10px]">Identitas Siswa</span>
                    <span className="text-slate-800 font-bold block text-sm">{selectedOrder.NamaSiswa}</span>
                    <span className="text-slate-500 text-xs block">NIS: {selectedOrder.NIS} | Kelas {selectedOrder.Kelas}</span>
                  </div>
                  <div className="space-y-1 text-right">
                    <span className="text-slate-400 uppercase text-[10px]">Tanggal Checkout</span>
                    <span className="text-slate-800 block text-xs">{selectedOrder.Tanggal}</span>
                    <span className="text-slate-400 uppercase text-[10px] block mt-1.5">Status Pesanan</span>
                    <span className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] font-extrabold ${
                      selectedOrder.Status === 'LUNAS' 
                        ? 'bg-emerald-100 text-emerald-800' 
                        : selectedOrder.Status === 'SELESAI'
                          ? 'bg-blue-100 text-blue-800'
                          : 'bg-amber-100 text-amber-800'
                    }`}>
                      {selectedOrder.Status}
                    </span>
                  </div>
                </div>

                {/* Items listing */}
                <div className="space-y-2">
                  <span className="text-slate-400 uppercase tracking-wider text-[10px] block">Buku Pelajaran Yang Dipesan:</span>
                  <div className="border border-slate-200 rounded-xl overflow-hidden">
                    <table className="w-full text-left border-collapse">
                      <thead className="bg-slate-50 border-b border-slate-200 text-slate-400 text-[10px]">
                        <tr>
                          <th className="py-2.5 px-3">Buku Pelajaran</th>
                          <th className="py-2.5 px-3 text-center">Qty</th>
                          <th className="py-2.5 px-3 text-right">Satuan</th>
                          <th className="py-2.5 px-3 text-right">Subtotal</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100 text-xs text-slate-700">
                        {getOrderItems(selectedOrder.NoPesanan).map((it, i) => (
                          <tr key={i}>
                            <td className="py-2.5 px-3 font-bold text-slate-800">{it.NamaBuku}</td>
                            <td className="py-2.5 px-3 text-center">{it.Qty} pcs</td>
                            <td className="py-2.5 px-3 text-right">Rp {it.Harga.toLocaleString('id-ID')}</td>
                            <td className="py-2.5 px-3 text-right font-extrabold text-slate-900">Rp {it.Subtotal.toLocaleString('id-ID')}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* Scanned/Dispatched book details */}
                {selectedOrder.Status !== 'MENUNGGU PEMBAYARAN' && (
                  <div className="space-y-1.5 border-t border-slate-100 pt-3 text-[11px] text-slate-500">
                    <span className="text-slate-400 uppercase tracking-wider text-[10px] block font-bold">Progress Penyerahan Buku Fisik:</span>
                    <div className="bg-blue-50/50 p-3 rounded-xl border border-blue-100 space-y-1">
                      {getOrderItems(selectedOrder.NoPesanan).map((it, idx) => {
                        const scanned = selectedOrder.BukuScanned?.[it.KodeBuku] || 0;
                        return (
                          <div key={idx} className="flex justify-between items-center text-xs">
                            <span className="font-semibold text-slate-700">{it.NamaBuku}</span>
                            <span className={`font-extrabold px-2 py-0.5 rounded ${scanned === it.Qty ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'}`}>
                              {scanned} / {it.Qty} pcs diserahkan
                            </span>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* Total tags */}
                <div className="border-t border-slate-100 pt-3 flex justify-between items-center">
                  <span className="text-slate-500 text-xs">TOTAL TAGIHAN AKHIR</span>
                  <span className="text-base font-extrabold text-slate-900">
                    Rp {selectedOrder.Total.toLocaleString('id-ID')}
                  </span>
                </div>

                {/* Modal footer controls */}
                <div className="pt-4 border-t border-slate-100 flex justify-end space-x-2">
                  <button
                    type="button"
                    onClick={() => setIsDetailOpen(false)}
                    className="px-4 py-2 border border-slate-200 hover:bg-slate-50 text-slate-700 font-semibold rounded-lg"
                  >
                    Tutup
                  </button>

                  {selectedOrder.Status === 'MENUNGGU PEMBAYARAN' ? (
                    <button
                      type="button"
                      onClick={() => handleOpenPaymentConfirm(selectedOrder)}
                      className="px-5 py-2 bg-brand-blue-800 hover:bg-brand-blue-700 text-white font-bold rounded-lg shadow"
                      id="tu-confirm-pay-detail"
                    >
                      Konfirmasi Lunas & Cetak
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={() => handlePrintDirectReceipt(selectedOrder)}
                      className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg shadow flex items-center space-x-1.5"
                    >
                      <Printer className="h-4 w-4" />
                      <span>Unduh Kuitansi PDF</span>
                    </button>
                  )}
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* CONFIRM PAYMENT DIALOG OVERLAY */}
      <AnimatePresence>
        {isPayModalOpen && selectedOrder && (
          <div className="fixed inset-0 z-50 overflow-y-auto bg-black/40 backdrop-blur-xs flex items-center justify-center p-4">
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white rounded-3xl w-full max-w-md shadow-2xl border border-slate-200 overflow-hidden text-left"
            >
              <div className="bg-brand-blue-900 text-white p-6">
                <h3 className="text-md font-bold font-display text-brand-gold-400">Pilih Metode Pembayaran</h3>
                <p className="text-[10px] text-slate-300 mt-0.5">Selesaikan konfirmasi kuitansi untuk: {selectedOrder.NoPesanan}</p>
              </div>

              <form onSubmit={handleConfirmPaySubmit} className="p-6 space-y-5 text-xs font-semibold text-slate-700">
                <div className="space-y-3">
                  <label className="text-slate-500 uppercase">Metode Pembayaran</label>
                  <div className="grid grid-cols-2 gap-3">
                    <button
                      type="button"
                      onClick={() => setPaymentMethod('TUNAI')}
                      className={`p-4 rounded-xl border-2 font-bold text-center flex flex-col items-center justify-center space-y-2 transition ${
                        paymentMethod === 'TUNAI' 
                          ? 'border-brand-blue-800 bg-brand-blue-50/20 text-brand-blue-900' 
                          : 'border-slate-200 hover:border-slate-300'
                      }`}
                    >
                      <CreditCard className="h-6 w-6" />
                      <span>TUNAI (CASH)</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setPaymentMethod('TRANSFER BANK')}
                      className={`p-4 rounded-xl border-2 font-bold text-center flex flex-col items-center justify-center space-y-2 transition ${
                        paymentMethod === 'TRANSFER BANK' 
                          ? 'border-brand-blue-800 bg-brand-blue-50/20 text-brand-blue-900' 
                          : 'border-slate-200 hover:border-slate-300'
                      }`}
                    >
                      <School className="h-6 w-6" />
                      <span>TRANSFER BANK</span>
                    </button>
                  </div>
                </div>

                <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-2">
                  <div className="flex justify-between">
                    <span className="text-slate-400">NAMA SISWA:</span>
                    <span className="text-slate-800 font-bold">{selectedOrder.NamaSiswa}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">TOTAL TUNAI:</span>
                    <span className="text-brand-blue-900 font-bold">Rp {selectedOrder.Total.toLocaleString('id-ID')}</span>
                  </div>
                </div>

                <div className="pt-4 border-t border-slate-100 flex justify-end space-x-2">
                  <button
                    type="button"
                    onClick={() => setIsPayModalOpen(false)}
                    className="px-4 py-2 border border-slate-200 hover:bg-slate-50 text-slate-700 font-semibold rounded-lg"
                  >
                    Batal
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg shadow"
                    id="tu-payment-confirm-submit"
                  >
                    Konfirmasi Lunas & Cetak
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
