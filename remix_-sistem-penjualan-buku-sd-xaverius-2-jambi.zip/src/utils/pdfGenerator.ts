/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { jsPDF } from 'jspdf';
import { Pesanan, DetailPesanan, SchoolSettings } from '../types';

export function generatePaymentReceiptPDF(
  order: Pesanan,
  items: DetailPesanan[],
  settings: SchoolSettings,
  paymentMethod: string = 'TUNAI',
  paymentDate: string = ''
) {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const primaryBlue = '#1d3f8c';
  const accentGold = '#b58900';

  // --- Background Decor (Subtle Top Bar) ---
  doc.setFillColor(29, 63, 140); // primaryBlue
  doc.rect(0, 0, 210, 6, 'F');
  doc.setFillColor(181, 137, 0); // accentGold
  doc.rect(0, 6, 210, 2, 'F');

  // --- School Header ---
  doc.setFont('Helvetica', 'bold');
  doc.setFontSize(16);
  doc.setTextColor(29, 63, 140);
  doc.text(settings.NamaSekolah.toUpperCase(), 14, 20);

  doc.setFont('Helvetica', 'normal');
  doc.setFontSize(9);
  doc.setTextColor(80, 80, 80);
  doc.text([
    settings.Alamat,
    `Telepon: ${settings.Telepon} | Tahun Pelajaran: ${settings.TahunPelajaran}`,
    'Email: info@sdxaverius2jambi.sch.id | Akreditasi: A'
  ], 14, 25);

  // Decorative Golden Line
  doc.setDrawColor(181, 137, 0);
  doc.setLineWidth(0.5);
  doc.line(14, 38, 196, 38);

  // --- Invoice Title ---
  doc.setFont('Helvetica', 'bold');
  doc.setFontSize(14);
  doc.setTextColor(20, 20, 20);
  doc.text('BUKTI PEMBAYARAN LUNAS', 14, 46);
  doc.setFontSize(10);
  doc.setTextColor(100, 100, 100);
  doc.text('PENJUALAN BUKU PELAJARAN SD XAVERIUS 2 JAMBI', 14, 51);

  // --- Order Metadata (2 Columns) ---
  doc.setFillColor(245, 247, 250);
  doc.rect(14, 56, 182, 32, 'F');
  doc.setDrawColor(220, 225, 230);
  doc.setLineWidth(0.2);
  doc.rect(14, 56, 182, 32, 'S');

  doc.setFont('Helvetica', 'bold');
  doc.setFontSize(9);
  doc.setTextColor(50, 50, 50);
  
  // Left Column
  doc.text('INFORMASI PESANAN', 18, 62);
  doc.setFont('Helvetica', 'normal');
  doc.text(`No. Pesanan :  ${order.NoPesanan}`, 18, 68);
  doc.text(`Tanggal     :  ${order.Tanggal}`, 18, 74);
  doc.text(`Status      :  ${order.Status}`, 18, 80);

  // Right Column
  doc.setFont('Helvetica', 'bold');
  doc.text('DATA SISWA', 110, 62);
  doc.setFont('Helvetica', 'normal');
  doc.text(`Nama Siswa  :  ${order.NamaSiswa}`, 110, 68);
  doc.text(`NIS / Kelas :  ${order.NIS} / Kelas ${order.Kelas}`, 110, 74);
  doc.text(`Pembayaran  :  ${paymentMethod} (${paymentDate || order.Tanggal})`, 110, 80);

  // --- Table Header ---
  const startY = 95;
  doc.setFillColor(29, 63, 140);
  doc.rect(14, startY, 182, 8, 'F');

  doc.setFont('Helvetica', 'bold');
  doc.setFontSize(9);
  doc.setTextColor(255, 255, 255);
  doc.text('NO', 18, startY + 5);
  doc.text('NAMA BUKU PELAJARAN', 30, startY + 5);
  doc.text('QTY', 125, startY + 5, { align: 'right' });
  doc.text('HARGA SATUAN', 155, startY + 5, { align: 'right' });
  doc.text('SUBTOTAL', 190, startY + 5, { align: 'right' });

  // --- Table Items ---
  let currentY = startY + 8;
  doc.setFont('Helvetica', 'normal');
  doc.setTextColor(40, 40, 40);

  items.forEach((item, index) => {
    // Alternating background colors
    if (index % 2 === 1) {
      doc.setFillColor(248, 250, 252);
      doc.rect(14, currentY, 182, 8, 'F');
    }
    
    // Draw row bottom line
    doc.setDrawColor(230, 235, 240);
    doc.line(14, currentY + 8, 196, currentY + 8);

    doc.text((index + 1).toString(), 18, currentY + 5);
    
    // Handle text overflow for long book titles
    const title = item.NamaBuku;
    const truncatedTitle = title.length > 50 ? title.substring(0, 47) + '...' : title;
    doc.text(truncatedTitle, 30, currentY + 5);
    
    doc.text(item.Qty.toString(), 125, currentY + 5, { align: 'right' });
    doc.text(`Rp ${item.Harga.toLocaleString('id-ID')}`, 155, currentY + 5, { align: 'right' });
    doc.text(`Rp ${item.Subtotal.toLocaleString('id-ID')}`, 190, currentY + 5, { align: 'right' });

    currentY += 8;
  });

  // --- Table Footer (Total) ---
  doc.setFillColor(240, 244, 248);
  doc.rect(14, currentY, 182, 10, 'F');
  
  doc.setFont('Helvetica', 'bold');
  doc.setTextColor(29, 63, 140);
  doc.text('TOTAL PEMBAYARAN', 30, currentY + 6);
  doc.text(`Rp ${order.Total.toLocaleString('id-ID')}`, 190, currentY + 6, { align: 'right' });

  // --- Signatures & Stamp Section ---
  const signY = currentY + 20;
  
  // Left Column - Orang Tua
  doc.setFont('Helvetica', 'normal');
  doc.setFontSize(9);
  doc.setTextColor(60, 60, 60);
  doc.text('Orang Tua / Wali Murid,', 30, signY);
  doc.line(20, signY + 22, 70, signY + 22);
  
  // Right Column - TU & Stamp
  doc.text('Jambi, ' + new Date().toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' }), 135, signY - 5);
  doc.text('Petugas Tata Usaha,', 135, signY);
  
  // Simulated Stamp
  doc.setDrawColor(181, 137, 0); // Gold stamp outline
  doc.setLineWidth(0.4);
  doc.circle(150, signY + 11, 10, 'S');
  doc.circle(150, signY + 11, 9.5, 'S');
  doc.setFontSize(6);
  doc.setTextColor(181, 137, 0);
  doc.setFont('Helvetica', 'bold');
  doc.text('SD XAVERIUS 2', 150, signY + 10, { align: 'center' });
  doc.text('SIPIN - JAMBI', 150, signY + 13, { align: 'center' });

  // Signature line for staff
  doc.setDrawColor(100, 100, 100);
  doc.setLineWidth(0.2);
  doc.line(125, signY + 22, 175, signY + 22);
  doc.setFont('Helvetica', 'italic');
  doc.setFontSize(8);
  doc.setTextColor(120, 120, 120);
  doc.text(`( ${order.Petugas || 'Tata Usaha'} )`, 150, signY + 26, { align: 'center' });

  // Save the PDF
  doc.save(`KUITANSI-${order.NoPesanan}.pdf`);
}
