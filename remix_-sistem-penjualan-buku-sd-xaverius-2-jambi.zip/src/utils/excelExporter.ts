/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Buku, Siswa } from '../types';

/**
 * Exports any flat array of objects into a downloadable CSV (Excel-compatible) spreadsheet.
 */
export function exportToCSV(data: any[], filename: string) {
  if (!data || data.length === 0) return;

  const headers = Object.keys(data[0]);
  const csvRows = [];

  // Add the headers
  csvRows.push(headers.join(','));

  // Add the rows
  for (const row of data) {
    const values = headers.map(header => {
      const val = row[header];
      // Escape values with double quotes if they contain commas or quotes
      let strVal = val === null || val === undefined ? '' : String(val);
      if (strVal.includes(',') || strVal.includes('"') || strVal.includes('\n')) {
        strVal = `"${strVal.replace(/"/g, '""')}"`;
      }
      return strVal;
    });
    csvRows.push(values.join(','));
  }

  const csvContent = 'data:text/csv;charset=utf-8,\uFEFF' + csvRows.join('\n'); // Add BOM for Excel UTF-8 support
  const encodedUri = encodeURI(csvContent);
  const link = document.createElement('a');
  link.setAttribute('href', encodedUri);
  link.setAttribute('download', `${filename}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

/**
 * Parses a plain CSV string (from a file upload) into structured objects.
 */
export function parseCSV(csvText: string): any[] {
  const lines = csvText.split(/\r?\n/);
  if (lines.length <= 1) return [];

  const headers = lines[0].split(',').map(h => h.trim().replace(/^"|"$/g, ''));
  const results: any[] = [];

  for (let i = 1; i < lines.length; i++) {
    const line = lines[i].trim();
    if (!line) continue;

    // Simple CSV split (handles double quotes with commas roughly, which is enough for our app)
    const matches = line.match(/(".*?"|[^",\s]+)(?=\s*,|\s*$)/g) || line.split(',');
    const values = matches.map(v => v.trim().replace(/^"|"$/g, ''));

    const obj: any = {};
    headers.forEach((header, index) => {
      obj[header] = values[index] || '';
    });
    results.push(obj);
  }

  return results;
}

/**
 * Seeds or structures standard books imported from a simulated Excel file.
 */
export function processImportedBooks(parsedRows: any[]): Buku[] {
  return parsedRows.map(row => ({
    KodeBuku: row.KodeBuku || `B-${Math.floor(100 + Math.random() * 900)}`,
    Barcode: row.Barcode || String(Math.floor(899000000 + Math.random() * 99999)),
    NamaBuku: row.NamaBuku || 'Buku Tanpa Nama',
    Kelas: String(row.Kelas || '1'),
    Harga: Number(row.Harga || 50000),
    Stok: Number(row.Stok || 10),
    Kategori: row.Kategori || 'Umum',
    Status: (row.Status?.toUpperCase() === 'NONAKTIF' ? 'NONAKTIF' : 'AKTIF') as any,
    Foto: row.Foto || 'https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=400&auto=format&fit=crop&q=60'
  }));
}

/**
 * Seeds or structures standard students imported from a simulated Excel file.
 */
export function processImportedSiswa(parsedRows: any[]): Siswa[] {
  return parsedRows.map(row => ({
    NIS: row.NIS || String(Math.floor(10203000 + Math.random() * 9999)),
    Nama: row.Nama || 'Siswa Baru',
    Kelas: row.Kelas || '1A',
    JenisKelamin: (row.JenisKelamin?.toUpperCase() === 'P' ? 'P' : 'L') as any,
    NamaOrtu: row.NamaOrtu || 'Orang Tua',
    NoHP: row.NoHP || '081200000000'
  }));
}
