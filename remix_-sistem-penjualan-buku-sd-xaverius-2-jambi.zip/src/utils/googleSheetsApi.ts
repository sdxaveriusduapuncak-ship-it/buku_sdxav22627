/**
 * Google Sheets REST API integration utility
 */

export interface SheetSchema {
  name: string;
  headers: string[];
}

export const SHEET_SCHEMAS: SheetSchema[] = [
  { name: 'Siswa', headers: ['NIS', 'Nama', 'Kelas', 'JenisKelamin', 'NamaOrtu', 'NoHP'] },
  { name: 'Buku', headers: ['KodeBuku', 'Barcode', 'NamaBuku', 'Kelas', 'Harga', 'Stok', 'Kategori', 'Status'] },
  { name: 'Pesanan', headers: ['NoPesanan', 'Tanggal', 'NamaSiswa', 'NIS', 'Kelas', 'Total', 'Status', 'Petugas'] },
  { name: 'DetailPesanan', headers: ['NoPesanan', 'KodeBuku', 'NamaBuku', 'Qty', 'Harga', 'Subtotal'] },
  { name: 'Transaksi', headers: ['NoTransaksi', 'NoPesanan', 'TanggalBayar', 'MetodePembayaran', 'Jumlah', 'Status'] },
  { name: 'LogStok', headers: ['Tanggal', 'KodeBuku', 'NamaBuku', 'Masuk', 'Keluar', 'Sisa', 'Petugas'] },
  { name: 'User', headers: ['Username', 'Password', 'Role'] }
];

/**
 * Extracts Spreadsheet ID from a standard Google Sheets URL or returns the input if already an ID
 */
export function extractSpreadsheetId(urlOrId: string): string {
  if (!urlOrId) return '';
  const match = urlOrId.match(/\/spreadsheets\/d\/([a-zA-Z0-9-_]+)/);
  return match ? match[1] : urlOrId.trim();
}

/**
 * Fetch list of sheet titles currently existing in the spreadsheet
 */
export async function getExistingSheets(accessToken: string, spreadsheetId: string): Promise<string[]> {
  const url = `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}?fields=sheets.properties.title`;
  const res = await fetch(url, {
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    }
  });

  if (!res.ok) {
    const errorData = await res.json().catch(() => ({}));
    throw new Error(errorData.error?.message || `Gagal mengambil metadata spreadsheet (HTTP ${res.status})`);
  }

  const data = await res.json();
  return data.sheets?.map((s: any) => s.properties.title) || [];
}

/**
 * Initialize all missing tables with correct headers inside the user's spreadsheet
 */
export async function initializeSpreadsheet(accessToken: string, spreadsheetId: string): Promise<{ created: string[]; existed: string[] }> {
  const existing = await getExistingSheets(accessToken, spreadsheetId);
  const toCreate = SHEET_SCHEMAS.filter(s => !existing.includes(s.name));

  if (toCreate.length > 0) {
    // Add missing sheets via batchUpdate
    const requests = toCreate.map(s => ({
      addSheet: {
        properties: {
          title: s.name
        }
      }
    }));

    const updateUrl = `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}:batchUpdate`;
    const updateRes = await fetch(updateUrl, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ requests })
    });

    if (!updateRes.ok) {
      const errorData = await updateRes.json().catch(() => ({}));
      throw new Error(`Gagal membuat tabel baru: ${errorData.error?.message || updateRes.statusText}`);
    }
  }

  // Populate headers for newly created sheets or ensure headers exist
  for (const schema of SHEET_SCHEMAS) {
    // We can write/overwrite the header row (Row 1) to be safe
    const range = `${schema.name}!A1:${getColLetter(schema.headers.length)}1`;
    const writeUrl = `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${range}?valueInputOption=USER_ENTERED`;
    await fetch(writeUrl, {
      method: 'PUT',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        range,
        majorDimension: 'ROWS',
        values: [schema.headers]
      })
    });
  }

  return {
    created: toCreate.map(s => s.name),
    existed: SHEET_SCHEMAS.map(s => s.name).filter(name => existing.includes(name))
  };
}

/**
 * Fetch all records from a specific sheet
 */
export async function fetchSheetData<T>(accessToken: string, spreadsheetId: string, sheetName: string): Promise<T[]> {
  const range = `${sheetName}!A1:Z1000`; // Fetch first 1000 rows
  const url = `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${range}`;
  
  const res = await fetch(url, {
    headers: {
      Authorization: `Bearer ${accessToken}`
    }
  });

  if (res.status === 404) {
    return []; // Sheet doesn't exist or is empty
  }

  if (!res.ok) {
    const errorData = await res.json().catch(() => ({}));
    throw new Error(`Gagal membaca data ${sheetName}: ${errorData.error?.message || res.statusText}`);
  }

  const data = await res.json();
  const rows: any[][] = data.values || [];
  if (rows.length <= 1) return [];

  const headers = rows[0];
  const items: T[] = [];

  for (let i = 1; i < rows.length; i++) {
    const row = rows[i];
    const item: any = {};
    headers.forEach((header, index) => {
      let val = row[index] !== undefined ? row[index] : '';
      
      // Parse numeric fields if possible
      if (val !== '' && !isNaN(Number(val)) && (header === 'Harga' || header === 'Stok' || header === 'Qty' || header === 'Total' || header === 'Subtotal' || header === 'Jumlah' || header === 'Masuk' || header === 'Keluar' || header === 'Sisa')) {
        val = Number(val);
      }
      
      // Parse BukuScanned JSON if relevant
      if (header === 'BukuScanned' && typeof val === 'string' && val.startsWith('{')) {
        try {
          val = JSON.parse(val);
        } catch {
          // keep as string if parse fails
        }
      }

      item[header] = val;
    });
    items.push(item);
  }

  return items;
}

/**
 * Replace entire sheet data with an array of objects
 */
export async function replaceSheetData(accessToken: string, spreadsheetId: string, sheetName: string, dataArray: any[], headers: string[]) {
  // 1. Clear sheet
  const clearUrl = `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${sheetName}!A1:Z1000:clear`;
  await fetch(clearUrl, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${accessToken}`
    }
  });

  // 2. Prepare values (headers + rows)
  const values: any[][] = [headers];
  
  dataArray.forEach(item => {
    const row: any[] = [];
    headers.forEach(h => {
      let val = item[h];
      if (val === undefined || val === null) {
        val = '';
      } else if (typeof val === 'object') {
        val = JSON.stringify(val); // e.g. BukuScanned object
      }
      row.push(val);
    });
    values.push(row);
  });

  // 3. Write new data
  const range = `${sheetName}!A1:${getColLetter(headers.length)}${values.length}`;
  const writeUrl = `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${range}?valueInputOption=USER_ENTERED`;
  const res = await fetch(writeUrl, {
    method: 'PUT',
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      range,
      majorDimension: 'ROWS',
      values
    })
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(`Gagal menulis data ${sheetName}: ${err.error?.message || res.statusText}`);
  }
}

/**
 * Append a single row object to sheet
 */
export async function appendSheetRow(accessToken: string, spreadsheetId: string, sheetName: string, rowObj: any, headers: string[]) {
  const row: any[] = [];
  headers.forEach(h => {
    let val = rowObj[h];
    if (val === undefined || val === null) {
      val = '';
    } else if (typeof val === 'object') {
      val = JSON.stringify(val);
    }
    row.push(val);
  });

  const range = `${sheetName}!A:A`;
  const url = `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${range}:append?valueInputOption=USER_ENTERED`;
  const res = await fetch(url, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      range,
      majorDimension: 'ROWS',
      values: [row]
    })
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(`Gagal menambahkan baris ke ${sheetName}: ${err.error?.message || res.statusText}`);
  }
}

/**
 * Updates a specific field on a row identified by a key column and value
 */
export async function updateSheetRowField(
  accessToken: string, 
  spreadsheetId: string, 
  sheetName: string, 
  keyColumn: string, 
  keyValue: string | number, 
  targetColumn: string, 
  targetValue: any,
  headers: string[]
): Promise<boolean> {
  // 1. Fetch existing values to find the matching row
  const range = `${sheetName}!A1:Z1000`;
  const url = `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${range}`;
  const res = await fetch(url, { headers: { Authorization: `Bearer ${accessToken}` } });
  
  if (!res.ok) return false;
  
  const data = await res.json();
  const rows: any[][] = data.values || [];
  if (rows.length <= 1) return false;

  const fetchedHeaders = rows[0];
  const keyColIdx = fetchedHeaders.indexOf(keyColumn);
  const targetColIdx = fetchedHeaders.indexOf(targetColumn);

  if (keyColIdx === -1 || targetColIdx === -1) return false;

  // 2. Find row index (1-indexed, header is row 1, so row i is at row index i + 1)
  for (let i = 1; i < rows.length; i++) {
    const row = rows[i];
    if (row[keyColIdx]?.toString() === keyValue.toString()) {
      const rowNum = i + 1;
      const targetColLetter = getColLetter(targetColIdx + 1);
      const updateRange = `${sheetName}!${targetColLetter}${rowNum}`;
      const updateUrl = `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${updateRange}?valueInputOption=USER_ENTERED`;
      
      const payloadValue = typeof targetValue === 'object' ? JSON.stringify(targetValue) : targetValue;

      const updateRes = await fetch(updateUrl, {
        method: 'PUT',
        headers: {
          Authorization: `Bearer ${accessToken}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          range: updateRange,
          majorDimension: 'ROWS',
          values: [[payloadValue]]
        })
      });

      return updateRes.ok;
    }
  }

  return false;
}

/**
 * Helper to translate column index (1-indexed) to Google Sheet Column letter (e.g. 1 -> A, 2 -> B, 27 -> AA)
 */
function getColLetter(colNum: number): string {
  let temp = colNum;
  let letter = '';
  while (temp > 0) {
    const m = (temp - 1) % 26;
    letter = String.fromCharCode(65 + m) + letter;
    temp = Math.floor((temp - m) / 26);
  }
  return letter;
}
