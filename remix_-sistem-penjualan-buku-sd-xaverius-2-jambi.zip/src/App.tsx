/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { AppProvider, useApp } from './contexts/AppContext';
import Home from './pages/Home';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import DataBuku from './pages/DataBuku';
import Pesanan from './pages/Pesanan';
import ScanBarcode from './pages/ScanBarcode';
import AdminSiswa from './pages/AdminSiswa';
import AdminSync from './pages/AdminSync';
import DashboardLayout from './layouts/DashboardLayout';
import { 
  CheckCircle2, 
  XCircle, 
  Info, 
  X 
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

function AppContent() {
  const { activeUser, toastMsg } = useApp();
  
  // Custom navigation state
  // If activeUser is logged in, default to dashboard. Else 'parent-home'.
  const [currentScreen, setCurrentScreen] = useState<string>(() => {
    return localStorage.getItem('xaverius_active_user') ? 'dashboard' : 'parent-home';
  });

  // Main administrative view routing based on state tab selection
  const renderDashboardScreen = () => {
    switch (currentScreen) {
      case 'dashboard':
        return <Dashboard setActiveTab={setCurrentScreen} />;
      case 'buku':
        return <DataBuku />;
      case 'pesanan':
        return <Pesanan />;
      case 'scan':
        return <ScanBarcode />;
      case 'siswa':
        return <AdminSiswa />;
      case 'sync':
        return <AdminSync />;
      default:
        return <Dashboard setActiveTab={setCurrentScreen} />;
    }
  };

  return (
    <div className="relative min-h-screen bg-slate-50 overflow-x-hidden selection:bg-brand-gold-500/30 selection:text-brand-blue-900">
      <AnimatePresence mode="wait">
        
        {/* VIEW 1: PARENT PORTAL GREETING */}
        {currentScreen === 'parent-home' && (
          <motion.div
            key="parent-home"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="min-h-screen"
          >
            <Home onGoToLogin={() => setCurrentScreen('login')} />
          </motion.div>
        )}

        {/* VIEW 2: STAFF LOGIN GATEWAY */}
        {currentScreen === 'login' && (
          <motion.div
            key="login-screen"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <Login 
              onGoBack={() => setCurrentScreen('parent-home')} 
              onLoginSuccess={() => setCurrentScreen('dashboard')}
            />
          </motion.div>
        )}

        {/* VIEW 3: STAFF ADMINISTRATIVE BACKEND */}
        {activeUser && ['dashboard', 'buku', 'pesanan', 'scan', 'siswa', 'sync'].includes(currentScreen) && (
          <motion.div
            key="admin-workspace"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <DashboardLayout activeTab={currentScreen} setActiveTab={setCurrentScreen}>
              {renderDashboardScreen()}
            </DashboardLayout>
          </motion.div>
        )}

      </AnimatePresence>

      {/* GLOBAL SLIDING TOAST NOTIFICATIONS */}
      <AnimatePresence>
        {toastMsg && (
          <motion.div
            initial={{ opacity: 0, y: 50, x: 0, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            className="fixed bottom-6 right-6 z-50 max-w-sm w-full bg-white rounded-2xl shadow-2xl border border-slate-200 p-4 flex items-start space-x-3 text-left"
            id="global-toast-card"
          >
            {/* Status Icons */}
            <div className="shrink-0 mt-0.5">
              {toastMsg.type === 'success' && <CheckCircle2 className="h-5 w-5 text-emerald-500" />}
              {toastMsg.type === 'error' && <XCircle className="h-5 w-5 text-rose-500" />}
              {toastMsg.type === 'info' && <Info className="h-5 w-5 text-brand-blue-600" />}
            </div>

            {/* Message block */}
            <div className="flex-1">
              <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wide">
                {toastMsg.type === 'success' ? 'Sukses' : toastMsg.type === 'error' ? 'Peringatan' : 'Informasi'}
              </h4>
              <p className="text-xs text-slate-500 font-semibold mt-0.5 leading-relaxed">
                {toastMsg.text}
              </p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
