/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Siswa, Buku, User, SchoolSettings, Pesanan, DetailPesanan, Transaksi, LogStok, AuditLog } from './types';

export const INITIAL_SISWA: Siswa[] = [
  { NIS: "10203001", Nama: "Aditya Pratama", Kelas: "1A", JenisKelamin: "L", NamaOrtu: "Budi Pratama", NoHP: "081234567890" },
  { NIS: "10203002", Nama: "Angelina Wijaya", Kelas: "1A", JenisKelamin: "P", NamaOrtu: "Hendra Wijaya", NoHP: "081298765432" },
  { NIS: "10203003", Nama: "Benedictus Kevin", Kelas: "1B", JenisKelamin: "L", NamaOrtu: "Stevanus", NoHP: "085345678901" },
  { NIS: "10203004", Nama: "Clara Sitorus", Kelas: "1B", JenisKelamin: "P", NamaOrtu: "Aris Sitorus", NoHP: "082134561234" },
  { NIS: "10203005", Nama: "Daniel Christian", Kelas: "2A", JenisKelamin: "L", NamaOrtu: "Yohan Christian", NoHP: "081366549988" },
  { NIS: "10203006", Nama: "Elsa Mareta", Kelas: "2A", JenisKelamin: "P", NamaOrtu: "Antonius", NoHP: "081199887766" },
  { NIS: "10203007", Nama: "Ferdinand Gunawan", Kelas: "2B", JenisKelamin: "L", NamaOrtu: "Willy Gunawan", NoHP: "087755441122" },
  { NIS: "10203008", Nama: "Gabriella Christie", Kelas: "3A", JenisKelamin: "P", NamaOrtu: "Frans Christie", NoHP: "089912345678" },
  { NIS: "10203009", Nama: "Ignatius Ryan", Kelas: "3B", JenisKelamin: "L", NamaOrtu: "Sutrisno", NoHP: "085211223344" },
  { NIS: "10203010", Nama: "Jessica Amanda", Kelas: "4A", JenisKelamin: "P", NamaOrtu: "Suwito Amanda", NoHP: "081288776655" },
  { NIS: "10203011", Nama: "Kristoforus Alvin", Kelas: "4B", JenisKelamin: "L", NamaOrtu: "Rudolf Alvin", NoHP: "081344332211" },
  { NIS: "10203012", Nama: "Maria Angelina", Kelas: "5A", JenisKelamin: "P", NamaOrtu: "Agustinus", NoHP: "081255443322" },
  { NIS: "10203013", Nama: "Nicholas Saputra", Kelas: "5B", JenisKelamin: "L", NamaOrtu: "Thomas Saputra", NoHP: "082266778899" },
  { NIS: "10203014", Nama: "Patricia Lestari", Kelas: "6A", JenisKelamin: "P", NamaOrtu: "Vincentius", NoHP: "085388771122" },
  { NIS: "10203015", Nama: "Samuel Hermawan", Kelas: "6B", JenisKelamin: "L", NamaOrtu: "Andi Hermawan", NoHP: "081277665544" }
];

export const INITIAL_BUKU: Buku[] = [
  // Kelas 1
  { KodeBuku: "B101", Barcode: "899000101", NamaBuku: "Pendidikan Agama Katolik & Budi Pekerti - Kelas 1", Kelas: "1", Harga: 75000, Stok: 40, Kategori: "Agama", Status: "AKTIF", Foto: "https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=400&auto=format&fit=crop&q=60" },
  { KodeBuku: "B102", Barcode: "899000102", NamaBuku: "Pendidikan Pancasila - Kelas 1 Kurikulum Merdeka", Kelas: "1", Harga: 65000, Stok: 45, Kategori: "Nasional", Status: "AKTIF", Foto: "https://images.unsplash.com/photo-1592492159418-09f31333c516?w=400&auto=format&fit=crop&q=60" },
  { KodeBuku: "B103", Barcode: "899000103", NamaBuku: "Bahasa Indonesia: Aku Bisa! - Kelas 1", Kelas: "1", Harga: 58000, Stok: 50, Kategori: "Bahasa", Status: "AKTIF", Foto: "https://images.unsplash.com/photo-1512820790803-83ca734da794?w=400&auto=format&fit=crop&q=60" },
  { KodeBuku: "B104", Barcode: "899000104", NamaBuku: "Matematika Belajar Bersama Temanmu - Kelas 1 Vol 1", Kelas: "1", Harga: 48000, Stok: 35, Kategori: "Sains", Status: "AKTIF", Foto: "https://images.unsplash.com/photo-1635315300953-890333e111a8?w=400&auto=format&fit=crop&q=60" },
  { KodeBuku: "B105", Barcode: "899000105", NamaBuku: "My Next Words (English for Elementary School) - Kelas 1", Kelas: "1", Harga: 42000, Stok: 60, Kategori: "Bahasa", Status: "AKTIF", Foto: "https://images.unsplash.com/photo-1471286174243-e85ff856c364?w=400&auto=format&fit=crop&q=60" },

  // Kelas 2
  { KodeBuku: "B201", Barcode: "899000201", NamaBuku: "Pendidikan Agama Katolik & Budi Pekerti - Kelas 2", Kelas: "2", Harga: 75000, Stok: 35, Kategori: "Agama", Status: "AKTIF", Foto: "https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=400&auto=format&fit=crop&q=60" },
  { KodeBuku: "B202", Barcode: "899000202", NamaBuku: "Pendidikan Pancasila - Kelas 2 Kurikulum Merdeka", Kelas: "2", Harga: 68000, Stok: 38, Kategori: "Nasional", Status: "AKTIF", Foto: "https://images.unsplash.com/photo-1592492159418-09f31333c516?w=400&auto=format&fit=crop&q=60" },
  { KodeBuku: "B203", Barcode: "899000203", NamaBuku: "Bahasa Indonesia: Keluargaku Unik - Kelas 2", Kelas: "2", Harga: 60000, Stok: 40, Kategori: "Bahasa", Status: "AKTIF", Foto: "https://images.unsplash.com/photo-1512820790803-83ca734da794?w=400&auto=format&fit=crop&q=60" },
  { KodeBuku: "B204", Barcode: "899000204", NamaBuku: "Matematika Belajar Bersama Temanmu - Kelas 2 Vol 1", Kelas: "2", Harga: 50000, Stok: 30, Kategori: "Sains", Status: "AKTIF", Foto: "https://images.unsplash.com/photo-1635315300953-890333e111a8?w=400&auto=format&fit=crop&q=60" },

  // Kelas 3
  { KodeBuku: "B301", Barcode: "899000301", NamaBuku: "Pendidikan Agama Katolik & Budi Pekerti - Kelas 3", Kelas: "3", Harga: 78000, Stok: 40, Kategori: "Agama", Status: "AKTIF", Foto: "https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=400&auto=format&fit=crop&q=60" },
  { KodeBuku: "B302", Barcode: "899000302", NamaBuku: "Bahasa Indonesia: Kawan Seiring - Kelas 3", Kelas: "3", Harga: 62000, Stok: 42, Kategori: "Bahasa", Status: "AKTIF", Foto: "https://images.unsplash.com/photo-1512820790803-83ca734da794?w=400&auto=format&fit=crop&q=60" },
  { KodeBuku: "B303", Barcode: "899000303", NamaBuku: "Matematika Belajar Bersama Temanmu - Kelas 3 Vol 1", Kelas: "3", Harga: 52000, Stok: 35, Kategori: "Sains", Status: "AKTIF", Foto: "https://images.unsplash.com/photo-1635315300953-890333e111a8?w=400&auto=format&fit=crop&q=60" },

  // Kelas 4
  { KodeBuku: "B401", Barcode: "899000401", NamaBuku: "Pendidikan Agama Katolik & Budi Pekerti - Kelas 4", Kelas: "4", Harga: 80000, Stok: 28, Kategori: "Agama", Status: "AKTIF", Foto: "https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=400&auto=format&fit=crop&q=60" },
  { KodeBuku: "B402", Barcode: "899000402", NamaBuku: "IPAS (Ilmu Pengetahuan Alam dan Sosial) - Kelas 4", Kelas: "4", Harga: 72000, Stok: 30, Kategori: "Sains", Status: "AKTIF", Foto: "https://images.unsplash.com/photo-1532094349884-543bc11b234d?w=400&auto=format&fit=crop&q=60" },

  // Kelas 5
  { KodeBuku: "B501", Barcode: "899000501", NamaBuku: "Pendidikan Agama Katolik & Budi Pekerti - Kelas 5", Kelas: "5", Harga: 82000, Stok: 25, Kategori: "Agama", Status: "AKTIF", Foto: "https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=400&auto=format&fit=crop&q=60" },
  { KodeBuku: "B502", Barcode: "899000502", NamaBuku: "IPAS (Ilmu Pengetahuan Alam dan Sosial) - Kelas 5", Kelas: "5", Harga: 75000, Stok: 32, Kategori: "Sains", Status: "AKTIF", Foto: "https://images.unsplash.com/photo-1532094349884-543bc11b234d?w=400&auto=format&fit=crop&q=60" },

  // Kelas 6
  { KodeBuku: "B601", Barcode: "899000601", NamaBuku: "Pendidikan Agama Katolik & Budi Pekerti - Kelas 6", Kelas: "6", Harga: 85000, Stok: 20, Kategori: "Agama", Status: "AKTIF", Foto: "https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=400&auto=format&fit=crop&q=60" },
  { KodeBuku: "B602", Barcode: "899000602", NamaBuku: "IPAS (Ilmu Pengetahuan Alam dan Sosial) - Kelas 6", Kelas: "6", Harga: 78000, Stok: 22, Kategori: "Sains", Status: "AKTIF", Foto: "https://images.unsplash.com/photo-1532094349884-543bc11b234d?w=400&auto=format&fit=crop&q=60" }
];

export const INITIAL_USER: User[] = [
  { Username: "admin", Password: "password123", Role: "ADMIN" },
  { Username: "tu_xaverius", Password: "tu123", Role: "TU" }
];

export const INITIAL_SCHOOL_SETTINGS: SchoolSettings = {
  Logo: "https://images.unsplash.com/photo-1546410531-bb4caa6b424d?w=200&auto=format&fit=crop&q=60", // High contrast book illustration representation
  NamaSekolah: "SD Xaverius 2 Jambi",
  Alamat: "Jl. Kol. Abunjani No. 45, Sipin, Kota Jambi",
  Telepon: "(0741) 612345",
  TahunPelajaran: "2026/2027"
};

export const INITIAL_PESANAN: Pesanan[] = [
  { NoPesanan: "ORD-20260627-001", Tanggal: "2026-06-27", NamaSiswa: "Aditya Pratama", NIS: "10203001", Kelas: "1A", Total: 198000, Status: "MENUNGGU PEMBAYARAN", Petugas: "tu_xaverius" },
  { NoPesanan: "ORD-20260626-002", Tanggal: "2026-06-26", NamaSiswa: "Daniel Christian", NIS: "10203005", Kelas: "2A", Total: 253000, Status: "LUNAS", Petugas: "tu_xaverius" },
  { NoPesanan: "ORD-20260625-003", Tanggal: "2026-06-25", NamaSiswa: "Jessica Amanda", NIS: "10203010", Kelas: "4A", Total: 152000, Status: "SELESAI", Petugas: "admin" }
];

export const INITIAL_DETAIL_PESANAN: DetailPesanan[] = [
  // ORD-001
  { NoPesanan: "ORD-20260627-001", KodeBuku: "B101", NamaBuku: "Pendidikan Agama Katolik & Budi Pekerti - Kelas 1", Qty: 1, Harga: 75000, Subtotal: 75000 },
  { NoPesanan: "ORD-20260627-001", KodeBuku: "B102", NamaBuku: "Pendidikan Pancasila - Kelas 1 Kurikulum Merdeka", Qty: 1, Harga: 65000, Subtotal: 65000 },
  { NoPesanan: "ORD-20260627-001", KodeBuku: "B103", NamaBuku: "Bahasa Indonesia: Aku Bisa! - Kelas 1", Qty: 1, Harga: 58000, Subtotal: 58000 },

  // ORD-002
  { NoPesanan: "ORD-20260626-002", KodeBuku: "B201", NamaBuku: "Pendidikan Agama Katolik & Budi Pekerti - Kelas 2", Qty: 1, Harga: 75000, Subtotal: 75000 },
  { NoPesanan: "ORD-20260626-002", KodeBuku: "B202", NamaBuku: "Pendidikan Pancasila - Kelas 2 Kurikulum Merdeka", Qty: 1, Harga: 68000, Subtotal: 68000 },
  { NoPesanan: "ORD-20260626-002", KodeBuku: "B203", NamaBuku: "Bahasa Indonesia: Keluargaku Unik - Kelas 2", Qty: 1, Harga: 60000, Subtotal: 60000 },
  { NoPesanan: "ORD-20260626-002", KodeBuku: "B204", NamaBuku: "Matematika Belajar Bersama Temanmu - Kelas 2 Vol 1", Qty: 1, Harga: 50000, Subtotal: 50000 },

  // ORD-003
  { NoPesanan: "ORD-20260625-003", KodeBuku: "B401", NamaBuku: "Pendidikan Agama Katolik & Budi Pekerti - Kelas 4", Qty: 1, Harga: 80000, Subtotal: 80000 },
  { NoPesanan: "ORD-20260625-003", KodeBuku: "B402", NamaBuku: "IPAS (Ilmu Pengetahuan Alam dan Sosial) - Kelas 4", Qty: 1, Harga: 72000, Subtotal: 72000 }
];

export const INITIAL_TRANSAKSI: Transaksi[] = [
  { NoTransaksi: "TX-20260626-001", NoPesanan: "ORD-20260626-002", TanggalBayar: "2026-06-26 10:15:30", MetodePembayaran: "TUNAI", Jumlah: 253000, Status: "SUKSES" },
  { NoTransaksi: "TX-20260625-001", NoPesanan: "ORD-20260625-003", TanggalBayar: "2026-06-25 08:30:12", MetodePembayaran: "TRANSFER BANK", Jumlah: 152000, Status: "SUKSES" }
];

export const INITIAL_LOG_STOK: LogStok[] = [
  { Tanggal: "2026-06-25 08:31:00", KodeBuku: "B401", NamaBuku: "Pendidikan Agama Katolik & Budi Pekerti - Kelas 4", Masuk: 0, Keluar: 1, Sisa: 28, Petugas: "admin" },
  { Tanggal: "2026-06-25 08:31:10", KodeBuku: "B402", NamaBuku: "IPAS (Ilmu Pengetahuan Alam dan Sosial) - Kelas 4", Masuk: 0, Keluar: 1, Sisa: 30, Petugas: "admin" }
];

export const INITIAL_AUDIT_LOGS: AuditLog[] = [
  { id: "1", tanggal: "2026-06-27 10:00:00", user: "system", aktivitas: "Inisialisasi", keterangan: "Sistem berhasil dimuat dengan data lokal pertama" },
  { id: "2", tanggal: "2026-06-26 10:15:30", user: "tu_xaverius", aktivitas: "Konfirmasi Pembayaran", keterangan: "Mengonfirmasi pembayaran ORD-20260626-002 sebesar Rp 253.000 (Tunai)" },
  { id: "3", tanggal: "2026-06-25 08:31:15", user: "admin", aktivitas: "Pengeluaran Buku", keterangan: "Semua buku untuk pesanan ORD-20260625-003 telah discan dan diserahkan ke siswa" }
];

// Complete Google Apps Script (Code.gs) for implementation in the spreadsheet.
export const GOOGLE_APPS_SCRIPT_CODE = `/**
 * Google Apps Script - REST API untuk Sistem Penjualan Buku SD Xaverius 2 Jambi
 * Pasang script ini di Google Apps Script (Extensions -> Apps Script pada Google Sheets)
 * Deploy sebagai Web App dengan akses: "Anyone" (Siapa saja).
 */

function doGet(e) {
  const action = e.parameter.action;
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  
  try {
    if (!action) {
      return responseJSON({ success: false, message: "Missing 'action' parameter" });
    }
    
    // 1. GET SISWA
    if (action === "getSiswa") {
      const sheet = ss.getSheetByName("Siswa") || initSheet(ss, "Siswa");
      const data = getSheetData(sheet);
      return responseJSON({ success: true, data: data });
    }
    
    // 2. GET BUKU
    if (action === "getBuku") {
      const sheet = ss.getSheetByName("Buku") || initSheet(ss, "Buku");
      const data = getSheetData(sheet);
      return responseJSON({ success: true, data: data });
    }
    
    // 3. GET PESANAN
    if (action === "getPesanan") {
      const orderSheet = ss.getSheetByName("Pesanan") || initSheet(ss, "Pesanan");
      const detailSheet = ss.getSheetByName("DetailPesanan") || initSheet(ss, "DetailPesanan");
      
      const orders = getSheetData(orderSheet);
      const details = getSheetData(detailSheet);
      
      // Combine order with its details
      orders.forEach(order => {
        order.items = details.filter(item => item.NoPesanan === order.NoPesanan);
      });
      
      return responseJSON({ success: true, data: orders });
    }
    
    // 4. GET REPORT / DASHBOARD DATA
    if (action === "getDashboard") {
      const orderSheet = ss.getSheetByName("Pesanan") || initSheet(ss, "Pesanan");
      const transSheet = ss.getSheetByName("Transaksi") || initSheet(ss, "Transaksi");
      const bookSheet = ss.getSheetByName("Buku") || initSheet(ss, "Buku");
      
      const orders = getSheetData(orderSheet);
      const transactions = getSheetData(transSheet);
      const books = getSheetData(bookSheet);
      
      return responseJSON({
        success: true,
        data: {
          ordersCount: orders.length,
          transactionsCount: transactions.length,
          booksCount: books.length,
          orders: orders.slice(-10).reverse(), // Last 10 orders
          transactions: transactions.slice(-10).reverse()
        }
      });
    }

    return responseJSON({ success: false, message: "Unknown GET action: " + action });
    
  } catch (err) {
    return responseJSON({ success: false, error: err.toString() });
  }
}

function doPost(e) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  
  try {
    const postData = JSON.parse(e.postData.contents);
    const action = postData.action;
    
    if (!action) {
      return responseJSON({ success: false, message: "Missing 'action' in POST data" });
    }
    
    // 1. POST PESANAN BARU
    if (action === "createPesanan") {
      const orderSheet = ss.getSheetByName("Pesanan") || initSheet(ss, "Pesanan");
      const detailSheet = ss.getSheetByName("DetailPesanan") || initSheet(ss, "DetailPesanan");
      const bookSheet = ss.getSheetByName("Buku") || initSheet(ss, "Buku");
      
      const order = postData.order; // { NoPesanan, Tanggal, NamaSiswa, NIS, Kelas, Total, Status, Petugas }
      const items = postData.items; // Array of { KodeBuku, NamaBuku, Qty, Harga, Subtotal }
      
      // Save Main Order
      appendRowFromObject(orderSheet, order);
      
      // Save Order Details
      items.forEach(item => {
        const detailObj = {
          NoPesanan: order.NoPesanan,
          KodeBuku: item.KodeBuku,
          NamaBuku: item.NamaBuku,
          Qty: Number(item.Qty),
          Harga: Number(item.Harga),
          Subtotal: Number(item.Subtotal)
        };
        appendRowFromObject(detailSheet, detailObj);
      });
      
      return responseJSON({ success: true, message: "Pesanan " + order.NoPesanan + " berhasil disimpan" });
    }
    
    // 2. POST PEMBAYARAN (KONFIRMASI LUNAS)
    if (action === "confirmPayment") {
      const orderSheet = ss.getSheetByName("Pesanan") || initSheet(ss, "Pesanan");
      const transSheet = ss.getSheetByName("Transaksi") || initSheet(ss, "Transaksi");
      
      const { NoPesanan, NoTransaksi, TanggalBayar, MetodePembayaran, Jumlah, Petugas } = postData;
      
      // Update order status to LUNAS
      updateRowField(orderSheet, "NoPesanan", NoPesanan, "Status", "LUNAS");
      updateRowField(orderSheet, "NoPesanan", NoPesanan, "Petugas", Petugas);
      
      // Add Transaksi row
      const transObj = {
        NoTransaksi,
        NoPesanan,
        TanggalBayar,
        MetodePembayaran,
        Jumlah: Number(Jumlah),
        Status: "SUKSES"
      };
      appendRowFromObject(transSheet, transObj);
      
      return responseJSON({ success: true, message: "Pembayaran terkonfirmasi untuk NoPesanan: " + NoPesanan });
    }
    
    // 3. UPDATE/EDIT DATA BUKU
    if (action === "saveBuku") {
      const bookSheet = ss.getSheetByName("Buku") || initSheet(ss, "Buku");
      const book = postData.book; // { KodeBuku, Barcode, NamaBuku, Kelas, Harga, Stok, Kategori, Status }
      
      const existing = findRowIndex(bookSheet, "KodeBuku", book.KodeBuku);
      if (existing > 0) {
        // Update
        const headers = getHeaders(bookSheet);
        for (let key in book) {
          const colIndex = headers.indexOf(key) + 1;
          if (colIndex > 0) {
            bookSheet.getRange(existing, colIndex).setValue(book[key]);
          }
        }
      } else {
        // Create new
        appendRowFromObject(bookSheet, book);
      }
      return responseJSON({ success: true, message: "Data Buku berhasil disimpan" });
    }
    
    // 4. DISPATCH BUKU (Scan Barcode & Log Stok)
    if (action === "dispatchBuku") {
      const orderSheet = ss.getSheetByName("Pesanan") || initSheet(ss, "Pesanan");
      const logSheet = ss.getSheetByName("LogStok") || initSheet(ss, "LogStok");
      const bookSheet = ss.getSheetByName("Buku") || initSheet(ss, "Buku");
      
      const { NoPesanan, KodeBuku, NamaBuku, Qty, SisaStok, Petugas, Tanggal, SelesaiSemua } = postData;
      
      // 1. Tambahkan LogStok
      const logObj = {
        Tanggal,
        KodeBuku,
        NamaBuku,
        Masuk: 0,
        Keluar: Number(Qty),
        Sisa: Number(SisaStok),
        Petugas
      };
      appendRowFromObject(logSheet, logObj);
      
      // 2. Kurangi Stok Buku di Sheet Buku
      updateRowField(bookSheet, "KodeBuku", KodeBuku, "Stok", Number(SisaStok));
      
      // 3. Jika selesai semua, ganti status pesanan menjadi SELESAI
      if (SelesaiSemua) {
        updateRowField(orderSheet, "NoPesanan", NoPesanan, "Status", "SELESAI");
      }
      
      return responseJSON({ success: true, message: "Stock logged & updated successfully" });
    }
    
    // 5. BULK SYNC / SEED ALL DATA (From Frontend to GAS)
    if (action === "syncAllData") {
      const { siswa, buku, pesanan, detailPesanan, transaksi, logStok, users } = postData;
      
      if (siswa) replaceSheetData(ss, "Siswa", siswa);
      if (buku) replaceSheetData(ss, "Buku", buku);
      if (pesanan) replaceSheetData(ss, "Pesanan", pesanan);
      if (detailPesanan) replaceSheetData(ss, "DetailPesanan", detailPesanan);
      if (transaksi) replaceSheetData(ss, "Transaksi", transaksi);
      if (logStok) replaceSheetData(ss, "LogStok", logStok);
      if (users) replaceSheetData(ss, "User", users);
      
      return responseJSON({ success: true, message: "Sinkronisasi seluruh data ke Google Sheet berhasil!" });
    }

    return responseJSON({ success: false, message: "Unknown POST action: " + action });

  } catch (err) {
    return responseJSON({ success: false, error: err.toString() });
  }
}

// === HELPER FUNCTIONS ===

function responseJSON(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON)
    .setHeader("Access-Control-Allow-Origin", "*")
    .setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
    .setHeader("Access-Control-Allow-Headers", "Content-Type");
}

function getHeaders(sheet) {
  const lastCol = sheet.getLastColumn();
  if (lastCol === 0) return [];
  return sheet.getRange(1, 1, 1, lastCol).getValues()[0];
}

function getSheetData(sheet) {
  const lastRow = sheet.getLastRow();
  const lastCol = sheet.getLastColumn();
  if (lastRow <= 1) return [];
  
  const headers = getHeaders(sheet);
  const values = sheet.getRange(2, 1, lastRow - 1, lastCol).getValues();
  
  return values.map(row => {
    let obj = {};
    headers.forEach((header, index) => {
      let val = row[index];
      // Format Date values if encountered
      if (val instanceof Date) {
        val = Utilities.formatDate(val, Session.getScriptTimeZone(), "yyyy-MM-dd HH:mm:ss");
      }
      obj[header] = val;
    });
    return obj;
  });
}

function appendRowFromObject(sheet, obj) {
  const headers = getHeaders(sheet);
  let row = [];
  headers.forEach(header => {
    row.push(obj[header] !== undefined ? obj[header] : "");
  });
  sheet.appendRow(row);
}

function updateRowField(sheet, keyColumnName, keyValue, targetColumnName, targetValue) {
  const headers = getHeaders(sheet);
  const keyColIndex = headers.indexOf(keyColumnName) + 1;
  const targetColIndex = headers.indexOf(targetColumnName) + 1;
  
  if (keyColIndex === 0 || targetColIndex === 0) return false;
  
  const lastRow = sheet.getLastRow();
  if (lastRow <= 1) return false;
  
  const values = sheet.getRange(2, keyColIndex, lastRow - 1, 1).getValues();
  for (let i = 0; i < values.length; i++) {
    if (values[i][0].toString() === keyValue.toString()) {
      sheet.getRange(i + 2, targetColIndex).setValue(targetValue);
      return true;
    }
  }
  return false;
}

function findRowIndex(sheet, keyColumnName, keyValue) {
  const headers = getHeaders(sheet);
  const keyColIndex = headers.indexOf(keyColumnName) + 1;
  if (keyColIndex === 0) return -1;
  
  const lastRow = sheet.getLastRow();
  if (lastRow <= 1) return -1;
  
  const values = sheet.getRange(2, keyColIndex, lastRow - 1, 1).getValues();
  for (let i = 0; i < values.length; i++) {
    if (values[i][0].toString() === keyValue.toString()) {
      return i + 2; // Rows are 1-indexed, headers are row 1
    }
  }
  return -1;
}

function replaceSheetData(ss, sheetName, dataArray) {
  let sheet = ss.getSheetByName(sheetName);
  if (sheet) {
    sheet.clear();
  } else {
    sheet = ss.insertSheet(sheetName);
  }
  
  if (dataArray.length === 0) {
    initSheet(ss, sheetName);
    return;
  }
  
  // Get headers from first element keys
  const headers = Object.keys(dataArray[0]);
  sheet.appendRow(headers);
  
  const rows = dataArray.map(item => {
    return headers.map(h => item[h] !== undefined ? item[h] : "");
  });
  
  sheet.getRange(2, 1, rows.length, headers.length).setValues(rows);
}

function initSheet(ss, sheetName) {
  let sheet = ss.getSheetByName(sheetName);
  if (sheet) return sheet;
  sheet = ss.insertSheet(sheetName);
  
  let headers = [];
  if (sheetName === "Siswa") headers = ["NIS", "Nama", "Kelas", "JenisKelamin", "NamaOrtu", "NoHP"];
  else if (sheetName === "Buku") headers = ["KodeBuku", "Barcode", "NamaBuku", "Kelas", "Harga", "Stok", "Kategori", "Status"];
  else if (sheetName === "Pesanan") headers = ["NoPesanan", "Tanggal", "NamaSiswa", "NIS", "Kelas", "Total", "Status", "Petugas"];
  else if (sheetName === "DetailPesanan") headers = ["NoPesanan", "KodeBuku", "NamaBuku", "Qty", "Harga", "Subtotal"];
  else if (sheetName === "Transaksi") headers = ["NoTransaksi", "NoPesanan", "TanggalBayar", "MetodePembayaran", "Jumlah", "Status"];
  else if (sheetName === "LogStok") headers = ["Tanggal", "KodeBuku", "NamaBuku", "Masuk", "Keluar", "Sisa", "Petugas"];
  else if (sheetName === "User") headers = ["Username", "Password", "Role"];
  
  sheet.appendRow(headers);
  return sheet;
}
`;
