/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { createContext, useContext, useState, useEffect } from 'react';
import { Siswa, Buku, Pesanan, DetailPesanan, Transaksi, LogStok, User, SchoolSettings, AuditLog, AppConfig } from '../types';
import {
  INITIAL_SISWA,
  INITIAL_BUKU,
  INITIAL_PESANAN,
  INITIAL_DETAIL_PESANAN,
  INITIAL_TRANSAKSI,
  INITIAL_LOG_STOK,
  INITIAL_USER,
  INITIAL_SCHOOL_SETTINGS,
  INITIAL_AUDIT_LOGS
} from '../data';
import { initAuth, googleSignIn, googleSignOut } from '../utils/googleAuth';
import { 
  extractSpreadsheetId, 
  initializeSpreadsheet, 
  fetchSheetData, 
  replaceSheetData as apiReplaceSheetData, 
  appendSheetRow, 
  updateSheetRowField,
  SHEET_SCHEMAS
} from '../utils/googleSheetsApi';

interface AppContextType {
  siswa: Siswa[];
  buku: Buku[];
  pesanan: Pesanan[];
  detailPesanan: DetailPesanan[];
  transaksi: Transaksi[];
  logStok: LogStok[];
  users: User[];
  schoolSettings: SchoolSettings;
  auditLogs: AuditLog[];
  activeUser: User | null;
  config: AppConfig;
  toastMsg: { text: string; type: 'success' | 'error' | 'info' } | null;
  
  // Google Auth states
  googleUser: any | null;
  googleToken: string | null;
  connectGoogle: () => Promise<void>;
  disconnectGoogle: () => Promise<void>;
  initializeSheetsInSpreadsheet: () => Promise<{ success: boolean; message: string }>;

  // Actions
  showToast: (text: string, type?: 'success' | 'error' | 'info') => void;
  login: (username: string, password: string) => boolean;
  logout: () => void;
  addOrder: (order: Pesanan, items: DetailPesanan[]) => Promise<void>;
  saveBook: (book: Buku) => Promise<void>;
  deleteBook: (kodeBuku: string) => Promise<void>;
  confirmPayment: (noPesanan: string, metode: string, jumlah: number) => Promise<void>;
  dispatchBook: (noPesanan: string, kodeBuku: string, scanQty: number) => Promise<{ success: boolean; message: string; completed: boolean }>;
  
  // Admin Ops
  saveSiswa: (s: Siswa) => Promise<void>;
  deleteSiswa: (nis: string) => Promise<void>;
  saveUser: (u: User) => Promise<void>;
  deleteUser: (username: string) => Promise<void>;
  updateSchoolSettings: (settings: SchoolSettings) => void;
  saveConfig: (cfg: AppConfig) => void;
  
  // Sync
  syncWithGoogleSheets: (action: 'pull' | 'push') => Promise<{ success: boolean; message: string }>;
  clearAndResetLocal: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: React.ReactNode }) {
  // Core States
  const [siswa, setSiswa] = useState<Siswa[]>(() => {
    const saved = localStorage.getItem('xaverius_siswa');
    return saved ? JSON.parse(saved) : INITIAL_SISWA;
  });

  const [buku, setBuku] = useState<Buku[]>(() => {
    const saved = localStorage.getItem('xaverius_buku');
    return saved ? JSON.parse(saved) : INITIAL_BUKU;
  });

  const [pesanan, setPesanan] = useState<Pesanan[]>(() => {
    const saved = localStorage.getItem('xaverius_pesanan');
    return saved ? JSON.parse(saved) : INITIAL_PESANAN;
  });

  const [detailPesanan, setDetailPesanan] = useState<DetailPesanan[]>(() => {
    const saved = localStorage.getItem('xaverius_detail_pesanan');
    return saved ? JSON.parse(saved) : INITIAL_DETAIL_PESANAN;
  });

  const [transaksi, setTransaksi] = useState<Transaksi[]>(() => {
    const saved = localStorage.getItem('xaverius_transaksi');
    return saved ? JSON.parse(saved) : INITIAL_TRANSAKSI;
  });

  const [logStok, setLogStok] = useState<LogStok[]>(() => {
    const saved = localStorage.getItem('xaverius_log_stok');
    return saved ? JSON.parse(saved) : INITIAL_LOG_STOK;
  });

  const [users, setUsers] = useState<User[]>(() => {
    const saved = localStorage.getItem('xaverius_users');
    return saved ? JSON.parse(saved) : INITIAL_USER;
  });

  const [schoolSettings, setSchoolSettings] = useState<SchoolSettings>(() => {
    const saved = localStorage.getItem('xaverius_settings');
    return saved ? JSON.parse(saved) : INITIAL_SCHOOL_SETTINGS;
  });

  const [auditLogs, setAuditLogs] = useState<AuditLog[]>(() => {
    const saved = localStorage.getItem('xaverius_audit_logs');
    return saved ? JSON.parse(saved) : INITIAL_AUDIT_LOGS;
  });

  const [activeUser, setActiveUser] = useState<User | null>(() => {
    const saved = localStorage.getItem('xaverius_active_user');
    return saved ? JSON.parse(saved) : null;
  });

  const [config, setConfig] = useState<AppConfig>(() => {
    const saved = localStorage.getItem('xaverius_config');
    return saved ? JSON.parse(saved) : { 
      gasUrl: '', 
      isLiveMode: false, 
      googleSpreadsheetId: '1Ff5ru5DPHxDoHERc38ukdHtPW7XedLU2bGJp3f7g1hE', 
      syncMode: 'direct' 
    };
  });

  const [googleUser, setGoogleUser] = useState<any | null>(null);
  const [googleToken, setGoogleToken] = useState<string | null>(null);

  useEffect(() => {
    const unsubscribe = initAuth(
      (user, token) => {
        setGoogleUser(user);
        setGoogleToken(token);
      },
      () => {
        setGoogleUser(null);
        setGoogleToken(null);
      }
    );
    return () => unsubscribe();
  }, []);

  // Toasts
  const [toastMsg, setToastMsg] = useState<{ text: string; type: 'success' | 'error' | 'info' } | null>(null);

  // Sync state changes with localStorage
  useEffect(() => {
    localStorage.setItem('xaverius_siswa', JSON.stringify(siswa));
  }, [siswa]);

  useEffect(() => {
    localStorage.setItem('xaverius_buku', JSON.stringify(buku));
  }, [buku]);

  useEffect(() => {
    localStorage.setItem('xaverius_pesanan', JSON.stringify(pesanan));
  }, [pesanan]);

  useEffect(() => {
    localStorage.setItem('xaverius_detail_pesanan', JSON.stringify(detailPesanan));
  }, [detailPesanan]);

  useEffect(() => {
    localStorage.setItem('xaverius_transaksi', JSON.stringify(transaksi));
  }, [transaksi]);

  useEffect(() => {
    localStorage.setItem('xaverius_log_stok', JSON.stringify(logStok));
  }, [logStok]);

  useEffect(() => {
    localStorage.setItem('xaverius_users', JSON.stringify(users));
  }, [users]);

  useEffect(() => {
    localStorage.setItem('xaverius_settings', JSON.stringify(schoolSettings));
  }, [schoolSettings]);

  useEffect(() => {
    localStorage.setItem('xaverius_audit_logs', JSON.stringify(auditLogs));
  }, [auditLogs]);

  useEffect(() => {
    if (activeUser) {
      localStorage.setItem('xaverius_active_user', JSON.stringify(activeUser));
    } else {
      localStorage.removeItem('xaverius_active_user');
    }
  }, [activeUser]);

  useEffect(() => {
    localStorage.setItem('xaverius_config', JSON.stringify(config));
  }, [config]);

  // Toast Action
  const showToast = (text: string, type: 'success' | 'error' | 'info' = 'success') => {
    setToastMsg({ text, type });
    setTimeout(() => {
      setToastMsg(null);
    }, 4000);
  };

  const addAuditLog = (aktivitas: string, keterangan: string) => {
    const newLog: AuditLog = {
      id: Math.random().toString(36).substring(2, 9),
      tanggal: new Date().toISOString().slice(0, 19).replace('T', ' '),
      user: activeUser ? activeUser.Username : 'Sistem / Wali Murid',
      aktivitas,
      keterangan
    };
    setAuditLogs(prev => [newLog, ...prev]);
  };

  // Auth Operations
  const login = (username: string, password: string): boolean => {
    const user = users.find(u => u.Username.toLowerCase() === username.toLowerCase() && u.Password === password);
    if (user) {
      setActiveUser(user);
      addAuditLog('Login', `User ${user.Username} dengan role ${user.Role} berhasil login.`);
      showToast(`Selamat datang kembali, ${username}!`, 'success');
      return true;
    }
    showToast('Username atau password salah!', 'error');
    return false;
  };

  const logout = () => {
    if (activeUser) {
      addAuditLog('Logout', `User ${activeUser.Username} melakukan logout.`);
    }
    setActiveUser(null);
    showToast('Anda telah keluar dari sistem.', 'info');
  };

  // Student Order placement (Orang tua)
  const addOrder = async (order: Pesanan, items: DetailPesanan[]) => {
    // 1. Update Local State
    setPesanan(prev => [order, ...prev]);
    setDetailPesanan(prev => [...prev, ...items]);
    addAuditLog('Pemesanan Buku', `Pesanan baru dibuat: ${order.NoPesanan} untuk siswa ${order.NamaSiswa} (${order.Kelas}) senilai Rp ${order.Total.toLocaleString()}`);

    // 2. If Live Mode, dispatch API call
    if (config.isLiveMode) {
      if (config.syncMode === 'direct') {
        if (googleToken) {
          try {
            const spreadId = extractSpreadsheetId(config.googleSpreadsheetId || '1Ff5ru5DPHxDoHERc38ukdHtPW7XedLU2bGJp3f7g1hE');
            const pesananHeaders = SHEET_SCHEMAS.find(s => s.name === 'Pesanan')?.headers || [];
            const detailHeaders = SHEET_SCHEMAS.find(s => s.name === 'DetailPesanan')?.headers || [];
            
            await appendSheetRow(googleToken, spreadId, 'Pesanan', order, pesananHeaders);
            for (const item of items) {
              await appendSheetRow(googleToken, spreadId, 'DetailPesanan', item, detailHeaders);
            }
            showToast('Pesanan berhasil dibuat & sinkron dengan Google Sheets!', 'success');
          } catch (err: any) {
            console.error('Direct Sheets Error:', err);
            showToast('Gagal mengirim ke Google Sheets, disimpan secara lokal.', 'error');
          }
        } else {
          showToast('Pesanan disimpan lokal. Hubungkan Google Account untuk sinkron otomatis.', 'info');
        }
      } else if (config.gasUrl) {
        try {
          await fetch(config.gasUrl, {
            method: 'POST',
            mode: 'no-cors', // To bypass CORS preflight restrictions on GAS redirect
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              action: 'createPesanan',
              order,
              items
            })
          });
          showToast('Pesanan berhasil dibuat & sinkron dengan Google Sheets!', 'success');
        } catch (err) {
          console.error('GAS POST Error:', err);
          showToast('Gagal mengirim ke Google Sheets, disimpan secara lokal.', 'error');
        }
      }
    } else {
      showToast('Pesanan berhasil dibuat (Simulasi Lokal)!', 'success');
    }
  };

  // Data Buku Operations
  const saveBook = async (book: Buku) => {
    const isEdit = buku.some(b => b.KodeBuku === book.KodeBuku);
    
    // Update local state
    if (isEdit) {
      setBuku(prev => prev.map(b => b.KodeBuku === book.KodeBuku ? book : b));
      addAuditLog('Update Buku', `Buku ${book.NamaBuku} (Kode: ${book.KodeBuku}) diperbarui.`);
    } else {
      setBuku(prev => [book, ...prev]);
      addAuditLog('Tambah Buku', `Buku ${book.NamaBuku} (Kode: ${book.KodeBuku}) ditambahkan.`);
    }

    // Sync with GAS or Direct Sheet
    if (config.isLiveMode) {
      if (config.syncMode === 'direct') {
        if (googleToken) {
          try {
            const spreadId = extractSpreadsheetId(config.googleSpreadsheetId || '1Ff5ru5DPHxDoHERc38ukdHtPW7XedLU2bGJp3f7g1hE');
            const headers = SHEET_SCHEMAS.find(s => s.name === 'Buku')?.headers || [];
            if (isEdit) {
              await updateSheetRowField(googleToken, spreadId, 'Buku', 'KodeBuku', book.KodeBuku, 'Stok', book.Stok, headers);
              await updateSheetRowField(googleToken, spreadId, 'Buku', 'KodeBuku', book.KodeBuku, 'Harga', book.Harga, headers);
              await updateSheetRowField(googleToken, spreadId, 'Buku', 'KodeBuku', book.KodeBuku, 'NamaBuku', book.NamaBuku, headers);
              await updateSheetRowField(googleToken, spreadId, 'Buku', 'KodeBuku', book.KodeBuku, 'Status', book.Status, headers);
            } else {
              await appendSheetRow(googleToken, spreadId, 'Buku', book, headers);
            }
            showToast('Buku berhasil disimpan ke Google Sheets!', 'success');
          } catch (err) {
            showToast('Gagal sinkronisasi Buku ke Google Sheets.', 'error');
          }
        } else {
          showToast('Buku disimpan secara lokal. Hubungkan Google Account untuk sinkron otomatis.', 'info');
        }
      } else if (config.gasUrl) {
        try {
          await fetch(config.gasUrl, {
            method: 'POST',
            mode: 'no-cors',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              action: 'saveBuku',
              book
            })
          });
          showToast('Buku berhasil disimpan ke Google Sheets!', 'success');
        } catch (err) {
          showToast('Gagal sinkronisasi Buku ke Google Sheets.', 'error');
        }
      }
    } else {
      showToast('Data Buku berhasil disimpan!', 'success');
    }
  };

  const deleteBook = async (kodeBuku: string) => {
    const target = buku.find(b => b.KodeBuku === kodeBuku);
    if (!target) return;

    setBuku(prev => prev.filter(b => b.KodeBuku !== kodeBuku));
    addAuditLog('Hapus Buku', `Buku ${target.NamaBuku} (Kode: ${kodeBuku}) dihapus.`);
    showToast('Data buku berhasil dihapus!', 'success');
  };

  // Payment Confirmation (Tata Usaha)
  const confirmPayment = async (noPesanan: string, metode: string, jumlah: number) => {
    const targetOrder = pesanan.find(p => p.NoPesanan === noPesanan);
    if (!targetOrder) return;

    // 1. Update order status to LUNAS locally
    setPesanan(prev => prev.map(p => p.NoPesanan === noPesanan ? { ...p, Status: 'LUNAS', Petugas: activeUser?.Username || 'TU' } : p));

    // 2. Generate a transaction log
    const noTransaksi = `TX-${new Date().toISOString().slice(0, 10).replace(/-/g, '')}-${Math.floor(100 + Math.random() * 900)}`;
    const tanggalBayar = new Date().toISOString().slice(0, 19).replace('T', ' ');
    const newTx: Transaksi = {
      NoTransaksi: noTransaksi,
      NoPesanan: noPesanan,
      TanggalBayar: tanggalBayar,
      MetodePembayaran: metode,
      Jumlah: jumlah,
      Status: 'SUKSES'
    };

    setTransaksi(prev => [newTx, ...prev]);
    addAuditLog('Konfirmasi Pembayaran', `Pembayaran pesanan ${noPesanan} dikonfirmasi (${metode}). Lunas.`);

    // 3. Sync with Sheets or GAS
    if (config.isLiveMode) {
      if (config.syncMode === 'direct') {
        if (googleToken) {
          try {
            const spreadId = extractSpreadsheetId(config.googleSpreadsheetId || '1Ff5ru5DPHxDoHERc38ukdHtPW7XedLU2bGJp3f7g1hE');
            const pesananHeaders = SHEET_SCHEMAS.find(s => s.name === 'Pesanan')?.headers || [];
            const txHeaders = SHEET_SCHEMAS.find(s => s.name === 'Transaksi')?.headers || [];
            
            await updateSheetRowField(googleToken, spreadId, 'Pesanan', 'NoPesanan', noPesanan, 'Status', 'LUNAS', pesananHeaders);
            await updateSheetRowField(googleToken, spreadId, 'Pesanan', 'NoPesanan', noPesanan, 'Petugas', activeUser?.Username || 'TU', pesananHeaders);
            await appendSheetRow(googleToken, spreadId, 'Transaksi', newTx, txHeaders);
            
            showToast('Pembayaran dikonfirmasi & sinkron dengan Google Sheets!', 'success');
          } catch (err) {
            showToast('Gagal sinkron pembayaran ke Google Sheets.', 'error');
          }
        } else {
          showToast('Pembayaran dikonfirmasi secara lokal.', 'success');
        }
      } else if (config.gasUrl) {
        try {
          await fetch(config.gasUrl, {
            method: 'POST',
            mode: 'no-cors',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              action: 'confirmPayment',
              NoPesanan: noPesanan,
              NoTransaksi: noTransaksi,
              TanggalBayar: tanggalBayar,
              MetodePembayaran: metode,
              Jumlah: jumlah,
              Petugas: activeUser?.Username || 'TU'
            })
          });
          showToast('Pembayaran dikonfirmasi & sinkron dengan Google Sheets!', 'success');
        } catch (err) {
          showToast('Gagal sinkron pembayaran ke Google Sheets.', 'error');
        }
      }
    } else {
      showToast('Konfirmasi pembayaran berhasil disimulasikan!', 'success');
    }
  };

  // Dispatch Book (Scan Barcode & Update Stocks)
  const dispatchBook = async (noPesanan: string, kodeBuku: string, scanQty: number): Promise<{ success: boolean; message: string; completed: boolean }> => {
    const targetOrder = pesanan.find(p => p.NoPesanan === noPesanan);
    const targetBook = buku.find(b => b.KodeBuku === kodeBuku);
    const orderItems = detailPesanan.filter(d => d.NoPesanan === noPesanan);
    const specificItem = orderItems.find(d => d.KodeBuku === kodeBuku);

    if (!targetOrder) {
      return { success: false, message: `Pesanan ${noPesanan} tidak ditemukan.`, completed: false };
    }
    if (!targetBook) {
      return { success: false, message: `Buku dengan kode ${kodeBuku} tidak ditemukan dalam database sekolah.`, completed: false };
    }
    if (!specificItem) {
      return { success: false, message: `Buku ini tidak termasuk dalam pesanan ${noPesanan}.`, completed: false };
    }
    if (targetBook.Stok < scanQty) {
      return { success: false, message: `Stok buku ${targetBook.NamaBuku} tidak mencukupi (Sisa stok: ${targetBook.Stok}).`, completed: false };
    }

    // Initialize/Load barcode scan tracker locally
    const currentScanned = targetOrder.BukuScanned || {};
    const previousScannedCount = currentScanned[kodeBuku] || 0;
    const nextScannedCount = previousScannedCount + scanQty;

    if (nextScannedCount > specificItem.Qty) {
      return { 
        success: false, 
        message: `Buku ${targetBook.NamaBuku} sudah diserahkan sepenuhnya (${previousScannedCount}/${specificItem.Qty} pcs). Tidak bisa scan lebih banyak.`, 
        completed: false 
      };
    }

    // 1. Update book stock
    const newStock = targetBook.Stok - scanQty;
    setBuku(prev => prev.map(b => b.KodeBuku === kodeBuku ? { ...b, Stok: newStock } : b));

    // 2. Add Stock Log
    const tanggalLog = new Date().toISOString().slice(0, 19).replace('T', ' ');
    const newStockLog: LogStok = {
      Tanggal: tanggalLog,
      KodeBuku: kodeBuku,
      NamaBuku: targetBook.NamaBuku,
      Masuk: 0,
      Keluar: scanQty,
      Sisa: newStock,
      Petugas: activeUser?.Username || 'TU'
    };
    setLogStok(prev => [newStockLog, ...prev]);

    // Update scanned count inside order state
    const nextScannedObj = { ...currentScanned, [kodeBuku]: nextScannedCount };
    
    // Check if ALL books in the order are fully scanned/dispatched
    let allCompleted = true;
    const updatedPesanan = pesanan.map(p => {
      if (p.NoPesanan === noPesanan) {
        // Evaluate if completed
        orderItems.forEach(item => {
          const itemScanned = item.KodeBuku === kodeBuku ? nextScannedCount : (p.BukuScanned?.[item.KodeBuku] || 0);
          if (itemScanned < item.Qty) {
            allCompleted = false;
          }
        });

        const newStatus = allCompleted ? 'SELESAI' : p.Status;
        return { 
          ...p, 
          BukuScanned: nextScannedObj, 
          Status: newStatus as any, 
          Petugas: activeUser?.Username || p.Petugas 
        };
      }
      return p;
    });

    setPesanan(updatedPesanan);
    addAuditLog('Scan Barcode', `Buku ${targetBook.NamaBuku} berhasil discan (${nextScannedCount}/${specificItem.Qty} pcs) untuk pesanan ${noPesanan}.`);

    // 3. Sync with Google Sheets or GAS
    if (config.isLiveMode) {
      if (config.syncMode === 'direct') {
        if (googleToken) {
          try {
            const spreadId = extractSpreadsheetId(config.googleSpreadsheetId || '1Ff5ru5DPHxDoHERc38ukdHtPW7XedLU2bGJp3f7g1hE');
            const bookHeaders = SHEET_SCHEMAS.find(s => s.name === 'Buku')?.headers || [];
            const pesananHeaders = SHEET_SCHEMAS.find(s => s.name === 'Pesanan')?.headers || [];
            const logStokHeaders = SHEET_SCHEMAS.find(s => s.name === 'LogStok')?.headers || [];
            
            await updateSheetRowField(googleToken, spreadId, 'Buku', 'KodeBuku', kodeBuku, 'Stok', newStock, bookHeaders);
            await appendSheetRow(googleToken, spreadId, 'LogStok', newStockLog, logStokHeaders);
            await updateSheetRowField(googleToken, spreadId, 'Pesanan', 'NoPesanan', noPesanan, 'BukuScanned', nextScannedObj, pesananHeaders);
            if (allCompleted) {
              await updateSheetRowField(googleToken, spreadId, 'Pesanan', 'NoPesanan', noPesanan, 'Status', 'SELESAI', pesananHeaders);
            }
          } catch (err) {
            console.error('Direct Sheets dispatch err:', err);
          }
        }
      } else if (config.gasUrl) {
        try {
          await fetch(config.gasUrl, {
            method: 'POST',
            mode: 'no-cors',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              action: 'dispatchBuku',
              NoPesanan: noPesanan,
              KodeBuku: kodeBuku,
              NamaBuku: targetBook.NamaBuku,
              Qty: scanQty,
              SisaStok: newStock,
              Petugas: activeUser?.Username || 'TU',
              Tanggal: tanggalLog,
              SelesaiSemua: allCompleted
            })
          });
        } catch (err) {
          console.error('GAS dispatch err:', err);
        }
      }
    }

    const completedMsg = allCompleted 
      ? `Semua buku untuk pesanan ${noPesanan} telah berhasil diserahkan! Status pesanan berubah menjadi SELESAI.`
      : `Buku ${targetBook.NamaBuku} berhasil discan (${nextScannedCount}/${specificItem.Qty} pcs).`;

    return { success: true, message: completedMsg, completed: allCompleted };
  };

  // Admin Ops
  const saveSiswa = async (s: Siswa) => {
    const exists = siswa.some(stud => stud.NIS === s.NIS);
    if (exists) {
      setSiswa(prev => prev.map(stud => stud.NIS === s.NIS ? s : stud));
      addAuditLog('Edit Siswa', `Data siswa ${s.Nama} (${s.NIS}) diperbarui.`);
      showToast('Data siswa berhasil diperbarui!', 'success');
    } else {
      setSiswa(prev => [s, ...prev]);
      addAuditLog('Tambah Siswa', `Siswa baru ditambahkan: ${s.Nama} (${s.NIS}).`);
      showToast('Siswa baru berhasil ditambahkan!', 'success');
    }
  };

  const deleteSiswa = async (nis: string) => {
    const target = siswa.find(s => s.NIS === nis);
    if (!target) return;
    setSiswa(prev => prev.filter(s => s.NIS !== nis));
    addAuditLog('Hapus Siswa', `Siswa ${target.Nama} (${nis}) dihapus.`);
    showToast('Data siswa berhasil dihapus!', 'success');
  };

  const saveUser = async (u: User) => {
    const exists = users.some(usr => usr.Username.toLowerCase() === u.Username.toLowerCase());
    if (exists) {
      setUsers(prev => prev.map(usr => usr.Username.toLowerCase() === u.Username.toLowerCase() ? u : usr));
      addAuditLog('Edit User', `Password/Role untuk user ${u.Username} diperbarui.`);
    } else {
      setUsers(prev => [...prev, u]);
      addAuditLog('Tambah User', `User baru didaftarkan: ${u.Username} (Role: ${u.Role}).`);
    }
    showToast('Data user berhasil disimpan!', 'success');
  };

  const deleteUser = async (username: string) => {
    if (username.toLowerCase() === 'admin') {
      showToast('User "admin" utama tidak boleh dihapus!', 'error');
      return;
    }
    setUsers(prev => prev.filter(usr => usr.Username.toLowerCase() !== username.toLowerCase()));
    addAuditLog('Hapus User', `User ${username} dihapus dari sistem.`);
    showToast('User berhasil dihapus!', 'success');
  };

  const updateSchoolSettings = (settings: SchoolSettings) => {
    setSchoolSettings(settings);
    addAuditLog('Pengaturan Sekolah', 'Pengaturan profil sekolah diperbarui.');
    showToast('Profil sekolah berhasil diperbarui!', 'success');
  };

  const saveConfig = (cfg: AppConfig) => {
    setConfig(cfg);
    addAuditLog('Konfigurasi API', `Mode sinkronisasi diatur ke: ${cfg.isLiveMode ? 'Live (Google Sheets)' : 'Lokal'}.`);
    showToast(`Konfigurasi disimpan! Mode: ${cfg.isLiveMode ? 'Google Sheets Live' : 'Lokal'}`, 'success');
  };

  // Google Sheets Push/Pull Sync Implementation
  const syncWithGoogleSheets = async (action: 'pull' | 'push'): Promise<{ success: boolean; message: string }> => {
    if (config.syncMode === 'direct') {
      if (!googleToken) {
        return { success: false, message: 'Akun Google belum terhubung! Silakan hubungkan akun Google Anda di tab Sync.' };
      }
      const spreadId = extractSpreadsheetId(config.googleSpreadsheetId || '1Ff5ru5DPHxDoHERc38ukdHtPW7XedLU2bGJp3f7g1hE');
      if (!spreadId) {
        return { success: false, message: 'ID Spreadsheet Google tidak valid atau belum diset!' };
      }

      try {
        if (action === 'push') {
          // Push all local tables to Sheets API
          await apiReplaceSheetData(googleToken, spreadId, 'Siswa', siswa, SHEET_SCHEMAS.find(s => s.name === 'Siswa')!.headers);
          await apiReplaceSheetData(googleToken, spreadId, 'Buku', buku, SHEET_SCHEMAS.find(s => s.name === 'Buku')!.headers);
          await apiReplaceSheetData(googleToken, spreadId, 'Pesanan', pesanan, SHEET_SCHEMAS.find(s => s.name === 'Pesanan')!.headers);
          await apiReplaceSheetData(googleToken, spreadId, 'DetailPesanan', detailPesanan, SHEET_SCHEMAS.find(s => s.name === 'DetailPesanan')!.headers);
          await apiReplaceSheetData(googleToken, spreadId, 'Transaksi', transaksi, SHEET_SCHEMAS.find(s => s.name === 'Transaksi')!.headers);
          await apiReplaceSheetData(googleToken, spreadId, 'LogStok', logStok, SHEET_SCHEMAS.find(s => s.name === 'LogStok')!.headers);
          await apiReplaceSheetData(googleToken, spreadId, 'User', users, SHEET_SCHEMAS.find(s => s.name === 'User')!.headers);

          addAuditLog('Google Sheets Push', `Berhasil mengunggah seluruh data lokal ke Google Sheet (ID: ${spreadId}).`);
          return { success: true, message: 'Berhasil mengunggah semua data lokal ke Google Sheets!' };
        } else {
          // Pull all tables from Sheets API
          const fetchedSiswa = await fetchSheetData<Siswa>(googleToken, spreadId, 'Siswa');
          const fetchedBuku = await fetchSheetData<Buku>(googleToken, spreadId, 'Buku');
          const fetchedPesanan = await fetchSheetData<Pesanan>(googleToken, spreadId, 'Pesanan');
          const fetchedDetail = await fetchSheetData<DetailPesanan>(googleToken, spreadId, 'DetailPesanan');
          const fetchedTransaksi = await fetchSheetData<Transaksi>(googleToken, spreadId, 'Transaksi');
          const fetchedLogStok = await fetchSheetData<LogStok>(googleToken, spreadId, 'LogStok');
          const fetchedUsers = await fetchSheetData<User>(googleToken, spreadId, 'User');

          if (fetchedSiswa.length > 0) setSiswa(fetchedSiswa);
          if (fetchedBuku.length > 0) setBuku(fetchedBuku);
          if (fetchedPesanan.length > 0) setPesanan(fetchedPesanan);
          if (fetchedDetail.length > 0) setDetailPesanan(fetchedDetail);
          if (fetchedTransaksi.length > 0) setTransaksi(fetchedTransaksi);
          if (fetchedLogStok.length > 0) setLogStok(fetchedLogStok);
          if (fetchedUsers.length > 0) setUsers(fetchedUsers);

          addAuditLog('Google Sheets Pull', `Berhasil mengunduh data terbaru dari Google Sheet (ID: ${spreadId}).`);
          return { success: true, message: 'Berhasil mengunduh seluruh data terbaru dari Google Sheets!' };
        }
      } catch (err: any) {
        console.error('Direct Sheets API Error:', err);
        return { success: false, message: `Gagal sinkronisasi direct Sheets: ${err.message || err.toString()}` };
      }
    }

    if (!config.gasUrl) {
      return { success: false, message: 'Google Apps Script URL belum dikonfigurasi di pengaturan!' };
    }

    try {
      if (action === 'push') {
        // Push all local tables to GAS
        const response = await fetch(config.gasUrl, {
          method: 'POST',
          mode: 'no-cors', // To ignore CORS redirect blockage on direct post
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            action: 'syncAllData',
            siswa,
            buku,
            pesanan,
            detailPesanan,
            transaksi,
            logStok,
            users
          })
        });

        addAuditLog('Google Sheets Push', 'Mengunggah seluruh data lokal ke Google Sheets.');
        return { success: true, message: 'Berhasil mengunggah semua data lokal ke Google Sheets (Terkirim!' };
      } else {
        // Pull data from GAS
        const resSiswa = await fetch(`${config.gasUrl}?action=getSiswa`);
        const dataSiswa = await resSiswa.json();
        
        const resBuku = await fetch(`${config.gasUrl}?action=getBuku`);
        const dataBuku = await resBuku.json();
        
        const resPesanan = await fetch(`${config.gasUrl}?action=getPesanan`);
        const dataPesanan = await resPesanan.json();

        if (dataSiswa.success && dataSiswa.data) setSiswa(dataSiswa.data);
        if (dataBuku.success && dataBuku.data) setBuku(dataBuku.data);
        if (dataPesanan.success && dataPesanan.data) {
          // Sync orders
          setPesanan(dataPesanan.data);
          // Sync detailed items
          const details: DetailPesanan[] = [];
          dataPesanan.data.forEach((ord: any) => {
            if (ord.items) {
              details.push(...ord.items);
            }
          });
          if (details.length > 0) {
            setDetailPesanan(details);
          }
        }

        addAuditLog('Google Sheets Pull', 'Mengunduh data terbaru dari Google Sheets.');
        return { success: true, message: 'Berhasil mengunduh data terbaru dari Google Sheets!' };
      }
    } catch (err: any) {
      console.error('GAS Sync Error:', err);
      return { success: false, message: `Gagal sinkronisasi: ${err.message || err.toString()}` };
    }
  };

  const clearAndResetLocal = () => {
    localStorage.removeItem('xaverius_siswa');
    localStorage.removeItem('xaverius_buku');
    localStorage.removeItem('xaverius_pesanan');
    localStorage.removeItem('xaverius_detail_pesanan');
    localStorage.removeItem('xaverius_transaksi');
    localStorage.removeItem('xaverius_log_stok');
    localStorage.removeItem('xaverius_users');
    localStorage.removeItem('xaverius_settings');
    localStorage.removeItem('xaverius_audit_logs');
    localStorage.removeItem('xaverius_config');
    
    setSiswa(INITIAL_SISWA);
    setBuku(INITIAL_BUKU);
    setPesanan(INITIAL_PESANAN);
    setDetailPesanan(INITIAL_DETAIL_PESANAN);
    setTransaksi(INITIAL_TRANSAKSI);
    setLogStok(INITIAL_LOG_STOK);
    setUsers(INITIAL_USER);
    setSchoolSettings(INITIAL_SCHOOL_SETTINGS);
    setAuditLogs(INITIAL_AUDIT_LOGS);
    setConfig({ 
      gasUrl: '', 
      isLiveMode: false, 
      googleSpreadsheetId: '1Ff5ru5DPHxDoHERc38ukdHtPW7XedLU2bGJp3f7g1hE', 
      syncMode: 'direct' 
    });
    
    addAuditLog('Reset Data', 'Mengembalikan seluruh database ke kondisi awal pabrik.');
    showToast('Semua data lokal berhasil direset ke setelan awal!', 'info');
  };

  const connectGoogle = async () => {
    try {
      const result = await googleSignIn();
      if (result) {
        setGoogleUser(result.user);
        setGoogleToken(result.accessToken);
        addAuditLog('Koneksi Google', `Akun Google ${result.user.email} berhasil dihubungkan.`);
        showToast(`Berhasil menghubungkan Google Account: ${result.user.email}!`, 'success');
      }
    } catch (err: any) {
      showToast(`Gagal menghubungkan Google Account: ${err.message || err}`, 'error');
    }
  };

  const disconnectGoogle = async () => {
    try {
      await googleSignOut();
      setGoogleUser(null);
      setGoogleToken(null);
      addAuditLog('Diskoneksi Google', `Akun Google dilepas.`);
      showToast('Koneksi Google diputus.', 'info');
    } catch (err: any) {
      showToast('Gagal memutuskan Google Account.', 'error');
    }
  };

  const initializeSheetsInSpreadsheet = async (): Promise<{ success: boolean; message: string }> => {
    if (!googleToken) {
      return { success: false, message: 'Akun Google belum terhubung!' };
    }
    const spreadId = extractSpreadsheetId(config.googleSpreadsheetId || '1Ff5ru5DPHxDoHERc38ukdHtPW7XedLU2bGJp3f7g1hE');
    if (!spreadId) {
      return { success: false, message: 'ID Spreadsheet Google tidak valid!' };
    }

    try {
      const res = await initializeSpreadsheet(googleToken, spreadId);
      addAuditLog('Inisialisasi Spreadsheet', `Membuat tabel yang belum ada di spreadsheet ${spreadId}.`);
      let msg = 'Spreadsheet siap digunakan!';
      if (res.created.length > 0) {
        msg += ` Membuat tabel baru: ${res.created.join(', ')}.`;
      }
      return { success: true, message: msg };
    } catch (err: any) {
      console.error(err);
      return { success: false, message: `Gagal inisialisasi: ${err.message || err}` };
    }
  };

  return (
    <AppContext.Provider value={{
      siswa,
      buku,
      pesanan,
      detailPesanan,
      transaksi,
      logStok,
      users,
      schoolSettings,
      auditLogs,
      activeUser,
      config,
      toastMsg,
      
      // Google Auth states
      googleUser,
      googleToken,
      connectGoogle,
      disconnectGoogle,
      initializeSheetsInSpreadsheet,
      
      showToast,
      login,
      logout,
      addOrder,
      saveBook,
      deleteBook,
      confirmPayment,
      dispatchBook,
      
      saveSiswa,
      deleteSiswa,
      saveUser,
      deleteUser,
      updateSchoolSettings,
      saveConfig,
      
      syncWithGoogleSheets,
      clearAndResetLocal
    }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
}
