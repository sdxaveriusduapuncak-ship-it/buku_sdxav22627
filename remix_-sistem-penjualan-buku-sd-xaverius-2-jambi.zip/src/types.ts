/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Siswa {
  NIS: string;
  Nama: string;
  Kelas: string;
  JenisKelamin: 'L' | 'P';
  NamaOrtu: string;
  NoHP: string;
}

export interface Buku {
  KodeBuku: string;
  Barcode: string;
  NamaBuku: string;
  Kelas: string;
  Harga: number;
  Stok: number;
  Kategori: string;
  Status: 'AKTIF' | 'NONAKTIF';
  Foto?: string;
}

export type OrderStatus = 'MENUNGGU PEMBAYARAN' | 'LUNAS' | 'SELESAI' | 'BATAL';

export interface Pesanan {
  NoPesanan: string;
  Tanggal: string;
  NamaSiswa: string;
  NIS: string;
  Kelas: string;
  Total: number;
  Status: OrderStatus;
  Petugas: string;
  BukuScanned?: Record<string, number>; // Local tracking for barcode scan counts
}

export interface DetailPesanan {
  NoPesanan: string;
  KodeBuku: string;
  NamaBuku: string;
  Qty: number;
  Harga: number;
  Subtotal: number;
}

export interface Transaksi {
  NoTransaksi: string;
  NoPesanan: string;
  TanggalBayar: string;
  MetodePembayaran: string;
  Jumlah: number;
  Status: 'SUKSES' | 'GAGE';
}

export interface LogStok {
  Tanggal: string;
  KodeBuku: string;
  NamaBuku: string;
  Masuk: number;
  Keluar: number;
  Sisa: number;
  Petugas: string;
}

export interface User {
  Username: string;
  Password?: string;
  Role: 'ADMIN' | 'TU';
}

export interface SchoolSettings {
  Logo: string;
  NamaSekolah: string;
  Alamat: string;
  Telepon: string;
  TahunPelajaran: string;
}

export interface AuditLog {
  id: string;
  tanggal: string;
  user: string;
  aktivitas: string;
  keterangan: string;
}

export interface AppConfig {
  gasUrl: string;
  isLiveMode: boolean;
  googleSpreadsheetId?: string;
  syncMode?: 'direct' | 'gas';
}
